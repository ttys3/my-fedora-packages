<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="nb_NO">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>Version: %1</source>
        <translation>Versjon: %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="65"/>
        <source>Development version</source>
        <translation>Utviklingsversjon</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Links:</source>
        <translation>Lenker:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>Official website:</source>
        <translation>Offisiell nettside:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="85"/>
        <source>SMPlayer is a graphical interface for %1.</source>
        <translation>SMPlayer er et grafisk grensesnitt for %1.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="170"/>
        <source>Click here to know the translators from the transifex teams</source>
        <translation>Klikk her for å se oversetterne fra Transifex-lagene</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="166"/>
        <source>Many people contributed with translations.</source>
        <translation>Mange personer bidro med oversettelser.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>You can also help to translate SMPlayer into your own language.</source>
        <translation>Du kan også hjelpe med å oversette SMPlayer til ditt eget språk.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>Visit %1 and join a translation team.</source>
        <translation>Besøk %1 og bli med på et oversetterlag.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="60"/>
        <source>Using %1</source>
        <translation>Bruker %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="44"/>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="81"/>
        <source>SMPlayer is a graphical interface for %1 and %2.</source>
        <translation>SMPlayer er et grafisk grensesnitt for %1 og %2.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="14"/>
        <source>About SMPlayer</source>
        <translation>Om SMPlayer</translation>
    </message>
    <message>
        <location filename="../about.ui" line="33"/>
        <source>Page</source>
        <translation>Side</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>&amp;Info</source>
        <translation>&amp;Info</translation>
    </message>
    <message>
        <location filename="../about.ui" line="58"/>
        <location filename="../about.ui" line="114"/>
        <location filename="../about.ui" line="170"/>
        <location filename="../about.ui" line="226"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <location filename="../about.ui" line="94"/>
        <source>&amp;Contributions</source>
        <translation>&amp;Bidragsytere</translation>
    </message>
    <message>
        <location filename="../about.ui" line="150"/>
        <source>&amp;Translators</source>
        <translation>&amp;Oversettere</translation>
    </message>
    <message>
        <location filename="../about.ui" line="206"/>
        <source>&amp;License</source>
        <translation>&amp;Lisenser</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="67"/>
        <source>Portable Edition</source>
        <translation>Flyttbar utgave</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Bruker QT %1 (kompilert med Qt %2)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="126"/>
        <source>SMPlayer logo by %1</source>
        <translation>SMPlayer-logoen ble laget av %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="107"/>
        <source>Read the entire license</source>
        <translation>Les hele lisensen</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="115"/>
        <source>Read a translation</source>
        <translation>Les en oversettelse</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="127"/>
        <source>Packages for Windows created by %1</source>
        <translation>Installeringspakker for Windows ble laget av %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="128"/>
        <source>Many other people contributed with patches. See the Changelog for details.</source>
        <translation>Mange andre folk hjalp til med feilrettinger. Se endringsloggen for detaljer.</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Shortcut</source>
        <translation>Snarvei</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="242"/>
        <source>&amp;Save</source>
        <translation>&amp;Lagre</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="245"/>
        <source>&amp;Load</source>
        <translation>&amp;Last inn</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="503"/>
        <location filename="../actionseditor.cpp" line="553"/>
        <source>Key files</source>
        <translation>Nøkkelfiler</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="501"/>
        <source>Choose a filename</source>
        <translation>Velg et filnavn</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="213"/>
        <source>Type to search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="512"/>
        <source>Confirm overwrite?</source>
        <translation>Vil du skrive over?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="513"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1-filen finnes allerede.
Vil du overskrive den?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="552"/>
        <source>Choose a file</source>
        <translation>Velg en fil</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="525"/>
        <location filename="../actionseditor.cpp" line="559"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="526"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Filen kunne ikke lagres</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="560"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Filen kunne ikke lastes inn</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="249"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Endre snarvei...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="189"/>
        <source>Audio Equalizer</source>
        <translation>Lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="192"/>
        <location filename="../audioequalizer.cpp" line="193"/>
        <location filename="../audioequalizer.cpp" line="194"/>
        <location filename="../audioequalizer.cpp" line="195"/>
        <location filename="../audioequalizer.cpp" line="196"/>
        <source>%1 Hz</source>
        <translation>%1Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="197"/>
        <location filename="../audioequalizer.cpp" line="198"/>
        <location filename="../audioequalizer.cpp" line="199"/>
        <location filename="../audioequalizer.cpp" line="200"/>
        <location filename="../audioequalizer.cpp" line="201"/>
        <source>%1 kHz</source>
        <translation>%1kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="203"/>
        <source>&amp;Preset</source>
        <translation>&amp;Forhåndsinnstilling</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="204"/>
        <source>&amp;Apply</source>
        <translation>&amp;Bruk</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="205"/>
        <source>&amp;Reset</source>
        <translation>&amp;Tilbakestill</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="206"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Sett som standardverdier</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="207"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="212"/>
        <source>Flat</source>
        <translation>Flat</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="213"/>
        <source>Classical</source>
        <translation>Klassisk</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="214"/>
        <source>Club</source>
        <translation>Club</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="215"/>
        <source>Dance</source>
        <translation>Dance</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="216"/>
        <source>Full bass</source>
        <translation>Full bass</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="217"/>
        <source>Full bass and treble</source>
        <translation>Full bass og diskant</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="218"/>
        <source>Full treble</source>
        <translation>Full diskant</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="219"/>
        <source>Headphones</source>
        <translation>Hodetelefoner</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="220"/>
        <source>Large hall</source>
        <translation>Stor hall</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="221"/>
        <source>Live</source>
        <translation>Liveopptreden</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="222"/>
        <source>Party</source>
        <translation>Fest</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="223"/>
        <source>Pop</source>
        <translation>Pop</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="224"/>
        <source>Reggae</source>
        <translation>Reggae</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="225"/>
        <source>Rock</source>
        <translation>Rock</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="226"/>
        <source>Ska</source>
        <translation>Ska</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="227"/>
        <source>Soft</source>
        <translation>Soft</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="228"/>
        <source>Soft rock</source>
        <translation>Softrock</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="229"/>
        <source>Techno</source>
        <translation>Techno</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="230"/>
        <source>Custom</source>
        <translation>Tilpasset</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="235"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Bruk de nåværende verdiene som standardverdier for nye videoer.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="237"/>
        <source>Set all controls to zero.</source>
        <translation>Sett alle kontrollene til 0.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="252"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="253"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>De nåværende verdiene har blitt lagret for å brukes som standard.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="2001"/>
        <source>&amp;Open</source>
        <translation>&amp;Åpne</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2002"/>
        <source>&amp;Play</source>
        <translation>&amp;Spill av</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2003"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2004"/>
        <source>&amp;Audio</source>
        <translation>&amp;Lyd</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2005"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Undertekster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2006"/>
        <source>&amp;Browse</source>
        <translation>&amp;Bla</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2008"/>
        <source>Op&amp;tions</source>
        <translation>Inn&amp;stillinger</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2009"/>
        <source>&amp;Help</source>
        <translation>&amp;Hjelp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;File...</source>
        <translation>&amp;Fil...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1717"/>
        <source>D&amp;irectory...</source>
        <translation>Hel m&amp;appe...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1718"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Spilleliste...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1721"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD fra diskleser</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1722"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD fra mappe...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>&amp;URL...</source>
        <translation>&amp;Nettadresse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2025"/>
        <source>&amp;Clear</source>
        <translation>&amp;Fjern</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2023"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Nylige filer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1751"/>
        <source>P&amp;lay</source>
        <translation>S&amp;pill av</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1754"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1755"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stopp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1756"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Ett bilde fremover</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1775"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Vanlig fart</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1777"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Dobbel fart</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1778"/>
        <source>Speed &amp;-10%</source>
        <translation>Fart &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1779"/>
        <source>Speed &amp;+10%</source>
        <translation>Fart &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1873"/>
        <source>&amp;Off</source>
        <comment>closed captions menu</comment>
        <translation>%Av</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2043"/>
        <source>Sp&amp;eed</source>
        <translation>Fa&amp;rt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1770"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Gjenta</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1786"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Fullskjerm</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1787"/>
        <source>&amp;Compact mode</source>
        <translation>&amp;Kompakt modus</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2053"/>
        <source>Si&amp;ze</source>
        <translation>St&amp;ørrelse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2063"/>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Visningsaspekt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2102"/>
        <location filename="../basegui.cpp" line="3616"/>
        <location filename="../basegui.cpp" line="3630"/>
        <source>&amp;None</source>
        <translation>&amp;Ingen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2103"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2106"/>
        <source>Linear &amp;Blend</source>
        <translation>Lineær &amp;sammenblanding</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2066"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Avflett</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1815"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Etterbehandling</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1816"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autooppdag bølgefaser</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1817"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Avblokk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1818"/>
        <source>De&amp;ring</source>
        <translation>Av&amp;ring</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1820"/>
        <source>Add n&amp;oise</source>
        <translation>Legg til s&amp;tøy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2069"/>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltre</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1788"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Tonekontroll</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1789"/>
        <source>&amp;Screenshot</source>
        <translation>&amp;Skjermbilde</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2075"/>
        <source>S&amp;tay on top</source>
        <translation>H&amp;old alltid øverst</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1838"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Ekstrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1839"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2138"/>
        <source>&amp;Filters</source>
        <translation>&amp;Filter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2148"/>
        <location filename="../basegui.cpp" line="2154"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2149"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2150"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2141"/>
        <source>&amp;Channels</source>
        <translation>&amp;Kanaler</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2155"/>
        <source>&amp;Left channel</source>
        <translation>&amp;Venstre kanal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2156"/>
        <source>&amp;Right channel</source>
        <translation>&amp;Høyre kanal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2144"/>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Stereomodus</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1828"/>
        <source>&amp;Mute</source>
        <translation>&amp;Demp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1829"/>
        <source>Volume &amp;-</source>
        <translation>Volum &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1830"/>
        <source>Volume &amp;+</source>
        <translation>Volum &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1831"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Forsinkelse -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1832"/>
        <source>D&amp;elay +</source>
        <translation>F&amp;orsinkelse +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2164"/>
        <source>&amp;Select</source>
        <translation>&amp;Velg</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1846"/>
        <source>&amp;Load...</source>
        <translation>&amp;Last inn...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1848"/>
        <source>Delay &amp;-</source>
        <translation>Forsinkelse &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1849"/>
        <source>Delay &amp;+</source>
        <translation>Forsinkelse &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1851"/>
        <source>&amp;Up</source>
        <translation>&amp;Opp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1852"/>
        <source>&amp;Down</source>
        <translation>&amp;Ned</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2182"/>
        <source>&amp;Title</source>
        <translation>&amp;Tittel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2185"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Kapittel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2188"/>
        <source>&amp;Angle</source>
        <translation>&amp;Vinkel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1888"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Spilleliste</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2100"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Deaktivert</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2220"/>
        <source>&amp;OSD</source>
        <translation>&amp;OSD (Videooverlegg)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1890"/>
        <source>P&amp;references</source>
        <translation>P&amp;referanser</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1924"/>
        <source>About &amp;SMPlayer</source>
        <translation>Om &amp;SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3653"/>
        <location filename="../basegui.cpp" line="3669"/>
        <location filename="../basegui.cpp" line="3685"/>
        <location filename="../basegui.cpp" line="3700"/>
        <location filename="../basegui.cpp" line="3734"/>
        <location filename="../basegui.cpp" line="3754"/>
        <location filename="../basegui.cpp" line="3830"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tom&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4294"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4295"/>
        <location filename="../basegui.cpp" line="4545"/>
        <source>Audio</source>
        <translation>Lyd</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4296"/>
        <source>Playlists</source>
        <translation>Spillelister</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4297"/>
        <location filename="../basegui.cpp" line="4520"/>
        <location filename="../basegui.cpp" line="4546"/>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4292"/>
        <location filename="../basegui.cpp" line="4517"/>
        <location filename="../basegui.cpp" line="4543"/>
        <source>Choose a file</source>
        <translation>Velg en fil</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1892"/>
        <source>&amp;YouTube%1 browser</source>
        <translation>&amp;YouTube%1-leser</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1920"/>
        <source>&amp;Donate / Share with your friends</source>
        <translation>&amp;Doner / Del med dine venner</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4356"/>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer - Informasjon</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4357"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM/DVD-driverne er ikke konfigurert ennå.
Konfigurasjonsveiviseren vil vises nå, sånn at du kan gjøre det.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4470"/>
        <source>Select the Blu-ray folder</source>
        <translation>Velg Blu-Ray-mappen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4483"/>
        <source>Choose a directory</source>
        <translation>Velg en plassering</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4519"/>
        <source>Subtitles</source>
        <translation>Undertekster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4633"/>
        <source>&amp;Donate with PayPal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4634"/>
        <source>&amp;Not now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4637"/>
        <source>&amp;No</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5165"/>
        <location filename="../basegui.cpp" line="5194"/>
        <source>Error detected</source>
        <translation>Feil oppdaget</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5195"/>
        <source>Unfortunately this video can&apos;t be played.</source>
        <translation>Dessverre kan ikke denne videoen spilles av.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5432"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5433"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1759"/>
        <source>Play / Pause</source>
        <translation>Spill av / Pause</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1762"/>
        <source>Pause / Frame step</source>
        <translation>Pause / Ett bilde fremover</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1835"/>
        <location filename="../basegui.cpp" line="1847"/>
        <source>U&amp;nload</source>
        <translation>L&amp;øs ut</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1719"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>C&amp;lose</source>
        <translation>L&amp;ukk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1803"/>
        <source>Zoom &amp;-</source>
        <translation>Zoom &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1804"/>
        <source>Zoom &amp;+</source>
        <translation>Zoom &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1805"/>
        <source>&amp;Reset</source>
        <translation>&amp;Start på nytt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1809"/>
        <source>Move &amp;left</source>
        <translation>Gå til &amp;venstre</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1810"/>
        <source>Move &amp;right</source>
        <translation>Så til &amp;høyre</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1811"/>
        <source>Move &amp;up</source>
        <translation>Gå &amp;opp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1812"/>
        <source>Move &amp;down</source>
        <translation>Gå &amp;ned</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1856"/>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Forrige linje i underteksten</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1858"/>
        <source>N&amp;ext line in subtitles</source>
        <translation>N&amp;este linje i underteksten</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1897"/>
        <location filename="../basegui.cpp" line="2242"/>
        <source>%1 log</source>
        <translation>%1-logg</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1900"/>
        <location filename="../basegui.cpp" line="2245"/>
        <source>SMPlayer log</source>
        <translation>SMPlayer-logg</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2258"/>
        <location filename="../basegui.cpp" line="2259"/>
        <location filename="../basegui.cpp" line="2260"/>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2262"/>
        <location filename="../basegui.cpp" line="2263"/>
        <location filename="../basegui.cpp" line="2264"/>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1953"/>
        <source>Dec volume (2)</source>
        <translation>Senk volum (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>&amp;Blu-ray from drive</source>
        <translation>&amp;Blu-Ray fra diskleser</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1725"/>
        <source>Blu-&amp;ray from folder...</source>
        <translation>Blu-&amp;Ray fra mappe...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1757"/>
        <source>Fra&amp;me back step</source>
        <translation>E&amp;tt bilde bakover</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1776"/>
        <source>&amp;Half speed</source>
        <translation>&amp;Halvert fart</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1790"/>
        <source>Screenshot with subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1791"/>
        <source>Screenshot without subtitles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1794"/>
        <source>Start/stop capturing stream</source>
        <translation>Start/stopp opptak av kringkasting</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1797"/>
        <source>Thumb&amp;nail Generator...</source>
        <translation>Forhånds&amp;visningsgenerator...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1801"/>
        <source>Stereo &amp;3D filter</source>
        <translation>3D-&amp;visningsfilter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1819"/>
        <source>Debanding (&amp;gradfun)</source>
        <translation>Avklistring (med &amp;gradfun)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1842"/>
        <source>&amp;Headphone optimization</source>
        <translation>&amp;Hodetelefon-optimalisering</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1860"/>
        <source>Seek to next subtitle</source>
        <translation>Spol frem til neste undertekst</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1861"/>
        <source>Seek to previous subtitle</source>
        <translation>Spol frem til forrige undertekst</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1863"/>
        <source>Use custo&amp;m style</source>
        <translation>Bruk tilpasset stil</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1869"/>
        <source>Find subtitles at &amp;OpenSubtitles.org...</source>
        <translation>Finn undertekster hos &amp;OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1879"/>
        <source>&amp;Default</source>
        <comment>subfps menu</comment>
        <translation>&amp;Standard</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1889"/>
        <source>&amp;Information and properties...</source>
        <translation>&amp;Informasjon og egenskaper...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1902"/>
        <source>T&amp;ablet mode</source>
        <translation>N&amp;ettbrettmodus</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1905"/>
        <source>First Steps &amp;Guide</source>
        <translation>&amp;Veiledning for dine første skritt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1912"/>
        <source>Update &amp;YouTube support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1914"/>
        <source>Install / Update &amp;YouTube support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1918"/>
        <source>&amp;Open configuration folder</source>
        <translation>&amp;Åpne konfigureringsmappe</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1922"/>
        <location filename="../basegui.cpp" line="4636"/>
        <source>&amp;Donate</source>
        <translation>&amp;Doner</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1935"/>
        <source>Size &amp;+</source>
        <translation>Størrelse &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1936"/>
        <source>Size &amp;-</source>
        <translation>Størrelse &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1939"/>
        <source>Show times with &amp;milliseconds</source>
        <translation>Vis tider med &amp;millisekunder</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1954"/>
        <source>Inc volume (2)</source>
        <translation>Øk volum (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1957"/>
        <source>Exit fullscreen</source>
        <translation>Gå ut av fullskjerm</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1959"/>
        <source>OSD - Next level</source>
        <translation>OSD - Neste nivå</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1960"/>
        <source>Dec contrast</source>
        <translation>Senk kontrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1961"/>
        <source>Inc contrast</source>
        <translation>Øk kontrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1962"/>
        <source>Dec brightness</source>
        <translation>Senk lysstyrke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1963"/>
        <source>Inc brightness</source>
        <translation>Øk lysstyrke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1964"/>
        <source>Dec hue</source>
        <translation>Senk kulørverdi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1965"/>
        <source>Inc hue</source>
        <translation>Øk kulørverdi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1966"/>
        <source>Dec saturation</source>
        <translation>Senk fargemetning</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1968"/>
        <source>Dec gamma</source>
        <translation>Senk gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1970"/>
        <source>Previous video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1972"/>
        <source>Previous audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1973"/>
        <source>Next audio</source>
        <translation>Neste lydfil</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1974"/>
        <source>Previous subtitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1975"/>
        <source>Next subtitle</source>
        <translation>Neste undertekst</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1976"/>
        <source>Next chapter</source>
        <translation>Neste kapittel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1977"/>
        <source>Previous chapter</source>
        <translation>Forrige kapittel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1985"/>
        <source>Show filename on OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1986"/>
        <source>Show &amp;info on OSD</source>
        <translation>Vis info i OSD-visningen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1987"/>
        <source>Show playback time on OSD</source>
        <translation>Vis avspillingstid i OSD-visningen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2007"/>
        <source>Vie&amp;w</source>
        <translation>Vi&amp;s</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2083"/>
        <source>De&amp;noise</source>
        <translation>Støy&amp;fjerning</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2086"/>
        <source>Blur/S&amp;harp</source>
        <translation>(U)tydelig&amp;gjør</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2109"/>
        <source>&amp;Off</source>
        <comment>denoise menu</comment>
        <translation>&amp;Av</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2110"/>
        <source>&amp;Normal</source>
        <comment>denoise menu</comment>
        <translation>&amp;Normal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2111"/>
        <source>&amp;Soft</source>
        <comment>denoise menu</comment>
        <translation>&amp;Myk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2113"/>
        <source>&amp;None</source>
        <comment>unsharp menu</comment>
        <translation>&amp;Ingen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2114"/>
        <source>&amp;Blur</source>
        <comment>unsharp menu</comment>
        <translation>&amp;Utydeliggjør</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2115"/>
        <source>&amp;Sharpen</source>
        <comment>unsharp menu</comment>
        <translation>Gjør &amp;skarpere</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2122"/>
        <source>Rotate by 1&amp;80 degrees</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2136"/>
        <source>Select audio track</source>
        <translation>Velg lydspor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2151"/>
        <source>&amp;6.1 Surround</source>
        <translation>&amp;6.1 surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2152"/>
        <source>&amp;7.1 Surround</source>
        <translation>&amp;7.1 surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2157"/>
        <source>&amp;Mono</source>
        <translation>&amp;Mono</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2158"/>
        <source>Re&amp;verse</source>
        <translation>&amp;Omvendt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2162"/>
        <source>Prim&amp;ary track</source>
        <translation>Hovedspor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2167"/>
        <source>Select subtitle track</source>
        <translation>Velg undertekstspor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2170"/>
        <source>Secondary trac&amp;k</source>
        <translation>Sekundært spor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2172"/>
        <source>Select secondary subtitle track</source>
        <translation>Velg sekundært undertekstspor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2178"/>
        <source>F&amp;rames per second</source>
        <translation>B&amp;ilder i sekundet</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2192"/>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Bokmerker</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2202"/>
        <source>&amp;Add new bookmark</source>
        <translation>&amp;Legg til nytt bokmerke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2203"/>
        <source>&amp;Edit bookmarks</source>
        <translation>&amp;Rediger bokmerker</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2204"/>
        <source>Previous bookmark</source>
        <translation>Forrige bokmerke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2205"/>
        <source>Next bookmark</source>
        <translation>Neste bokmerke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2234"/>
        <source>Quick access menu</source>
        <translation>Hurtigtilgangsmeny</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3047"/>
        <source>Logs</source>
        <translation>Loggbøker</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3352"/>
        <source>You need to restart SMPlayer in order to apply the new preferences.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4630"/>
        <source>Support SMPlayer</source>
        <translation>Støtt SMPlayer</translation>
    </message>
    <message>
        <source>No</source>
        <translation type="obsolete">Nei</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4641"/>
        <source>SMPlayer needs you</source>
        <translation>SMPlayer trenger deg.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4642"/>
        <source>SMPlayer is free software. However the development requires a lot of time and a lot of work.</source>
        <translation>SMPlayer er en fri programvare. Men utviklingen av den krever masse tid og masse arbeid.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4643"/>
        <source>In order to keep developing SMPlayer with new features we need your help.</source>
        <translation>For å kunne fortsette å støtte SMPlayer med nye funksjoner, trenger vi din hjelp.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4644"/>
        <source>Please consider to support the SMPlayer project by sending a donation.</source>
        <translation>Tenk på om du vil støtte SMPlayer-prosjektet ved å gi en donasjon.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4645"/>
        <source>Even the smallest amount will help a lot.</source>
        <translation>Selv den minste sum vil være til stor hjelp.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5166"/>
        <source>The youtube-dl process failed because of missing libraries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5167"/>
        <source>You&apos;ll probably need to install %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5169"/>
        <source>the Microsoft Visual C++ 2010 Redistributable Package</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6159"/>
        <location filename="../basegui.cpp" line="6212"/>
        <source>More info in the log.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6165"/>
        <location filename="../basegui.cpp" line="6218"/>
        <source>%1 Error</source>
        <translation>%1-feil</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6159"/>
        <location filename="../basegui.cpp" line="6166"/>
        <source>%1 has finished unexpectedly.</source>
        <translation>%1 har blitt uventet fullført.</translation>
    </message>
    <message>
        <source>Donate with PayPal</source>
        <translation type="obsolete">Donér med PayPal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4649"/>
        <source>It&apos;s also possible to donate with cryptocurrencies.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6191"/>
        <source>The component youtube-dl failed to run.</source>
        <translation>Komponenten youtube-dl mislyktes i å kjøre.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6192"/>
        <source>Installing the Microsoft Visual C++ 2010 Redistributable Package (x86) may fix the problem.</source>
        <translation>Å installere Microsoft Visual C++ 2010 Redistributable Package (x86) kan løse problemet.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6194"/>
        <source>Click here to get it</source>
        <translation>Trykk her for å skaffe deg det</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6212"/>
        <location filename="../basegui.cpp" line="6220"/>
        <source>%1 failed to start.</source>
        <translation>%1 mislyktes i å starte opp.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6221"/>
        <source>Please check the %1 path in preferences.</source>
        <translation>Vennligst sjekk %1-filbanen i preferansene.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6223"/>
        <source>%1 has crashed.</source>
        <translation>%1 har krasjet.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6318"/>
        <source>The YouTube Browser is not installed.</source>
        <translation>YouTube-leseren er ikke installert.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6319"/>
        <location filename="../basegui.cpp" line="6331"/>
        <source>Visit %1 to get it.</source>
        <translation>Besøk %1 for å skaffe deg den.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6329"/>
        <source>The YouTube Browser failed to run.</source>
        <translation>YouTube-leseren klarte ikke å kjøre.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6330"/>
        <source>Be sure it&apos;s installed correctly.</source>
        <translation>Sjekk at det har blitt installert riktig.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6497"/>
        <source>The system has switched to tablet mode. Should SMPlayer change to tablet mode as well?</source>
        <translation>Maskinen har byttet til nettbrettmodus. Burde SMPlayer også bytte til nettbrettmodus?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6499"/>
        <source>The system has exited tablet mode. Should SMPlayer turn off the tablet mode as well?</source>
        <translation>Maskinen har gått ut av nettbrettmodus. Burde SMPlayer også gå ut av nettbrettmodus?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6503"/>
        <source>Remember my decision and don&apos;t ask again</source>
        <translation>Husk mitt svar og ikke spør igjen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2224"/>
        <source>S&amp;hare SMPlayer with your friends</source>
        <translation>D&amp;el SMPlayer med dine venner</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3351"/>
        <location filename="../basegui.cpp" line="4087"/>
        <source>Information</source>
        <translation>Informasjon</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3842"/>
        <source>Confirm deletion - SMPlayer</source>
        <translation>Bekreft sletting — SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3843"/>
        <source>Delete the list of recent files?</source>
        <translation>Vil du slette listen over nylige filer?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4088"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>De nåværende verdiene har blitt lagret for å brukes som standard.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1967"/>
        <source>Inc saturation</source>
        <translation>Øk fargemetning</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1969"/>
        <source>Inc gamma</source>
        <translation>Øk gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1834"/>
        <source>&amp;Load external file...</source>
        <translation>&amp;Last inn ekstern fil...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2107"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2104"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2105"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (dobbel bildefrekvens)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1943"/>
        <source>&amp;Next</source>
        <translation>&amp;Neste</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1944"/>
        <source>Pre&amp;vious</source>
        <translation>For&amp;rige</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1840"/>
        <source>Volume &amp;normalization</source>
        <translation>Volum&amp;stabilisering</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Lyd-CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1978"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Skru av eller på dobbel størrelse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1853"/>
        <source>S&amp;ize -</source>
        <translation>S&amp;tørrelse -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1854"/>
        <source>Si&amp;ze +</source>
        <translation>St&amp;ørrelse +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1821"/>
        <source>Add &amp;black borders</source>
        <translation>Legg til &amp;svarte kanter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1822"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Prog&amp;ramvareskalering</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1906"/>
        <source>&amp;FAQ</source>
        <translation>&amp;Ofte stilte spørsmål</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1907"/>
        <source>&amp;Command line options</source>
        <translation>&amp;Kommandolinjeinnstillinger</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4565"/>
        <source>SMPlayer command line options</source>
        <translation>SMPlayer-kommandolinjerinnstillinger</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1864"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Kun påtvugne undertekster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1979"/>
        <source>Reset video equalizer</source>
        <translation>Tilbakestill videotonekontroll</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5196"/>
        <source>The server returned &apos;%1&apos;</source>
        <translation>Serveren meldte tilbake med &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6167"/>
        <source>Exit code: %1</source>
        <translation>Avslutningskode: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6224"/>
        <source>See the log for more info.</source>
        <translation>Se gjennom loggen for mere info.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2072"/>
        <source>&amp;Rotate</source>
        <translation>&amp;Roter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2117"/>
        <source>&amp;Off</source>
        <translation>&amp;Av</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2118"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>&amp;Roter 90° med klokken og snu loddrett</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2119"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>Roter 90° &amp;med klokken</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2120"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>Roter 90° mot klokken</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2121"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Roter 90° mot klokken og &amp;snu loddrett</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1772"/>
        <source>&amp;Jump to...</source>
        <translation>&amp;Hopp til...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1981"/>
        <source>Show context menu</source>
        <translation>Vis kontekstmeny</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4293"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1825"/>
        <source>E&amp;qualizer</source>
        <translation>T&amp;onekontroll</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1980"/>
        <source>Reset audio equalizer</source>
        <translation>Tilbakestill lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1870"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Last opp un&amp;dertekster til OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2089"/>
        <source>&amp;Auto</source>
        <translation>&amp;Auto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1780"/>
        <source>Speed -&amp;4%</source>
        <translation>Fart -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1781"/>
        <source>&amp;Speed +4%</source>
        <translation>&amp;Fart +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1782"/>
        <source>Speed -&amp;1%</source>
        <translation>Fart - &amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1783"/>
        <source>S&amp;peed +1%</source>
        <translation>F&amp;art +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2079"/>
        <source>Scree&amp;n</source>
        <translation>Skjer&amp;m</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2130"/>
        <location filename="../basegui.cpp" line="2147"/>
        <source>&amp;Default</source>
        <translation>&amp;Standard</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1800"/>
        <source>Mirr&amp;or image</source>
        <translation>Spe&amp;ilvend bilde</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1971"/>
        <source>Next video</source>
        <translation>Neste video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2050"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Spor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2134"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Spor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5048"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Advarsel — Bruker gammel MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5049"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. SMPlayer can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Versjonen av MPlayer (%1) som er på din maskin er faset ut.
SMPlayer fungerer ikke bra med den: noen innstillinger kan ikke brukes, undertekstvalg kan mislykkes...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5054"/>
        <source>Please, update your MPlayer.</source>
        <translation>Vennligst oppdater din MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5056"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Denne advarselen vil ikke vises lenger)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1982"/>
        <source>Next aspect ratio</source>
        <translation>Neste visningsaspekt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1806"/>
        <source>&amp;Auto zoom</source>
        <translation>&amp;Autozoom</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1807"/>
        <source>Zoom for &amp;16:9</source>
        <translation>Zoom for &amp;16:9</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1808"/>
        <source>Zoom for &amp;2.35:1</source>
        <translation>Zoom for &amp;2,35:1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2124"/>
        <source>&amp;Always</source>
        <translation>&amp;Alltid</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2125"/>
        <source>&amp;Never</source>
        <translation>&amp;Aldri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2126"/>
        <source>While &amp;playing</source>
        <translation>Under &amp;avspilling</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>DVD &amp;menu</source>
        <translation>DVD-&amp;meny</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2215"/>
        <source>DVD &amp;previous menu</source>
        <translation>Forrige &amp;DVD-meny</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2209"/>
        <source>DVD menu, move up</source>
        <translation>DVD-meny, gå opp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2210"/>
        <source>DVD menu, move down</source>
        <translation>DVD-meny, gå ned</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2211"/>
        <source>DVD menu, move left</source>
        <translation>DVD-meny, gå til venstre</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2212"/>
        <source>DVD menu, move right</source>
        <translation>DVD-meny, gå til høyre</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2214"/>
        <source>DVD menu, select option</source>
        <translation>DVD-meny, velg alternativ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2216"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD-meny, museklikk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1833"/>
        <source>Set dela&amp;y...</source>
        <translation>Velg forsinke&amp;lse...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1850"/>
        <source>Se&amp;t delay...</source>
        <translation>Ve&amp;lg forsinkelse...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4712"/>
        <location filename="../basegui.cpp" line="4716"/>
        <source>SMPlayer - Audio delay</source>
        <translation>SMPlayer - Lydforsinkelse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4713"/>
        <location filename="../basegui.cpp" line="4717"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Lydforsinkelse (i millisekunder):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4728"/>
        <location filename="../basegui.cpp" line="4732"/>
        <source>SMPlayer - Subtitle delay</source>
        <translation>SMPlayer - Undertekstforsinkelse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4729"/>
        <location filename="../basegui.cpp" line="4733"/>
        <source>Subtitle delay (in milliseconds):</source>
        <translation>Undertekstforsinkelse (i millisekunder):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2127"/>
        <source>Toggle stay on top</source>
        <translation>Skru av/på Alltid øverst</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5658"/>
        <location filename="../basegui.cpp" line="6006"/>
        <source>Jump to %1</source>
        <translation>Hopp til %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1792"/>
        <source>Start/stop takin&amp;g screenshots</source>
        <translation>Start/stopp å ta skjermklipp</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1866"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Undertekst&amp;synlighet</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1983"/>
        <source>Next wheel function</source>
        <translation>Neste musehjulfunksjon</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2197"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>P&amp;rogram</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2035"/>
        <source>&amp;TV</source>
        <translation>&amp;TV</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2038"/>
        <source>Radi&amp;o</source>
        <translation>Radi&amp;o</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1994"/>
        <source>Subtitles onl&amp;y</source>
        <translation>Kun undert&amp;ekster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1995"/>
        <source>Volume + &amp;Seek</source>
        <translation>Volum + &amp;Spoling</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1996"/>
        <source>Volume + Seek + &amp;Timer</source>
        <translation>Volum + Spoling + &amp;Tidsmåler</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1997"/>
        <source>Volume + Seek + Timer + T&amp;otal time</source>
        <translation>Volum + Spoling + Tidsmåler + T&amp;otal varighet</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1657"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Videofiltre er deaktivert når man bruker vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1799"/>
        <source>Fli&amp;p image</source>
        <translation>Sn&amp;u bilde loddrett</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2060"/>
        <source>Zoo&amp;m</source>
        <translation>Zoo&amp;m</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1767"/>
        <source>Set &amp;A marker</source>
        <translation>Sett &amp;A-punkt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1768"/>
        <source>Set &amp;B marker</source>
        <translation>Sett &amp;B-punkt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1769"/>
        <source>&amp;Clear A-B markers</source>
        <translation>&amp;Fjern A- og B-punkter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2046"/>
        <source>&amp;A-B section</source>
        <translation>&amp;A-B-seksjon</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1989"/>
        <source>Toggle deinterlacing</source>
        <translation>Skru av eller på avfletting</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2175"/>
        <source>&amp;Closed captions</source>
        <translation>&amp;Undertekster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2027"/>
        <source>&amp;Disc</source>
        <translation>&amp;Disk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2031"/>
        <source>F&amp;avorites</source>
        <translation>F&amp;avoritter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1908"/>
        <source>Check for &amp;updates</source>
        <translation>Se etter &amp;oppdateringer</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="354"/>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer kjører fortsatt her</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="377"/>
        <source>S&amp;how icon in system tray</source>
        <translation>V&amp;is ikon i systemstatusfeltet</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="386"/>
        <source>&amp;Cast to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="389"/>
        <source>&amp;Chromecast</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="391"/>
        <source>&amp;Smartphone/tablet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="396"/>
        <source>Send &amp;video to screen</source>
        <translation>Send &amp;video til skjerm</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="398"/>
        <source>Information about connected &amp;screens</source>
        <translation>Informasjon om tilkoblede &amp;skjermer</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="401"/>
        <source>Video is sent to an external screen</source>
        <translation>Videosignal blir sendt til en ekstern skjerm</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="405"/>
        <source>Send &amp;audio to</source>
        <translation>Send &amp;lyd til</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="443"/>
        <source>&amp;Hide</source>
        <translation>&amp;Skjul</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="445"/>
        <source>&amp;Restore</source>
        <translation>&amp;Vis</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="922"/>
        <source>Information about connected screens</source>
        <translation>Informasjon om tilkoblede skjermer</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="925"/>
        <source>Connected screens</source>
        <translation>Tilkoblede skjermer</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="928"/>
        <location filename="../baseguiplus.cpp" line="970"/>
        <source>Number of screens: %1</source>
        <translation>Antall skjermer: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="933"/>
        <location filename="../baseguiplus.cpp" line="971"/>
        <source>Primary screen: %1</source>
        <translation>Hovedskjerm: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="941"/>
        <location filename="../baseguiplus.cpp" line="975"/>
        <source>Information for screen %1</source>
        <translation>Informasjon for skjerm %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="943"/>
        <location filename="../baseguiplus.cpp" line="977"/>
        <source>Available geometry: %1 %2 %3 x %4</source>
        <translation>Tilgjengelig geometri: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="945"/>
        <source>Available size: %1 x %2</source>
        <translation>Tilgjengelig størrelse: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="946"/>
        <source>Available virtual geometry: %1 %2 %3 x %4</source>
        <translation>Tilgjengelig virtuell geometri: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="950"/>
        <source>Available virtual size: %1 x %2</source>
        <translation>Tilgjengelig virtuell størrelse: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="952"/>
        <source>Depth: %1 bits</source>
        <translation>Dybde: %1 bit</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="953"/>
        <location filename="../baseguiplus.cpp" line="979"/>
        <source>Geometry: %1 %2 %3 x %4</source>
        <translation>Geometri: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="955"/>
        <source>Logical DPI: %1</source>
        <translation>Logisk DPI: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="957"/>
        <source>Physical DPI: %1</source>
        <translation>Fysisk DPI: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="958"/>
        <source>Physical size: %1 x %2 mm</source>
        <translation>Fysisk størrelse: %1 x %2 mm</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="960"/>
        <source>Refresh rate: %1 Hz</source>
        <translation>Oppfriskningsfrekvens: %1 Hz</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="961"/>
        <source>Size: %1 x %2</source>
        <translation>Størrelse: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="962"/>
        <source>Virtual geometry: %1 %2 %3 x %4</source>
        <translation>Virtuell geometri: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="964"/>
        <source>Virtual size: %1 x %2</source>
        <translation>Virtuell størrelse: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1017"/>
        <source>Primary screen</source>
        <translation>Hovedskjerm</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1102"/>
        <source>SMPlayer external screen output</source>
        <translation>SMPlayer ekstern skjermutdata</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1151"/>
        <source>&amp;Default audio device</source>
        <translation>&amp;Standard lydenhet</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="373"/>
        <source>&amp;Quit</source>
        <translation>&amp;Avslutt</translation>
    </message>
</context>
<context>
    <name>BookmarkDialog</name>
    <message>
        <location filename="../bookmarkdialog.ui" line="14"/>
        <source>Edit bookmarks</source>
        <translation>Rediger bokmerker</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.ui" line="38"/>
        <source>&amp;New bookmark</source>
        <translation>&amp;Nytt bokmerke</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.ui" line="45"/>
        <source>&amp;Delete bookmark</source>
        <translation>&amp;Slett bokmerke</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.cpp" line="76"/>
        <source>Time</source>
        <translation>Tid</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.cpp" line="76"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
</context>
<context>
    <name>Chromecast</name>
    <message>
        <location filename="../chromecast.cpp" line="91"/>
        <source>The SMPlayer web server is running</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../chromecast.cpp" line="93"/>
        <source>&amp;Stop the SMPlayer web server</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CodeDownloader</name>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="50"/>
        <source>Downloading...</source>
        <translation type="unfinished">Laster ned...</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="77"/>
        <source>Connecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="146"/>
        <source>The YouTube code has been installed successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="147"/>
        <source>Installed version: %1</source>
        <translation type="unfinished">Installert versjon: %1</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="148"/>
        <source>Success</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="153"/>
        <location filename="../youtube/codedownloader.cpp" line="158"/>
        <source>Error</source>
        <translation type="unfinished">Feil</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="153"/>
        <source>It&apos;s not possible to save %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="158"/>
        <source>An error happened while downloading the file:&lt;br&gt;%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="170"/>
        <source>It wasn&apos;t possible to find the URL for this video.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="166"/>
        <source>%1 failed to communicate with the external YouTube application. Either it&apos;s not installed or it doesn&apos;t work correctly.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="171"/>
        <source>Maybe you need to update the YouTube code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="176"/>
        <source>In order to play YouTube videos, %1 needs an external application called youtube-dl.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="177"/>
        <source>This component needs to be updated frequently.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="178"/>
        <source>You can update it just by reinstalling SMPlayer. The installer will download and install the very latest version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="180"/>
        <source>Install / Update YouTube support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="240"/>
        <source>In order to play YouTube videos, %1 needs the help of an external application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="241"/>
        <source>%1 can download and install this application for you.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="242"/>
        <source>It will be downloaded from the official website and installed as %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="243"/>
        <source>Would you like to proceed?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="247"/>
        <location filename="../youtube/codedownloader.cpp" line="250"/>
        <source>Install YouTube support?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3249"/>
        <source>Brightness: %1</source>
        <translation>Lysstyrke: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3265"/>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3280"/>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Hue: %1</source>
        <translation>Kulørverdi: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3310"/>
        <source>Saturation: %1</source>
        <translation>Fargemetning. %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3453"/>
        <source>Volume: %1</source>
        <translation>Volum: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4432"/>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3585"/>
        <location filename="../core.cpp" line="3596"/>
        <source>Font scale: %1</source>
        <translation>Fontskalering: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Aspect ratio: %1</source>
        <translation>Visningsaspekt: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4670"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Oppdaterer fontmellomlageret. Dette kan ta noen sekunder...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3510"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Undertekstforsinkelser: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3528"/>
        <source>Audio delay: %1 ms</source>
        <translation>Lydforsinkelse: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Speed: %1</source>
        <translation>Fart: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="580"/>
        <source>Unable to locate the URL of the video</source>
        <translation>Kunne ikke finne videoens nettadresse</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3684"/>
        <source>Subtitles on</source>
        <translation>Undertekster på</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3686"/>
        <source>Subtitles off</source>
        <translation>Undertekster av</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4309"/>
        <source>Mouse wheel seeks now</source>
        <translation>Musehjulet spoler nå</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4312"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Musehjulet endrer volumet nå</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4315"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Musehjulet endrer zoomingen nå</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4318"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Musehjulet endrer farten nå</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4646"/>
        <source>Screenshot saved as %1</source>
        <translation>Skjermklipp lagret som %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4681"/>
        <source>Starting...</source>
        <translation>Starter opp...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1419"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Skjermklippet ble IKKE tatt, siden mappen ikke er satt opp</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1432"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Skjermklippene ble IKKE tatt, siden mappen ikke er satt opp</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2851"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>A-punkt satt til %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2876"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>B-punkt satt til %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2899"/>
        <source>A-B markers cleared</source>
        <translation>A- og B-punktene ble fjernet</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="576"/>
        <source>Connecting to %1</source>
        <translation>Kobler opp til %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="711"/>
        <source>Audio</source>
        <translation>Lyd</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="712"/>
        <source>Subtitle</source>
        <translation>Undertekst</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="704"/>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Hovedverktøylinje</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="708"/>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Språkverktøylinje</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="698"/>
        <source>&amp;Toolbars</source>
        <translation>&amp;Verktøylinjer</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="677"/>
        <source>Ready</source>
        <translation>Klar</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="717"/>
        <source>F&amp;ormat info</source>
        <translation>F&amp;ormatinfo</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="760"/>
        <source>A:%1</source>
        <translation>A:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="764"/>
        <source>B:%1</source>
        <translation>B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="701"/>
        <source>Status&amp;bar</source>
        <translation>Status&amp;linje</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="264"/>
        <source>Time format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="715"/>
        <source>&amp;Video info</source>
        <translation>&amp;Videoinfo</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="716"/>
        <source>&amp;Frame counter</source>
        <translation>&amp;Bildeteller</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="718"/>
        <source>&amp;Bitrate info</source>
        <translation>&amp;Bitfrekvens-informasjon</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="719"/>
        <source>&amp;Show the current time with milliseconds</source>
        <translation>&amp;Vis den nåværende tiden med millisekunder</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="721"/>
        <source>Display &amp;total time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="722"/>
        <source>Display &amp;remaining time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="725"/>
        <source>Edit main &amp;toolbar</source>
        <translation>Rediger hoved&amp;verktøylinjen</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="726"/>
        <source>Edit &amp;control bar</source>
        <translation>Rediger &amp;kontrollinjen</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="727"/>
        <source>Edit m&amp;ini control bar</source>
        <translation>Rediger m&amp;inikontrollinjen</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="728"/>
        <source>Edit &amp;floating control</source>
        <translation>Rediger &amp;svevende kontroller</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="774"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation>%1x%2@%3Hz</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="786"/>
        <source>V: %1 kbps A: %2 kbps</source>
        <translation>Video: %1 Kb/s, Lyd: %2 Kb/s</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="40"/>
        <source>Oops, something went wrong</source>
        <translation>Oisann, noe gikk galt</translation>
    </message>
    <message>
        <location filename="../errordialog.cpp" line="67"/>
        <source>Hide log</source>
        <translation>Skjul logg</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="91"/>
        <location filename="../errordialog.cpp" line="69"/>
        <source>Show log</source>
        <translation>Vis logg</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="14"/>
        <source>MPlayer Error</source>
        <translation>Feil i MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="22"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="43"/>
        <source>Oops, something wrong happened</source>
        <translation>Oisann, det skjedde noe galt</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="62"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Icon</source>
        <translation>Ikon</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="116"/>
        <source>Favorite editor</source>
        <translation>Favorittredaktør</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="118"/>
        <location filename="../favoriteeditor.cpp" line="181"/>
        <location filename="../favoriteeditor.cpp" line="281"/>
        <source>Favorite list</source>
        <translation>Favorittliste</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="119"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Du kan redigere, slette, sortere eller legge til nye gjenstander. Dobbeltklikk i en boks for å redigere innholdet dens.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="354"/>
        <source>Select an icon file</source>
        <translation>Velg en ikonfil</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="356"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>ikon</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>S&amp;lett</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>Delete &amp;all</source>
        <translation>Slett &amp;alle</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>&amp;Up</source>
        <translation>&amp;Opp</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="112"/>
        <source>&amp;Down</source>
        <translation>&amp;Ned</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New item</source>
        <translation>&amp;Ny gjenstand</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="85"/>
        <source>New &amp;submenu</source>
        <translation>Nye &amp;undermeny</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="374"/>
        <location filename="../favorites.cpp" line="378"/>
        <source>Jump to item</source>
        <translation>Hopp til gjenstand</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="375"/>
        <location filename="../favorites.cpp" line="379"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Skriv inn gjenstandens nummer i listen for å hoppe:</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="89"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Rediger...</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="90"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Hopp...</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="91"/>
        <source>&amp;Next</source>
        <translation>&amp;Neste</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="92"/>
        <source>&amp;Previous</source>
        <translation>&amp;Forrige</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="93"/>
        <source>&amp;Add current media</source>
        <translation>&amp;Legg til nåværende medie</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.cpp" line="55"/>
        <source>Click to select a file or folder</source>
        <translation>Klikk for å velge en fil eller mappe</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="37"/>
        <source>Downloading...</source>
        <translation>Laster ned...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="64"/>
        <source>Connecting to %1</source>
        <translation>Kobler til %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer - Filegenskaper</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Informasjon</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demultiplekser</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Velg demultiplekseren som skal brukes til denne filen:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Tilbakestill</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Videokodek</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Velg videokodek:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>L&amp;ydkodek</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Velg lydkodek:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,mirror</source>
        <translation>Du kan også velge ytterligere videofiltre.
Skill dem med komma. Ikke bruk mellomrom!
Eksempel: scale=512:-2,mirror</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: extrastereo,karaoke</source>
        <translation>Og til slutt lydfiltre. Samme system som for videofiltre.
Eksempler: extrastereo,karaoke</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Innstillinger:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideofiltre:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Lyd&amp;filtre:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="89"/>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="90"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="91"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="98"/>
        <source>O&amp;ptions for %1</source>
        <translation>I&amp;nnstillinger for %1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="99"/>
        <source>Additional Options for %1</source>
        <translation>Ekstra innstillinger for %1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="100"/>
        <source>Here you can pass extra options to %1.</source>
        <translation>Her kan du overlate ekstra innstillinger til %1.</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="101"/>
        <source>Write them separated by spaces.</source>
        <translation>Skriv dem med mellomrom mellom dem.</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="101"/>
        <source>Example:</source>
        <translation>Eksempel:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="30"/>
        <source>Hash and filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Aktiver eller deaktiver bruken av en proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="37"/>
        <source>The host name of the proxy.</source>
        <translation>Proxyens vertsnavn.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>The port of the proxy.</source>
        <translation>Proxyens port.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="39"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Hvis proxyen krever pålogging, vil dette velge brukernavnet.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="41"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Proxyens passord. &lt;b&gt;Advarsel:&lt;/b&gt; passordet vil bli lagret som ren tekst i konfigurasjonsfilen.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="43"/>
        <source>Select the proxy type to be used.</source>
        <translation>Velg proxytypen som skal brukes.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="227"/>
        <source>Server</source>
        <translation>Server</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="235"/>
        <source>&amp;OpenSubtitles server:</source>
        <translation>&amp;OpenSubtitles-server:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="113"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="20"/>
        <source>General</source>
        <translation type="unfinished">Generelt</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="28"/>
        <source>Search &amp;method:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="66"/>
        <source>Opensubtitles Credentials</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="119"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Aktiver proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="132"/>
        <source>&amp;Host:</source>
        <translation>&amp;Vert:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="145"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="74"/>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="165"/>
        <source>&amp;Username:</source>
        <translation>&amp;Brukernavn:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="91"/>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="178"/>
        <source>Pa&amp;ssword:</source>
        <translation>Pa&amp;ssord:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="195"/>
        <source>&amp;Type:</source>
        <translation>&amp;Type:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="56"/>
        <source>A&amp;ppend language code to the subtitle filename</source>
        <translation>Tilknytt språkkode til undertekstfilnavnet</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="252"/>
        <source>Number of &amp;retries:</source>
        <translation>Antall &amp;forsøk:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Files</source>
        <translation>Filer</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Uploaded by</source>
        <translation>Lastet opp av</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="274"/>
        <source>Portuguese - Brasil</source>
        <translation>Portugisisk for Brasil</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="269"/>
        <source>Spanish - Spain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="247"/>
        <source>Spanish</source>
        <translation type="unfinished">Spansk</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="251"/>
        <source>Portuguese</source>
        <translation type="unfinished">Portugisisk</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="270"/>
        <source>Spanish - Latin America</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="282"/>
        <source>All</source>
        <translation>Alle</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="291"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Subtitles service powered by %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="405"/>
        <source>Connecting...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="415"/>
        <source>Login to opensubtitles.org has failed</source>
        <translation>Pålogging til opensubtitles.org mislyktes</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="419"/>
        <source>Search has failed</source>
        <translation>Søket mislyktes</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="584"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="586"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="667"/>
        <source>Error fixing the subtitle lines</source>
        <translation>Feil ved korrigering av undertekstlinjene</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>&amp;Download</source>
        <translation>&amp;Last ned</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="296"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Kopier lenke til utklippstavle</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="399"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="400"/>
        <source>Download failed: %1.</source>
        <translation>Nedlasting mislyktes: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="429"/>
        <source>Downloading...</source>
        <translation>Laster ned...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="437"/>
        <source>Done.</source>
        <translation>Ferdig.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="483"/>
        <source>%1 files available</source>
        <translation>%1 filer er tilgjengelig</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="492"/>
        <source>Failed to parse the received data.</source>
        <translation>Klarte ikke å tolke den mottatte dataen.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="14"/>
        <source>Find Subtitles</source>
        <translation>Finn undertekster</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="28"/>
        <source>&amp;Video file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="49"/>
        <source>Search for &amp;title:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="59"/>
        <source>Type here a movie or TV show title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="66"/>
        <source>&amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Språk:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Oppfrisk</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="603"/>
        <source>Subtitle saved as %1</source>
        <translation>Undertekst lagret som %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="598"/>
        <source>Error saving file</source>
        <translation>Feil ved lagring av fil</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="599"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Det var ikke mulig å lagre den nedlastede
filen i %1-mappen
Vennligst sjekk mappens tillatelser.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="397"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="554"/>
        <source>Download failed</source>
        <translation>Nedlasting mislyktes</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Innstillinger</translation>
    </message>
</context>
<context>
    <name>FontCacheDialog</name>
    <message>
        <location filename="../fontcache.cpp" line="27"/>
        <source>SMPlayer is initializing</source>
        <translation>SMPlayer starter opp</translation>
    </message>
    <message>
        <location filename="../fontcache.cpp" line="28"/>
        <source>Creating a font cache...</source>
        <translation>Oppretter et fontmellomlager...</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsDialog</name>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="23"/>
        <source>Select the multimedia keys that SMPlayer will capture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="35"/>
        <source>Media &amp;Play</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="42"/>
        <source>Media &amp;Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="49"/>
        <source>Media Pre&amp;vious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="56"/>
        <source>Media &amp;Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="63"/>
        <source>Media P&amp;ause</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="97"/>
        <source>Media &amp;Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="104"/>
        <source>Volume &amp;Mute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="111"/>
        <source>Volume &amp;Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="118"/>
        <source>Volume &amp;Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.cpp" line="26"/>
        <source>Global Shortcuts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="78"/>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="82"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="82"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="86"/>
        <source>URL</source>
        <translation>Nettadresse</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="93"/>
        <source>Length</source>
        <translation>Lengde</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="94"/>
        <source>Demuxer</source>
        <translation>Demultiplekser</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <location filename="../infofile.cpp" line="141"/>
        <location filename="../infofile.cpp" line="170"/>
        <location filename="../infofile.cpp" line="190"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="100"/>
        <source>Artist</source>
        <translation>Artist</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Author</source>
        <translation>Skaper</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="103"/>
        <source>Genre</source>
        <translation>Sjanger</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Date</source>
        <translation>Dato</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Spor</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Opphavsrett</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Programvare</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="121"/>
        <source>Clip info</source>
        <translation>Klippinfo</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="129"/>
        <source>Resolution</source>
        <translation>Oppløsning</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Aspect ratio</source>
        <translation>Visningsaspekt</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <location filename="../infofile.cpp" line="160"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <location filename="../infofile.cpp" line="161"/>
        <source>Bitrate</source>
        <translation>Bitfrekvens</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <location filename="../infofile.cpp" line="161"/>
        <source>%1 kbps</source>
        <translation>%1 Kb/s</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <source>Frames per second</source>
        <translation>Bilder i sekundet</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="164"/>
        <source>Selected codec</source>
        <translation>Valgt kodek</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="140"/>
        <source>Video Streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="159"/>
        <source>Initial Audio Stream</source>
        <translation>Første lydstrøm</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="162"/>
        <source>Rate</source>
        <translation>Frekvens</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="162"/>
        <source>%1 Hz</source>
        <translation>%1Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="163"/>
        <source>Channels</source>
        <translation>Kanaler</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="169"/>
        <source>Audio Streams</source>
        <translation>Lydstrømmer</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <location filename="../infofile.cpp" line="170"/>
        <location filename="../infofile.cpp" line="190"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="248"/>
        <source>Track %1</source>
        <translation>Spor %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="251"/>
        <location filename="../infofile.cpp" line="259"/>
        <source>Language: %1</source>
        <translation>Språk: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="252"/>
        <location filename="../infofile.cpp" line="260"/>
        <source>Name: %1</source>
        <translation>Navn: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="253"/>
        <location filename="../infofile.cpp" line="261"/>
        <source>ID: %1</source>
        <translation>ID: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="255"/>
        <location filename="../infofile.cpp" line="263"/>
        <source>Type: %1</source>
        <translation>Type: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="189"/>
        <source>Subtitles</source>
        <translation>Undertekster</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="128"/>
        <source>Initial Video Stream</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="190"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Kringkastingstittel</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Kringkastingens nettadresse</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="81"/>
        <source>File</source>
        <translation>Fil</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../infowindow.ui" line="36"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
</context>
<context>
    <name>InputBookmark</name>
    <message>
        <location filename="../inputbookmark.ui" line="14"/>
        <source>Add new bookmark</source>
        <translation>Legg til nytt bokmerke</translation>
    </message>
    <message>
        <location filename="../inputbookmark.ui" line="22"/>
        <source>&amp;Time:</source>
        <translation>&amp;Tid:</translation>
    </message>
    <message>
        <location filename="../inputbookmark.ui" line="48"/>
        <source>&amp;Name (optional):</source>
        <translation>&amp;Navn (valgfritt):</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="43"/>
        <source>Choose a directory</source>
        <translation>Velg en plassering</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="13"/>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer - Spill av en DVD fra en mappe</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="36"/>
        <source>You can play a DVD from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Du kan spille av en DVD fra harddisken din. Du trenger bare velge mappen som har VIDEO_TS- og AUDIO_TS-direktivene du ønsker.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="69"/>
        <source>Choose a directory...</source>
        <translation>Velg en plassering...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="14"/>
        <source>SMPlayer - Enter the MPlayer version</source>
        <translation>SMPlayer - Gå til MPlayer-versjonen</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="35"/>
        <source>SMPlayer couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>SMPlayer kunne ikke identifisere MPlayer-versjonen du bruker.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="58"/>
        <source>Version reported by MPlayer:</source>
        <translation>Versjonen ifølge MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="102"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Vennligst &amp;velg den riktige versjonen:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="113"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 eller eldre</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="118"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="123"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 eller nyere</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="13"/>
        <source>SMPlayer - Enter URL</source>
        <translation>SMPlayer - Skriv inn nettadresse</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="64"/>
        <source>&amp;URL:</source>
        <translation>&amp;Nettadresse:</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="24"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="25"/>
        <source>Abkhazian</source>
        <translation>Abkhasisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Amharic</source>
        <translation>Amharisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <location filename="../languages.cpp" line="310"/>
        <source>Arabic</source>
        <translation>Arabisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Assamese</source>
        <translation>Assamesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Azerbaijani</source>
        <translation>Aserbaijansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Bashkir</source>
        <translation>Basjkirsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <location filename="../languages.cpp" line="336"/>
        <source>Bulgarian</source>
        <translation>Bulgarsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bengali</source>
        <translation>Bengalsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Tibetan</source>
        <translation>Tibetansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Breton</source>
        <translation>Bretonsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Catalan</source>
        <translation>Katalansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Corsican</source>
        <translation>Korsikansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <location filename="../languages.cpp" line="337"/>
        <source>Czech</source>
        <translation>Tsjekkisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <source>Welsh</source>
        <translation>Walisisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Danish</source>
        <translation>Dansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <location filename="../languages.cpp" line="224"/>
        <source>German</source>
        <translation>Tysk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Greek</source>
        <translation>Gresk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Engelsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Spansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="338"/>
        <source>Estonian</source>
        <translation>Estisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Basque</source>
        <translation>Baskisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <source>Persian</source>
        <translation>Persisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Finnish</source>
        <translation>Finsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Faroese</source>
        <translation>Færøysk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="228"/>
        <source>French</source>
        <translation>Fransk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Frisian</source>
        <translation>Frisisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Irish</source>
        <translation>Irsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Galician</source>
        <translation>Galisisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Guarani</source>
        <translation>Guaraní</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Hebrew</source>
        <translation>Hebraisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <location filename="../languages.cpp" line="339"/>
        <source>Croatian</source>
        <translation>Kroatisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <location filename="../languages.cpp" line="340"/>
        <source>Hungarian</source>
        <translation>Ungarsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Armenian</source>
        <translation>Armensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Indonesian</source>
        <translation>Indonesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Icelandic</source>
        <translation>Islandsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Italian</source>
        <translation>Italiensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <location filename="../languages.cpp" line="230"/>
        <source>Japanese</source>
        <translation>Japansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <source>Javanese</source>
        <translation>Javanesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Georgian</source>
        <translation>Georgisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kazakh</source>
        <translation>Kasakhstansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Greenlandic</source>
        <translation>Grønlandsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Korean</source>
        <translation>Koreansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kashmiri</source>
        <translation>Kasjmiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <source>Kurdish</source>
        <translation>Kurdisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <source>Kirghiz</source>
        <translation>Kirgisisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Latin</source>
        <translation>Latinsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <location filename="../languages.cpp" line="341"/>
        <source>Lithuanian</source>
        <translation>Litauisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <location filename="../languages.cpp" line="342"/>
        <source>Latvian</source>
        <translation>Latvisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <source>Malagasy</source>
        <translation>Madagassisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Maori</source>
        <translation>Maorisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Macedonian</source>
        <translation>Makedonsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Mongolian</source>
        <translation>Mongolsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <source>Moldavian</source>
        <translation>Rumensk for Moldova</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Malay</source>
        <translation>Malayisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Maltese</source>
        <translation>Maltesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Burmese</source>
        <translation>Burmesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Nauru</source>
        <translation>Naurisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>BokmÃ¥l</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Nepali</source>
        <translation>Nepalsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Dutch</source>
        <translation>Nederlandsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian Nynorsk</source>
        <translation>Nynorsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="146"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Norwegian</source>
        <translation>Norsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Occitan</source>
        <translation>Oksitansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <location filename="../languages.cpp" line="343"/>
        <source>Polish</source>
        <translation>Polsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Portuguese</source>
        <translation>Portugisisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <source>Romanian</source>
        <translation>Rumensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <location filename="../languages.cpp" line="234"/>
        <location filename="../languages.cpp" line="317"/>
        <location filename="../languages.cpp" line="344"/>
        <source>Russian</source>
        <translation>Russisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sanskrit</source>
        <translation>Sanskrit</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sindhi</source>
        <translation>Sindhī</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="345"/>
        <source>Slovak</source>
        <translation>Slovakisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Samoan</source>
        <translation>Samoansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Somali</source>
        <translation>Somalisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <source>Albanian</source>
        <translation>Albansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Serbian</source>
        <translation>Serbisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <source>Sundanese</source>
        <translation>Sundanesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Swedish</source>
        <translation>Svensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Tamil</source>
        <translation>Tamilsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Tajik</source>
        <translation>Tadsjikisk persisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Thai</source>
        <translation>Thailandsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Tigrinya</source>
        <translation>Tigrinja</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Turkmen</source>
        <translation>Turkmensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <source>Tonga</source>
        <translation>Tongansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <location filename="../languages.cpp" line="312"/>
        <source>Turkish</source>
        <translation>Tyrkisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Tatar</source>
        <translation>Tatarsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <source>Uighur</source>
        <translation>Uigursk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <location filename="../languages.cpp" line="347"/>
        <source>Ukrainian</source>
        <translation>Ukrainsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Uzbek</source>
        <translation>Usbekisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="203"/>
        <source>Vietnamese</source>
        <translation>Vietnamesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>VolapÃ¼k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="212"/>
        <source>Yiddish</source>
        <translation>Jiddisch</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="213"/>
        <source>Yoruba</source>
        <translation>Joruba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="214"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="215"/>
        <location filename="../languages.cpp" line="236"/>
        <location filename="../languages.cpp" line="348"/>
        <source>Chinese</source>
        <translation>Kinesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="216"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="245"/>
        <source>Arabic - Syria</source>
        <translation>Arabisk for Syria</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="302"/>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="303"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="304"/>
        <source>Western European Languages</source>
        <translation>Vest-europeiske språk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="305"/>
        <source>Western European Languages with Euro</source>
        <translation>Vest-europeiske språk med €-tegnet</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="306"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slaviske / Sentral-europeiske språk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="307"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, galisisk, maltesisk, tyrkisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="308"/>
        <source>Old Baltic charset</source>
        <translation>Gammelt baltisk tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="309"/>
        <source>Cyrillic</source>
        <translation>Kyrillisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="311"/>
        <source>Modern Greek</source>
        <translation>Moderne gresk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="313"/>
        <source>Baltic</source>
        <translation>Baltisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="314"/>
        <source>Celtic</source>
        <translation>Keltisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="315"/>
        <source>South-Eastern European</source>
        <translation>Sørøst-europeisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="316"/>
        <source>Hebrew charsets</source>
        <translation>Hebraiske tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="318"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainsk og hviterussisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="319"/>
        <source>Simplified Chinese charset</source>
        <translation>Forenklet kinesisk tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="320"/>
        <source>Traditional Chinese charset</source>
        <translation>Tradisjonelt kinesisk tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="321"/>
        <source>Japanese charsets</source>
        <translation>Japanske tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="322"/>
        <source>Korean charset</source>
        <translation>Koreansk tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="323"/>
        <source>Thai charset</source>
        <translation>Thailandsk tegnsett</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="324"/>
        <source>Cyrillic Windows</source>
        <translation>Kyrillisk (Windows)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="325"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slavisk / Sentral-europeisk (Windows)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="326"/>
        <source>Arabic Windows</source>
        <translation>Arabisk (Windows)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="26"/>
        <source>Avestan</source>
        <translation>Avestansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Aragonese</source>
        <translation>Aragonesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Avaric</source>
        <translation>Avarisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <location filename="../languages.cpp" line="335"/>
        <source>Belarusian</source>
        <translation>Hviterussisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <source>Bambara</source>
        <translation>Bambara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bosnian</source>
        <translation>Bosnisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Chechen</source>
        <translation>Tsjetsjensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <source>Cree</source>
        <translation>Cree</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Church</source>
        <translation>Kirkeslavisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Chuvash</source>
        <translation>Tsjuvasjisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Divehi</source>
        <translation>Dhivehi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Dzongkha</source>
        <translation>Dzongkha</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <source>Fulah</source>
        <translation>Fulfulde</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Fijian</source>
        <translation>Fijiansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <source>Gaelic</source>
        <translation>Skotsk-gælisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <source>Manx</source>
        <translation>Mansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hiri</source>
        <translation>Hiri motu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Haitian</source>
        <translation>Haitisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <source>Chamorro</source>
        <translation>Chamorro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Sichuan</source>
        <translation>Sichuansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Inupiaq</source>
        <translation>Inupiak</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Kikuyu</source>
        <translation>Kikuyu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <source>Kuanyama</source>
        <translation>Kwanyama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Kanuri</source>
        <translation>Kanuri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Komi</source>
        <translation>Syrjensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Cornish</source>
        <translation>Kornisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Luxembourgish</source>
        <translation>Luxemburgisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Ganda</source>
        <translation>Luganda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Limburgan</source>
        <translation>Limburgsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Lao</source>
        <translation>Laotisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Luba-Katanga</source>
        <translation>Luba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Marshallese</source>
        <translation>Marshallesisk</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Bokmål</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <location filename="../languages.cpp" line="147"/>
        <source>Ndebele</source>
        <translation>Ndebele</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <source>Ndonga</source>
        <translation>Ndonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Navajo</source>
        <translation>Navajo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Chichewa</source>
        <translation>Chichewa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Ojibwa</source>
        <translation>Ojibwa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oromo</source>
        <translation>Oromo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Ossetian</source>
        <translation>Ossetisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Panjabi</source>
        <translation>Panjabi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Pushto</source>
        <translation>Pashto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Romansh</source>
        <translation>Retoromansk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <source>Rundi</source>
        <translation>Kirundi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sardinian</source>
        <translation>Sardinisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sami</source>
        <translation>Samisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <source>Sinhala</source>
        <translation>Singalesisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <location filename="../languages.cpp" line="346"/>
        <source>Slovene</source>
        <translation>Slovensk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Swati</source>
        <translation>Swati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sotho</source>
        <translation>Sesotho</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tswana</source>
        <translation>Tswana</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Tahitian</source>
        <translation>Tahitisk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <source>Venda</source>
        <translation>TshiVenda</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="207"/>
        <source>Volapük</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Walloon</source>
        <translation>Vallonsk</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="327"/>
        <source>Modern Greek Windows</source>
        <translation>Moderne gresk (Windows)</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="107"/>
        <source>Choose a filename to save under</source>
        <translation>Velg et filnavn å lagre som</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Confirm overwrite?</source>
        <translation>Vil du bekrefte overskrivingen?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="114"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Denne filen finnes allerere.
Vil du overskrive den?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="133"/>
        <source>Error saving file</source>
        <translation>Feil ved lagring av fil</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="134"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Loggboken kunne ikke lagres</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="108"/>
        <source>Logs</source>
        <translation>Loggbøker</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="58"/>
        <location filename="../logwindow.ui" line="61"/>
        <source>Save</source>
        <translation>Lagre</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="68"/>
        <location filename="../logwindow.ui" line="71"/>
        <source>Copy to clipboard</source>
        <translation>Kopier til utklippstavle</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="78"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="81"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
</context>
<context>
    <name>MPVProcess</name>
    <message>
        <location filename="../mpvoptions.cpp" line="203"/>
        <location filename="../mpvprocess.h" line="208"/>
        <source>the &apos;%1&apos; filter is not supported by mpv</source>
        <translation>&apos;%1&apos;-filteret støttes ikke av mpv</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="929"/>
        <location filename="../mpvprocess.h" line="209"/>
        <source>File:</source>
        <translation>Fil:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="932"/>
        <location filename="../mpvprocess.h" line="210"/>
        <source>Video:</source>
        <translation>Video:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="933"/>
        <location filename="../mpvprocess.h" line="211"/>
        <source>Resolution:</source>
        <translation>Oppløsning:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="934"/>
        <location filename="../mpvprocess.h" line="212"/>
        <source>Frames per second:</source>
        <translation>Bilder i sekundet:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="934"/>
        <location filename="../mpvprocess.h" line="213"/>
        <source>Estimated:</source>
        <translation>Antatt:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="936"/>
        <location filename="../mpvprocess.h" line="214"/>
        <source>Aspect Ratio:</source>
        <translation>Visningsaspekt:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="937"/>
        <location filename="../mpvoptions.cpp" line="942"/>
        <location filename="../mpvprocess.h" line="215"/>
        <location filename="../mpvprocess.h" line="218"/>
        <source>Bitrate:</source>
        <translation>Bitfrekvens:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="938"/>
        <location filename="../mpvprocess.h" line="216"/>
        <source>Dropped frames:</source>
        <translation>Bilder hoppet over:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="941"/>
        <location filename="../mpvprocess.h" line="217"/>
        <source>Audio:</source>
        <translation>Lyd:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="943"/>
        <location filename="../mpvprocess.h" line="219"/>
        <source>Sample Rate:</source>
        <translation>Samplingsfrekvens:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="944"/>
        <location filename="../mpvprocess.h" line="220"/>
        <source>Channels:</source>
        <translation>Kanaler:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="947"/>
        <location filename="../mpvprocess.h" line="221"/>
        <source>Audio/video synchronization:</source>
        <translation>Synkronisering av lyd/video:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="950"/>
        <source>Cache (in seconds):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="951"/>
        <source>Cache speed:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mpvprocess.h" line="222"/>
        <source>Cache fill:</source>
        <translation>Mellomlagringsfyll:</translation>
    </message>
    <message>
        <location filename="../mpvprocess.h" line="223"/>
        <source>Used cache:</source>
        <translation>Brukt mellomlagring:</translation>
    </message>
</context>
<context>
    <name>MediaPanel</name>
    <message>
        <location filename="../skingui/mediapanel.cpp" line="246"/>
        <source>Shuffle playlist</source>
        <translation>Bland spilleliste</translation>
    </message>
    <message>
        <location filename="../skingui/mediapanel.cpp" line="247"/>
        <source>Repeat playlist</source>
        <translation>Gjenta spilleliste</translation>
    </message>
</context>
<context>
    <name>MiniGui</name>
    <message>
        <location filename="../minigui.cpp" line="181"/>
        <source>Control bar</source>
        <translation>Kontrollinje</translation>
    </message>
    <message>
        <location filename="../minigui.cpp" line="184"/>
        <source>Edit &amp;control bar</source>
        <translation>Rediger &amp;kontrollinje</translation>
    </message>
    <message>
        <location filename="../minigui.cpp" line="185"/>
        <source>Edit &amp;floating control</source>
        <translation>Rediger &amp;svevende kontroller</translation>
    </message>
</context>
<context>
    <name>MpcGui</name>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="150"/>
        <source>Control bar</source>
        <translation>Kontrollinje</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="151"/>
        <source>Seek bar</source>
        <translation>Spoleelinje</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="463"/>
        <location filename="../mpcgui/mpcgui.cpp" line="464"/>
        <location filename="../mpcgui/mpcgui.cpp" line="465"/>
        <source>-%1</source>
        <translation>-%1</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="467"/>
        <location filename="../mpcgui/mpcgui.cpp" line="468"/>
        <location filename="../mpcgui/mpcgui.cpp" line="469"/>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
</context>
<context>
    <name>MplayerProcess</name>
    <message>
        <location filename="../mplayeroptions.cpp" line="434"/>
        <location filename="../mplayeroptions.cpp" line="511"/>
        <source>This option is not supported by MPlayer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MultilineInputDialog</name>
    <message>
        <location filename="../multilineinputdialog.ui" line="13"/>
        <source>Enter URL(s)</source>
        <translation>Skriv inn nettadresse(r)</translation>
    </message>
    <message>
        <location filename="../multilineinputdialog.ui" line="19"/>
        <source>Enter the URL(s) to be added to the playlist. One per line.</source>
        <translation>Legg til nettadresse(ne) som skal legges til i spillelisten. Én per linje.</translation>
    </message>
</context>
<context>
    <name>OpenWithDeviceDialog</name>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="14"/>
        <source>Play on device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="20"/>
        <source>To play this video in a smartphone or tablet, scan the following QR code with your device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="46"/>
        <source>Or open this URL in your device&apos;s media player:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlayControl</name>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="186"/>
        <source>Rewind</source>
        <translation>Spol tilbake</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="187"/>
        <source>Forward</source>
        <translation>Spol fremover</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="188"/>
        <source>Play / Pause</source>
        <translation>Spill av / Pause</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="189"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="190"/>
        <source>Record</source>
        <translation>Spill inn</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="191"/>
        <source>Next file in playlist</source>
        <translation>Neste fil i spillelisten</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="192"/>
        <source>Previous file in playlist</source>
        <translation>Forrige fil i spillelisten</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Name</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Length</source>
        <translation>Lengde</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="730"/>
        <source>&amp;Play</source>
        <translation>&amp;Spill av</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="777"/>
        <source>&amp;Edit</source>
        <translation>&amp;Rediger</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1389"/>
        <location filename="../playlist.cpp" line="1425"/>
        <source>Playlists</source>
        <translation>Spillelister</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1387"/>
        <source>Choose a file</source>
        <translation>Velg en fil</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1423"/>
        <source>Choose a filename</source>
        <translation>Velg et filnavn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1435"/>
        <source>Confirm overwrite?</source>
        <translation>Vil du skrive over?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1436"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1-filen finnes allerede.
Vil du overskrive den?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1389"/>
        <location filename="../playlist.cpp" line="1425"/>
        <location filename="../playlist.cpp" line="1738"/>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="399"/>
        <source>Untitled playlist</source>
        <translation>Spilleliste uten navn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="722"/>
        <source>&amp;Load...</source>
        <translation>&amp;Last inn...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="724"/>
        <source>Load playlist from &amp;URL...</source>
        <translation>Last ned spilleliste fra &amp;nettadresse...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="763"/>
        <source>Play on Chromec&amp;ast</source>
        <translation>Spill av med en Chromec&amp;ast</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="765"/>
        <source>Open stream in &amp;a web browser</source>
        <translation>Spill av strømmen i &amp;en nettleser</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="781"/>
        <source>Load/Save</source>
        <translation>Last inn / Lagre</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1735"/>
        <source>Select one or more files to open</source>
        <translation>Velg en eller flere filer å åpne</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1804"/>
        <source>Choose a directory</source>
        <translation>Velg en plassering</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2001"/>
        <source>Edit name</source>
        <translation>Rediger navn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2002"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Skriv inn navnet som denne spillelisten vil vise denne filen som:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Filename / URL</source>
        <translation>Filnavn / Nettadresse</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Shuffle order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="725"/>
        <source>Download playlist from URL</source>
        <translation>Last ned spilleliste fra nettadresse</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="727"/>
        <source>&amp;Save</source>
        <translation>&amp;Lagre</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="728"/>
        <source>Save &amp;as...</source>
        <translation>Lagre &amp;som...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="732"/>
        <source>&amp;Next</source>
        <translation>&amp;Neste</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="733"/>
        <source>Pre&amp;vious</source>
        <translation>For&amp;rige</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="739"/>
        <source>Move &amp;up</source>
        <translation>Gå &amp;opp</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="740"/>
        <source>Move &amp;down</source>
        <translation>Gå &amp;ned</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="742"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Gjenta</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="743"/>
        <source>S&amp;huffle</source>
        <translation>B&amp;land</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="746"/>
        <source>Add &amp;current file</source>
        <translation>Legg til &amp;nåværende fil</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="747"/>
        <source>Add &amp;file(s)</source>
        <translation>Legg til &amp;fil(er)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="748"/>
        <source>Add &amp;directory</source>
        <translation>Legg til &amp;plassering</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="749"/>
        <source>Add &amp;URL(s)</source>
        <translation>Legg til &amp;nettadresse(r)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="752"/>
        <source>Remove &amp;selected</source>
        <translation>Fjern &amp;valgte</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="753"/>
        <source>Remove &amp;all</source>
        <translation>Fjern &amp;alle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="756"/>
        <source>&amp;Delete file from disk</source>
        <translation>&amp;Slett fil fra harddisk</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="759"/>
        <location filename="../playlist.cpp" line="1533"/>
        <source>&amp;Copy file path to clipboard</source>
        <translation>&amp;Kopier filbanen til utklippstavlen</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="760"/>
        <source>&amp;Open source folder</source>
        <translation>&amp;Åpne kildemappen</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="768"/>
        <location filename="../playlist.cpp" line="789"/>
        <source>Search</source>
        <translation>Søk</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="770"/>
        <source>Show position column</source>
        <translation>Vis posisjonskolonne</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="771"/>
        <source>Show name column</source>
        <translation>Vis navnekolonne</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="772"/>
        <source>Show length column</source>
        <translation>Vis varighetskolonne</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="773"/>
        <source>Show filename column</source>
        <translation>Vis filnavnkolonne</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="774"/>
        <source>Show shuffle column</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1538"/>
        <source>&amp;Copy URL to clipboard</source>
        <translation>&amp;Kopier nettadressen til utklippstavlen</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2039"/>
        <source>Confirm deletion</source>
        <translation>Bekreft sletting</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2040"/>
        <source>You&apos;re about to DELETE the file &apos;%1&apos; from your drive.</source>
        <translation>Du er i ferd med å SLETTE &apos;%1&apos;-filen fra harddisken din.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2041"/>
        <source>This action cannot be undone. Are you sure you want to proceed?</source>
        <translation>Denne handlingen kan ikke omgjøres. Er du sikker på at du vil gå videre?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2059"/>
        <source>Deletion failed</source>
        <translation>Sletting mislyktes</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2060"/>
        <source>It wasn&apos;t possible to delete &apos;%1&apos;</source>
        <translation>Det var ikke mulig å slette &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2065"/>
        <source>Error deleting the file</source>
        <translation>Feil ved sletting av fil</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2066"/>
        <source>It&apos;s not possible to delete &apos;%1&apos; from the filesystem.</source>
        <translation>Det er ikke mulig å slette &apos;%1&apos; fra filsystemet.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2553"/>
        <source>It&apos;s not possible to load this playlist</source>
        <translation>Det er ikke mulig å laste inn denne spillelisten</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2553"/>
        <source>Unrecognized format.</source>
        <translation>Ugjenkjennelig format.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="783"/>
        <source>Add...</source>
        <translation>Legg til...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="785"/>
        <source>Remove...</source>
        <translation>Fjern...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1468"/>
        <source>Playlist modified</source>
        <translation>Spilleliste endret</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1469"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Det er blitt gjort ulagrede endringer, vil du lagre spillelisten?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1737"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
</context>
<context>
    <name>PrefAdvanced</name>
    <message>
        <location filename="../prefadvanced.cpp" line="79"/>
        <location filename="../prefadvanced.cpp" line="455"/>
        <source>Advanced</source>
        <translation>Avansert</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="92"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="24"/>
        <source>&amp;Advanced</source>
        <translation>&amp;Avansert</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="568"/>
        <source>Log SMPlayer output</source>
        <translation>Loggfør SMPlayer-utdata</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="653"/>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Denne innstillingen er hovedsaklig ment for avlusing av programmet.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="599"/>
        <source>Filter for SMPlayer logs</source>
        <translation>Filter for SMPlayer-loggføringer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="48"/>
        <source>&amp;Monitor aspect:</source>
        <translation>Skjerm&amp;aspekt:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="112"/>
        <source>Use the la&amp;vf demuxer by default</source>
        <translation>Bruk la&amp;vf-demultiplekseren som standard</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="200"/>
        <source>O&amp;SD bar position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="238"/>
        <source>Display the name o&amp;f the media in the window title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="253"/>
        <source>Color&amp;key:</source>
        <translation>Farge&amp;nøkkel:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="351"/>
        <source>&amp;Options:</source>
        <translation>&amp;Alternativer:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="377"/>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideofiltre:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="586"/>
        <source>SMPlayer</source>
        <translation>SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="592"/>
        <source>Log &amp;SMPlayer output</source>
        <translation>Loggfør &amp;SMPlayer-utdata</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="663"/>
        <source>&amp;Filter for SMPlayer logs:</source>
        <translation>&amp;Filter for SMPlayer-loggføringer:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="276"/>
        <source>C&amp;hange...</source>
        <translation>E&amp;ndre...</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="565"/>
        <source>Logs</source>
        <translation>Loggbøker</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="457"/>
        <source>Monitor aspect</source>
        <translation>Skjermaspekt</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="458"/>
        <source>Select the aspect ratio of your monitor.</source>
        <translation>Velg visningsaspektet til skjermen din.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="467"/>
        <source>Use the lavf demuxer by default</source>
        <translation>Bruk lavf-demultiplekseren som standard</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="468"/>
        <source>If this option is checked, the lavf demuxer will be used for all formats.</source>
        <translation>Hvis dette alternativet er valgt, vil lavf-demultiplekseren bli brukt til alle formater.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="545"/>
        <source>This option may be needed to play playlist files (m3u, pls...). However it can involve a security risk when playing internet sources because the way MPlayer parses and uses playlist files is not safe against maliciously constructed files.</source>
        <translation>Denne innstillingen kan være nødvendig for å spille av spillelistefiler (m3u, pls...). Derimot kan utgjøre en sikkerhetsrisiko ved avspilling av internettmateriale, siden måten MPlayer analyserer og deretter bruker spillelistefiler ikke er sikret mot ondskapsfulle filer.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="496"/>
        <source>Limitation: the actions are run only when a file is opened and not when the %1 process is restarted (e.g. you select an audio or video filter).</source>
        <translation>Begrensning: Handlingene blir kun kjørt når en fil blir åpnet, og ikke når %1-prosessen startes på nytt (altså når du velger et lyd- eller video-filter).</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="508"/>
        <source>Colorkey</source>
        <translation>Fargenøkkel</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="509"/>
        <source>If you see parts of the video over any other window, you can change the colorkey to fix it. Try to select a color close to black.</source>
        <translation>Hvis deler av videoen vises over et annet vindu, kan du endre fargenøkkelen for å fikse det. Prøv å velge en farge som ligger nært  svart.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="517"/>
        <source>Options</source>
        <translation>Innstillinger</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="521"/>
        <source>Video filters</source>
        <translation>Videofiltre</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="525"/>
        <source>Audio filters</source>
        <translation>Lydfiltre</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="472"/>
        <source>Repaint the background of the video window</source>
        <translation>Fargelegg bakgrunnen til videovinduet på nytt</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="119"/>
        <source>Repaint the backgroun&amp;d of the video window</source>
        <translation>Fargelegg bakgrunne&amp;n til videovinduet på nytt</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="559"/>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="560"/>
        <source>Use IPv4 on network connections. Falls back on IPv6 automatically.</source>
        <translation>Bruk IPv4 for nettverkstilkoblinger. Automatisk tilbakefall på IPv6.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="562"/>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="563"/>
        <source>Use IPv6 on network connections. Falls back on IPv4 automatically.</source>
        <translation>Bruk IPv6 for nettverkstikoblinger. Automatisk tilbakefall på IPv4.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="472"/>
        <source>Network Connection</source>
        <translation>Nettverkstilkobling</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="484"/>
        <source>IPv&amp;4</source>
        <translation>IPv&amp;4</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="491"/>
        <source>IPv&amp;6</source>
        <translation>IPv&amp;6</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="515"/>
        <source>Lo&amp;gs</source>
        <translation>Lo&amp;ggbøker</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="460"/>
        <source>Rebuild index if needed</source>
        <translation>Gjenopprett indeksen hvis det trengs</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="105"/>
        <source>Rebuild &amp;index if needed</source>
        <translation>Gjenopprett &amp;indeksen hvis det trengs</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="569"/>
        <source>If this option is checked, SMPlayer will store the debugging messages that SMPlayer outputs (you can see the log in &lt;b&gt;Options -&gt; View logs -&gt; SMPlayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer lagre avlusingsbeskjedene som SMPlayer sender ut (Du kan se loggen i &lt;b&gt;Innstillinger → Se logger → SMPlayer&lt;/b&gt;). Denne informasjonen kan bli veldig nyttig for utviklerne dersom du støter på en programfeil.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="581"/>
        <source>Log %1 output</source>
        <translation>Loggfør %1 utdataer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="582"/>
        <source>If checked, SMPlayer will store the output of %1 (you can see it in &lt;b&gt;Options -&gt; View logs -&gt; %1&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Hvis dette er valgt, vil SMPlayer lagre utdataen til %1 (Du kan se den i &lt;b&gt;Innstillinger → Se logger → %1&lt;/b&gt;). I tilfelle problemer oppstår, kan denne loggen inneholde viktig informasjon, så det er anbefalt å ha dette alternativet valgt.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="587"/>
        <source>Autosave %1 log</source>
        <translation>Autolagre %1 logg</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="588"/>
        <source>If this option is checked, the %1 log will be saved to the specified file every time a new file starts to play. It&apos;s intended for external applications, so they can get info about the file you&apos;re playing.</source>
        <translation>Hvis denne innstillingen er valgt, vil %1-loggen bli lagret til den bestemte filen hver gang en ny fil blir spilt av. Det er laget med eksterne programmer i tankene, sånn at de kan hente info om filen du spiller av.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="593"/>
        <source>Autosave %1 log filename</source>
        <translation>Autolagre %1 loggfilnavn</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="594"/>
        <source>Enter here the path and filename that will be used to save the %1 log.</source>
        <translation>Velg filbanen og filnavnet som skal brukes til å lagre %1-loggen.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="600"/>
        <source>This option allows to filter the SMPlayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Denne innstillinger tillater å filtrere SMPlayer-beskjedene som blir lagret i loggen. Her kan du skrive ethvert ordinært uttrykk.&lt;br&gt;For eksempel: &lt;i&gt;^Core:::.*&lt;/i&gt; vil kun vise de linjene som starter med &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="478"/>
        <source>Correct pts</source>
        <translation>Korrekt visningstidsstempel</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="94"/>
        <source>&amp;Run %1 in its own window</source>
        <translation>&amp;Kjør %1 i et eget vindu</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="95"/>
        <source>&amp;Pass short filenames (8+3) to %1</source>
        <translation>&amp;Overlat korte filnavn (8+3) til %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="519"/>
        <source>Write them separated by spaces.</source>
        <translation>Skriv dem med mellomrom mellom dem.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="101"/>
        <source>Log %1 &amp;output</source>
        <translation>Loggfør %1-&amp;utdataer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="96"/>
        <source>Notify %1 crash&amp;es</source>
        <translation>Meld fra om %1-krasj&amp;er</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="99"/>
        <source>Here you can pass options and filters to %1.</source>
        <translation>Her kan du overlate innstillinger og filtre til %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="102"/>
        <source>A&amp;utosave %1 log to file</source>
        <translation>Autolagre %1 logg som fil</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="104"/>
        <source>Pa&amp;ss the %1 option to MPlayer (security risk)</source>
        <translation>Over&amp;lat &quot;%1&quot;-innstillingen til MPlayer (sikkerhetsrisiko)</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="473"/>
        <source>Unchecking this option may reduce flickering, but it can also produce strange artifacts under certain circumstances.</source>
        <translation>Å velge denne innstillingen kan redusere flimring, men det kan også forårsake rare artifakter under enkelte omstendigheter.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="500"/>
        <source>OSD bar position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="501"/>
        <source>Set the position of the screen where the OSD bar is displayed. 0 is top, 100 bottom.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="503"/>
        <source>Display the name of the media in the window title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="504"/>
        <source>If this option is enabled the media title from information tags will be displayed in the window title instead of the filename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="529"/>
        <source>Run %1 in its own window</source>
        <translation>Kjør %1 i et eget vindu</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="530"/>
        <source>If you check this option, the %1 video window won&apos;t be embedded in SMPlayer&apos;s main window but instead it will use its own window. Note that mouse and keyboard events will be handled directly by %1, that means key shortcuts and mouse clicks probably won&apos;t work as expected when the %1 window has the focus.</source>
        <translation>Hvis du velger denne innstillingen, vil %1-videovinduet ikke bli bygd inn i SMPlayers hovedvindu, men vil derimot bruke sitt eget vindu. Bemerk at mus- og tastatur-hendelser vil bli håndtert direkte av %1, som betyr at tastatursnarveier og museklikk kanskje ikke fungerer som forventet når %1-vinduet er i fokus.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="538"/>
        <source>Notify %1 crashes</source>
        <translation>Meld fra om %1-krasjer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="539"/>
        <source>If this option is checked, a popup window will be displayed to inform about %1 crashes. Otherwise those failures will be silently ignored.</source>
        <translation>Hvis dette alternativet er valgt, vil et oppsprettsvindu dukke opp for å fortelle deg om %1 krasj. Hvis ikke, vil feilene bli stille ignorert.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="552"/>
        <source>Pass short filenames (8+3) to %1</source>
        <translation>Overlat korte filnavn (8+3) til %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="553"/>
        <source>If this option is checked, SMPlayer will pass to %1 the short version of the filenames.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer overlate kortversjonen av filnavnene til %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="544"/>
        <source>Pass the %1 option to MPlayer (security risk)</source>
        <translation>Overlat &quot;%1&quot;-innstillingen til MPlayer (sikkerhetsrisiko)</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="479"/>
        <source>Switches %1 to an experimental mode where timestamps for video frames are calculated differently and video filters which add new frames or modify timestamps of existing ones are supported. The more accurate timestamps can be visible for example when playing subtitles timed to scene changes with the SSA/ASS library enabled. Without correct pts the subtitle timing will typically be off by some frames. This option does not work correctly with some demuxers and codecs.</source>
        <translation>Plasserer %1 i en eksperimentell modus for tidsstemplene til videobilder kalkuleres annerledes, og videofiltre som legger til nye rammer eller som endrer på tidsstempler blir støttet. De mer nøyaktige tidsstemplene, kan være synlige for eksempel ved avspilling av undertekster som er synkronisert til sceneendringer med SSA/ASS-biblioteket aktivert. Uten et riktig tidsstempel vil undertekstvisningen ofte være noen bilder for sent ute. Denne innstillingen fungerer ikke riktig med noen demultipleksere og kodeker.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="488"/>
        <source>Actions list</source>
        <translation>Handlingsliste</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="489"/>
        <source>Here you can specify a list of &lt;i&gt;actions&lt;/i&gt; which will be run every time a file is opened. You&apos;ll find all available actions in the key shortcut editor in the &lt;b&gt;Keyboard and mouse&lt;/b&gt; section. The actions must be separated by spaces. Checkable actions can be followed by &lt;i&gt;true&lt;/i&gt; or &lt;i&gt;false&lt;/i&gt; to enable or disable the action.</source>
        <translation>Her kan du spesifisere en liste over &lt;i&gt;handlinger&lt;/i&gt; som skal kjøres hver gang en fil blir åpnet. Du kan finne alle de tilgjengelige handlingene i hurtigtastredigereren i &lt;b&gt;Tastatur og mus&lt;/b&gt;-seksjonen. Handlingene må være adskilt med mellomrom. Avkryssbare handlinger kan etterfølges av &lt;i&gt;true&lt;/i&gt; eller &lt;i&gt;false&lt;/i&gt; for å aktivere eller deaktivere handlingen.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="98"/>
        <source>Options for %1</source>
        <translation>Innstillinger for %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="518"/>
        <source>Here you can type options for %1.</source>
        <translation>Her kan du skrive inn innstillingene til %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="522"/>
        <source>Here you can add video filters for %1.</source>
        <translation>Her kan du legge til videofiltre til %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="523"/>
        <location filename="../prefadvanced.cpp" line="527"/>
        <source>Write them separated by commas. Don&apos;t use spaces!</source>
        <translation>Skriv dem med kommaer i mellom. Ikke bruk mellomrom!</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="526"/>
        <source>Here you can add audio filters for %1.</source>
        <translation>Her kan du legge til lydfiltre til %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="557"/>
        <source>Network</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="169"/>
        <source>R&amp;un the following actions every time a file is opened. The actions must be separated with spaces:</source>
        <translation>K&amp;jør de følgende handlingene hver gang en fil blir åpnet. Handlingene må være adskilt med mellomrom:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="403"/>
        <source>A&amp;udio filters:</source>
        <translation>L&amp;ydfiltre:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="466"/>
        <source>&amp;Network</source>
        <translation>&amp;Nettverk</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="495"/>
        <location filename="../prefadvanced.cpp" line="519"/>
        <location filename="../prefadvanced.cpp" line="523"/>
        <location filename="../prefadvanced.cpp" line="527"/>
        <source>Example:</source>
        <translation>Eksempel:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="461"/>
        <source>Rebuilds index of files if no index was found, allowing seeking. Useful with broken/incomplete downloads, or badly created files. This option only works if the underlying media supports seeking (i.e. not with stdin, pipe, etc).&lt;br&gt; &lt;b&gt;Note:&lt;/b&gt; the creation of the index may take some time.</source>
        <translation>Gjenoppbygger filindekser dersom ingen indekser ble funnet, noe som tillater hopping. Nyttig for ødelagte eller ufullførte nedlastinger, eller dårlig skapte filer. Denne innstillingen fungerer bare hvis det underliggende mediet støtter søking (altså ikke med stdin, pipe, osv.)&lt;br&gt; &lt;b&gt;Bemerk&lt;/b&gt; at opprettingen av indeksen kan ta litt tid.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="128"/>
        <source>C&amp;orrect PTS:</source>
        <translation>K&amp;orrekt visningstidsstempel:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="559"/>
        <source>&amp;Verbose</source>
        <translation>&amp;Detaljnivå</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="575"/>
        <source>Save SMPlayer log to file</source>
        <translation>Lagre SMPlayer-loggen i en fil</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="576"/>
        <source>If this option is checked, the SMPlayer log wil be recorded to %1</source>
        <translation>Hvis dette alternativet er valgt, vil SMPlayer-loggen bli lagret som %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="624"/>
        <source>Sa&amp;ve SMPlayer log to a file</source>
        <translation>La&amp;gre SMPlayer-loggen i en fil</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="204"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="205"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Ikke alle filtyper kunne tilknyttes. Vennligst sjekk dine sikkerhetstillatelser og prøv igjen.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="215"/>
        <source>File Types</source>
        <translation>Filtyper</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="232"/>
        <source>Select all</source>
        <translation>Velg alle</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="233"/>
        <source>Check all file types in the list</source>
        <translation>Velg alle filtypene på listen</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="236"/>
        <source>Uncheck all file types in the list</source>
        <translation>Avvelg alle filtypene på listen</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="238"/>
        <source>List of file types</source>
        <translation>Liste over filtyper</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="242"/>
        <source>Note:</source>
        <translation>Bemerk at</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="243"/>
        <source>Restoration doesn&apos;t work on Windows Vista.</source>
        <translation>gjenoppretting ikke fungerer med Windows Vista.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="26"/>
        <source>File types</source>
        <translation>Filtyper</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="38"/>
        <source>Media files handled by SMPlayer:</source>
        <translation>Mediefiler som håndteres av SMPlayer:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="91"/>
        <source>Select All</source>
        <translation>Velg alle</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="98"/>
        <source>Select None</source>
        <translation>Velg ingen</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="239"/>
        <source>Check the media file extensions you would like SMPlayer to handle. When you click Apply, the checked files will be associated with SMPlayer. If you uncheck a media type, the file association will be restored.</source>
        <translation>Kryss av på mediefilutvidelsene som du vil at SMPlayer skal håndtere. Når du trykker på Bruk, vil de avkryssede filene bli knyttet til SMPlayer. Hvis du avhuker en medietype, vil den filtilknyttingen bli tilbakestilt.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="235"/>
        <source>Select none</source>
        <translation>Velg ingen</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <location filename="../prefdrives.ui" line="27"/>
        <location filename="../prefdrives.cpp" line="73"/>
        <source>Drives</source>
        <translation>Lesere</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="219"/>
        <source>CD device</source>
        <translation>CD-enhet</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="220"/>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation>Velg din CDROM-enhet. Den vil også bli brukt til å spille av VCD-disker og lyd-CDer.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="223"/>
        <source>DVD device</source>
        <translation>DVD-enhet</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="224"/>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation>Velg din DVD-enhet. Den vil bli brukt til å spille av DVDer.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="75"/>
        <source>Select your &amp;CD device:</source>
        <translation>Velg din &amp;CD-enhet:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="176"/>
        <source>Select your &amp;DVD device:</source>
        <translation>Velg din &amp;DVD-enhet:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="274"/>
        <source>Select your &amp;Blu-ray device:</source>
        <translation>Velg din &amp;Blu-Ray-enhet:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="33"/>
        <source>SMPlayer does not choose any CDROM or DVD devices by default. So before you can actually play a CD or DVD you have to select the devices you want to use (they can be the same).</source>
        <translation>SMPlayer velger ikke automatisk noen CDROM- eller DVD-enheter. Så før du faktisk kan spille av en CD eller DVD, må du velge enhetene du ønsker å bruke (De kan være den samme enheten).</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="239"/>
        <source>Blu-ray device</source>
        <translation>Blu-Ray-enhet</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="240"/>
        <source>Choose your Blu-ray device. It will be used to play Blu-ray discs.</source>
        <translation>Velg din Blu-Ray-enhet. Den vil bli brukt til å spille av Blu-Ray-disker.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="227"/>
        <source>Enable DVD menus</source>
        <translation>Aktiver DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="228"/>
        <source>If this option is checked, SMPlayer will play DVDs using dvdnav. Requires a version of MPlayer with dvdnav support.</source>
        <translation>Hvis dette alternativet er valgt, vil SMPlayer spille av DVDer ved hjelp av dvdnav. Det krever en versjon av MPlayer med dvdnav-støtte.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="231"/>
        <source>&lt;b&gt;Note 1&lt;/b&gt;: cache will be disabled, this can affect performance.</source>
        <translation>&lt;b&gt;Bemerkning 1&lt;/&gt;: Mellomlageret vil bli skrudd av, og det kan påvirke yteevnen.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="232"/>
        <source>&lt;b&gt;Note 2&lt;/b&gt;: you may want to assign the action &quot;activate option in DVD menus&quot; to one of the mouse buttons.</source>
        <translation>&lt;b&gt;Bemerkning 2&lt;/b&gt;: Det kan hende du vil ønske å knytte funksjonen &quot;Aktiver innstilling i DVD-menyer&quot; til en av museknappene.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="234"/>
        <source>&lt;b&gt;Note 3&lt;/b&gt;: this feature is under development, expect a lot of issues with it.</source>
        <translation>&lt;b&gt;Bemerkning 3&lt;/b&gt;: Denne funksjonen er under utvikling, så forvent å ha mange problemer med den.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="225"/>
        <source>&amp;Enable DVD menus (experimental)</source>
        <translation>&amp;Aktiver DVD-menyer (eksperiementelt)</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="119"/>
        <source>&amp;Scan for CD/DVD drives</source>
        <translation>&amp;Let etter CD/DVD-lesere</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="153"/>
        <location filename="../prefgeneral.cpp" line="1077"/>
        <source>General</source>
        <translation>Generelt</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="27"/>
        <source>&amp;General</source>
        <translation>&amp;Generelt</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="76"/>
        <source>Media settings</source>
        <translation>Medieinnstillinger</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1220"/>
        <source>Start videos in fullscreen</source>
        <translation>Start videoer i fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1251"/>
        <source>Disable screensaver</source>
        <translation>Skru av skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="176"/>
        <source>7 (6.1 Surround)</source>
        <translation>7 (6.1 surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="177"/>
        <source>8 (7.1 Surround)</source>
        <translation>8 (7.1 surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="205"/>
        <source>Select the %1 executable</source>
        <translation>Velg den eksekverbare %1-filen</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="207"/>
        <source>Executables</source>
        <translation>Eksekverbare filer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="209"/>
        <source>All files</source>
        <translation>Alle filer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="211"/>
        <source>Select a directory</source>
        <translation>Velg en plassering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="222"/>
        <source>%1 &amp;executable:</source>
        <translation>%1 &amp;eksekverbare filer:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="172"/>
        <location filename="../prefgeneral.cpp" line="483"/>
        <location filename="../prefgeneral.cpp" line="484"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="214"/>
        <source>Here you can type your preferred language for the audio and subtitle streams. When a media with multiple audio or subtitle streams is found, SMPlayer will try to use your preferred language. This only will work with media that offer info about the language of audio and subtitle streams, like DVDs or mkv files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="491"/>
        <source>hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="492"/>
        <source>software</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1080"/>
        <source>Multimedia engine</source>
        <translation>Multimediemotor</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1081"/>
        <source>Select which multimedia engine you want to use, either MPlayer or mpv.</source>
        <translation>Velg hvilken multimediemotor du ønsker å bruke, enten MPlayer eller mpv.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1082"/>
        <source>The option &apos;other&apos; allows you to manually select the path of the executable.</source>
        <translation>Alternativet &apos;Annet&apos; gjør at du kan manuelt velge filbanen til den eksekverbare filen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1085"/>
        <source>%1 executable</source>
        <translation>%1 eksekverbare filer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1086"/>
        <source>Here you must specify the %1 executable that SMPlayer will use.</source>
        <translation>Her må du velge den eksekverbare %1-filen som SMPlayer skal bruke.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1101"/>
        <source>Remember settings for streams</source>
        <translation>Husk innstillingene for kringkastinger</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1102"/>
        <source>When this option is enabled the settings for online streams will be remembered as well.</source>
        <translation>Hvis dette alternativet er valgt, vil innstillingene for online-medier også bli husket.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1117"/>
        <source>Screenshots folder</source>
        <translation>Skjermklippmappe</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1123"/>
        <source>Template for screenshots</source>
        <translation>Mal for skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1125"/>
        <source>For example %1 would save the screenshot as &apos;moviename_0001.png&apos;.</source>
        <translation>For eksempel ville %1 lagre skjermklippet som &apos;filmnavn_0001.png&apos;.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1126"/>
        <source>%1 specifies the filename of the video without the extension, %2 adds a 4 digit number padded with zeros.</source>
        <translation>%1 bestemmer videoens filnavn uten utvidelsen, mens %2 legger til et 4-sifret nummer spedd ut med nuller.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1136"/>
        <source>Format for screenshots</source>
        <translation>Format for skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1137"/>
        <source>This option allows to choose the image file type used for saving screenshots.</source>
        <translation>Denne innstillingen tillater deg å velge bildefiltypen som skjermklippene skal lagres som.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1155"/>
        <source>If this option is enabled, the computer will shut down just after SMPlayer is closed.</source>
        <translation>Hvis dette alternativet er valgt, vil datamaskinen skru seg av rett etter at SMPlayer har blitt lukket.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1161"/>
        <source>Video output driver</source>
        <translation>Videoutdatadriver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1162"/>
        <source>Select the video output driver.</source>
        <translation>Velg videoutdatadriveren.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1171"/>
        <source>Wayland support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1172"/>
        <source>This activates some options to prevent the video being displayed outside the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1190"/>
        <source>If this option is enabled, black borders will be added to the image by default on new opened files.</source>
        <translation>Hvis dette alternativet er valgt, vil svarte felter automatisk bli lagt til i bildet til nyåpnede filer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1260"/>
        <source>Audio output driver</source>
        <translation>Lydutdatadriver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1261"/>
        <source>Select the audio output driver.</source>
        <translation>Velg lydutdatadriveren.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1091"/>
        <source>Remember settings</source>
        <translation>Husk innstillinger</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1319"/>
        <source>Preferred audio language</source>
        <translation>Foretrukket lydspråk</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1331"/>
        <source>Preferred subtitle language</source>
        <translation>Foretrukket undertekstspråk</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1198"/>
        <source>Software video equalizer</source>
        <translation>Programvaretonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="168"/>
        <source>Other...</source>
        <translation>Annet...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1124"/>
        <source>This option specifies the filename template used to save screenshots.</source>
        <translation>Denne innstillingen velger filnavnmalen som skal brukes til å lagre skjermklipp.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1128"/>
        <source>For a full list of the template specifiers visit this link:</source>
        <translation>For en full liste over malvelgere, gå til denne lenken:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1132"/>
        <location filename="../prefgeneral.cpp" line="1139"/>
        <source>This option only works with mpv.</source>
        <translation>Denne innstillingen fungerer bare med mpv.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1154"/>
        <source>Shut down computer</source>
        <translation>Skru av datamaskinen</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1189"/>
        <source>Add black borders for subtitles by default</source>
        <translation>Legg til svarte kanter til undertekstene som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1199"/>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Du kan velge denne innstillinger dersom videotonekontrollen ikke støttes av ditt skjermkort eller din valgte videoutdatadriver.&lt;br&gt;&lt;b&gt;Bemerk&lt;/b&gt; at denne innstillingen kan være inkompatibel med noen videoutdatadrivere.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1221"/>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Hvis dette alternativet er valgt, vil alle videoer starte i fullskjermsmodus.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1266"/>
        <source>Global audio equalizer</source>
        <translation>Altomfattende lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1267"/>
        <source>If this option is checked, all media files share the audio equalizer.</source>
        <translation>Hvis dette alternativet er valgt, vil alle mediefiler dele på lydtonekontrollen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1268"/>
        <source>If it&apos;s not checked, the audio equalizer values are saved along each file and loaded back when the file is played later.</source>
        <translation>Hvis det ikke er valgt, vil videotonekontrollerverdiene lagres sammen med hver fil, og lastes inn igjen når filen spilles av igjen senere.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1271"/>
        <source>AC3/DTS passthrough over S/PDIF and HDMI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1277"/>
        <source>Requests the number of playback channels. %1 asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Ber den om antall avspillingskanaler. %1 ber dekoderen om å dekode lyden til det antall kanaler som har blitt valgt. Deretter er det opp til dekoderen å utføre dette kravet. Dette er vanligvis kun viktig ved avspilling av videoer med AC3-lyd (deriblant DVDer). I så fall håndterer liba52 dekodingen som standard, og nedmikser lyden til det ønskede antall kanaler på korrekt vis. &lt;b&gt;Bemerk&lt;/b&gt;: Denne innstillingen følges av kodeker (kun AC3), filtre (Surround), og lydutdatadrivere (OSS gjør garantert det).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1288"/>
        <source>Allows to change the playback speed without altering pitch.</source>
        <translation>Tillater deg å endre avspillingshastigheten uten å endre tonefallet.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1296"/>
        <source>Software volume control</source>
        <translation>Programvare-volumkontroller</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1297"/>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Velg denne innstillingen for å bruke en programvaremikser, i stedet for å bruke lydkortmikseren.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1178"/>
        <source>Postprocessing quality</source>
        <translation>Etterbehandlingskvalitet</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1179"/>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Endrer etterbehandlingsnivået dynamisk avhengig av den tilgjengelige reserve-prosessortiden. Nummeret du velger, vil bli maksnivået som kan brukes. Vanligvis kan du bruke et stort nummer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1172"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Lyd:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="82"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>Husk innstillinger for alle filer (lydspor, undertekster...)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1191"/>
        <source>Su&amp;btitles:</source>
        <translation>Un&amp;dertekster:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="455"/>
        <source>&amp;Quality:</source>
        <translation>&amp;Kvalitet:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="35"/>
        <source>Multimedia &amp;engine:</source>
        <translation>Multimedie&amp;motor:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="163"/>
        <source>Re&amp;member settings for streams</source>
        <translation>Hu&amp;sk innstillingene for kringkastinger</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="220"/>
        <source>Temp&amp;late:</source>
        <translation>Ma&amp;l:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="240"/>
        <source>F&amp;ormat:</source>
        <translation>F&amp;ormat:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="308"/>
        <source>S&amp;hut down computer</source>
        <translation>S&amp;kru av datamaskinen</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="407"/>
        <source>Wa&amp;yland support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="627"/>
        <source>Start videos in &amp;fullscreen</source>
        <translation>Start videoer i &amp;fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="641"/>
        <source>Disable &amp;screensaver</source>
        <translation>Deaktiver &amp;skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="775"/>
        <source>Global audio e&amp;qualizer</source>
        <translation>Altomfattende lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="784"/>
        <source>&amp;AC3/DTS passthrough over S/PDIF and HDMI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="894"/>
        <source>Use s&amp;oftware volume control</source>
        <translation>Bruk p&amp;rogramvare-volumkontroller</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="917"/>
        <source>Ma&amp;x. Amplification:</source>
        <translation>&amp;Maks lydforsterkning</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1204"/>
        <source>Direct rendering</source>
        <translation>Direkte tolkning</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1209"/>
        <source>Double buffering</source>
        <translation>Dobbelbufring</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="593"/>
        <source>D&amp;irect rendering</source>
        <translation>&amp;Direkte tolkning</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="600"/>
        <source>Dou&amp;ble buffering</source>
        <translation>Dob&amp;belbufring</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1210"/>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation>Dobbelbufring korrigerer flimmer ved å lagre to bilder i minnet, og viser den ene mens den dekoder den andre. Hvis det deaktiveres kan det negativt påvirke OSD, men det fjerner ofte OSD-flimmer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="435"/>
        <source>&amp;Enable postprocessing by default</source>
        <translation>&amp;Aktiver etterbehandling som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="945"/>
        <source>Volume &amp;normalization by default</source>
        <translation>Volum&amp;stabilisering som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1149"/>
        <source>Close when finished</source>
        <translation>Lukk når det er ferdig</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1150"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Hvis denne innstillingen er valgt, vil hovedvinduet lukkes automatisk når den nåværende filen/spillelisten er ferdig.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="173"/>
        <source>2 (Stereo)</source>
        <translation>2 (stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="174"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="175"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="799"/>
        <source>C&amp;hannels by default:</source>
        <translation>K&amp;analer som standard:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="269"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Sett på pause ved minimering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1144"/>
        <source>Pause when minimized</source>
        <translation>Sett på pause ved minimering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1175"/>
        <source>Enable postprocessing by default</source>
        <translation>Aktiver etterbehandling som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1300"/>
        <source>Max. Amplification</source>
        <translation>Maks lydforsterkning</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1307"/>
        <source>Volume normalization by default</source>
        <translation>Volumstabilisering som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1308"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Maksimerer volumet uten å forstyrre lyden.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1276"/>
        <source>Channels by default</source>
        <translation>Standardkanaler</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1301"/>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation>Velger maks forsterkningsnivå i prosent (Standarden er 110). En verdi på 200 vil tillate deg å justere volumet opp til maksimalt det dobbelte av det nåværende nivået. Med verdier under 100 vil det opprinnelige volumet (som er 100%) være over det nye maksimumet, som deriblant OSD-visningen ikke kan vise riktig.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1176"/>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation>Etterbehandling vil bli brukt som standard for nyåpnede filer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1321"/>
        <source>You can specify here a priority list of audio language codes, separated by commas. For example: spa,eng,jpn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1325"/>
        <source>This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1333"/>
        <source>You can specify here a priority list of subtitle language codes, separated by commas. For example: spa,eng,jpn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1336"/>
        <source>This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1343"/>
        <source>Audio track</source>
        <translation>Lydspor</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1344"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Velg standardlydsporet som skal bli brukt når du spiller av nye filer. Hvis lydsporet ikke finnes, vil spor 1 bli brukt i stedet. &lt;br&gt;&lt;b&gt;Bemerk&lt;/b&gt; at &lt;i&gt;&quot;Foretrukket lydspråk&quot;&lt;/i&gt; har høyere prioritet enn denne innstillingen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1349"/>
        <source>Subtitle track</source>
        <translation>Undertekstspor</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1350"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Velg standardundertekstsporet som skal bli brukt når du spiller av nye filer. Hvis undertekstsporet ikke finnes, vil spor 1 bli brukt i stedet. &lt;br&gt;&lt;b&gt;Bemerk&lt;/b&gt; at &lt;i&gt;&quot;Foretrukket undertekstspråk&quot;&lt;/i&gt; har høyere prioritet enn denne innstillingen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1312"/>
        <source>Or choose a track number:</source>
        <translation>Eller velg et spornummer:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1253"/>
        <source>Audi&amp;o:</source>
        <translation>Ly&amp;d:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1207"/>
        <source>Preferred language:</source>
        <translation>Foretrukket språk:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1096"/>
        <source>Preferre&amp;d audio and subtitles</source>
        <translation>Foretrukk&amp;et lyd og undertekst</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1266"/>
        <source>&amp;Subtitle:</source>
        <translation>&amp;Undertekster:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="835"/>
        <source>High speed &amp;playback without altering pitch</source>
        <translation>Raskere &amp;avspilling uten å endre tonefallet</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1287"/>
        <source>High speed playback without altering pitch</source>
        <translation>Raskere avspilling uten å endre tonefallet</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="348"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="523"/>
        <source>Add blac&amp;k borders for subtitles by default</source>
        <translation>Legg til svart&amp;e kanter til undertekstene som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="586"/>
        <source>Use s&amp;oftware video equalizer</source>
        <translation>Bruk p&amp;rogramvare-videotonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="685"/>
        <source>A&amp;udio</source>
        <translation>L&amp;yd</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="870"/>
        <source>Volume</source>
        <translation>Volum</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1159"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1258"/>
        <source>Audio</source>
        <translation>Lyd</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1317"/>
        <source>Preferred audio and subtitles</source>
        <translation>Foretrukket lyd og undertekst</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="181"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="182"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="183"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (normal)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="184"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (dobbel bildefrekvens)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="185"/>
        <source>Linear Blend</source>
        <translation>Lineær sammenblanding</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="186"/>
        <source>Kerndeint</source>
        <translation>Kerndeint</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1183"/>
        <source>Deinterlace by default</source>
        <translation>Avflett som standard</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1184"/>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation>Velg avflettingsfilteret du vil bruke til nye videoer som du åpner.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1096"/>
        <source>Remember time position</source>
        <translation>Husk tidsposisjon</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="116"/>
        <source>Remember &amp;time position</source>
        <translation>Husk &amp;tidsposisjon</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1263"/>
        <source>Enable the audio equalizer</source>
        <translation>Aktiver lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1264"/>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation>Velg denne innstillingen hvis du vil bruke lydtonekontrollen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="752"/>
        <source>&amp;Enable the audio equalizer</source>
        <translation>&amp;Skru på lydtonekontroll</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1214"/>
        <source>Draw video using slices</source>
        <translation>Kod videobildene stykkevis</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1215"/>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation>Aktiver/deaktiver å kode videoer med 16-pikslers høye skiver. Hvis det er deaktivert, vil hele skjermen kodes i ett sett. Det kan være raskere eller tregere, avhengig av skjermkortet og den tilgjengelige mellomlagringen. Det har kun en effekt med libmpeg2- og libavcodec-kodekene.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="607"/>
        <source>Dra&amp;w video using slices</source>
        <translation>Kod &amp;videobildene stykkevis</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="276"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Lukk etter at avspillingen er ferdig</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="498"/>
        <source>fast</source>
        <translation>Raskt</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="534"/>
        <location filename="../prefgeneral.cpp" line="586"/>
        <source>User defined...</source>
        <translation>Brukertilpasset...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1194"/>
        <source>Default zoom</source>
        <translation>Standardzooming</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1195"/>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation>Denne innstillingen velger standardzoomingen som skal brukes ved avspilling av nye videoer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="532"/>
        <source>Default &amp;zoom:</source>
        <translation>Standard&amp;zooming:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1088"/>
        <source>If this setting is wrong, SMPlayer won&apos;t be able to play anything!</source>
        <translation>Hvis denne innstillingen er feil, vil ikke SMPlayer kunne spille av noe som helst!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1092"/>
        <source>Usually SMPlayer will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>Vanligvis vil SMPlayer huske innstillingene til hver fil du spiller av (Valgt lydspor, volum, filtre...). Skru av dette alternativet hvis du ikke liker denne funksjonen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1145"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Hvis dette alternativet er valgt, vil filen bli satt på pause når hovedvinduet blir skjult. Når vinduet vises igjen, vil avspillingen fortsette.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1252"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Velg dette alternativet for å deaktivere skjermspareren under avspilling.&lt;br&gt;Skjermspareren vil bli aktivert igjen når avspillingen er ferdig.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="356"/>
        <location filename="../prefgeneral.ui" line="693"/>
        <source>Ou&amp;tput driver:</source>
        <translation>Ut&amp;datadriver:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1225"/>
        <source>Add black borders on fullscreen</source>
        <translation>Legg til svarte kanter ved fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1226"/>
        <source>If this option is enabled, black borders will be added to the image in fullscreen mode. This allows subtitles to be displayed on the black borders.</source>
        <translation>Hvis dette alternativet er valgt, vil svarte felter bli lagt til i bildet i fullskjermsmodus. Dette gjør det mulig for undertekster å bli vist i de svarte feltene.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="634"/>
        <source>&amp;Add black borders on fullscreen</source>
        <translation>&amp;Legg til svarte kanter ved fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="191"/>
        <source>one ini file</source>
        <translation>én .ini-fil</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="192"/>
        <source>multiple ini files</source>
        <translation>flere .ini-filer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1104"/>
        <source>Method to store the file settings</source>
        <translation>Metode for å lagre filinnstillinger</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1105"/>
        <source>This option allows to change the way the file settings would be stored. The following options are available:</source>
        <translation>Denne innstillingen tillater deg å endre måten filinnstillingene blir lagret. De følgende innstillingene er tilgjengelige:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1107"/>
        <source>&lt;b&gt;one ini file&lt;/b&gt;: the settings for all played files will be saved in a single ini file (%1)</source>
        <translation>&lt;b&gt;Én .ini-fil&lt;/b&gt;: innstillingene for alle avspilte filer vil bli lagret i en enkelt .ini.fil (%1)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1111"/>
        <source>The latter method could be faster if there is info for a lot of files.</source>
        <translation>Sistnevnte metode kan være raskere hvis det er informasjon for mange filer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="128"/>
        <source>&amp;Store settings in</source>
        <translation>&amp;Lagre innstillinger i</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1109"/>
        <source>&lt;b&gt;multiple ini files&lt;/b&gt;: one ini file will be used for each played file. Those ini files will be saved in the folder %1</source>
        <translation>&lt;b&gt;Flere .ini-filer&lt;/b&gt;: hver avspilte fil får tildelt sin egen .ini-fil. Disse .ini-filene vil bli lagret i %1-mappen</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1097"/>
        <source>If you check this option, SMPlayer will remember the last position of the file when you open it again. This option works only with regular files (not with DVDs, CDs, URLs...).</source>
        <translation>Hvis du velger denne innstillingen, vil SMPlayer huske den forrige tidsposisjonen til filen når du åpner den igjen. Denne innstillingen fungerer bare med vanlige filer (altså ikke med DVDer, CDer, nettadresser...).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1205"/>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation>Hvis dette er valgt, skrur det på sanntidsrendering (som ikke alle kodeker eller videoutdataer støtter)&lt;br&gt;&lt;b&gt;Advarsel:&lt;/b&gt; Det kan forårsake OSD/SUB-korrumpering!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1113"/>
        <source>Enable screenshots</source>
        <translation>Aktiver skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1114"/>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation>Du kan bruke denne innstillingen til å aktivere eller fjerne muligheten til å ta skjermklipp.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1118"/>
        <source>Here you can specify a folder where the screenshots taken by SMPlayer will be stored. If the folder is not valid the screenshot feature will be disabled.</source>
        <translation>Her kan du velge en mappe der skjermklippene som tas av SMPlayer vil bli lagret. Hvis mappen ikke er gyldig, vil skjermklippfunksjonen bli skrudd av.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="175"/>
        <source>Screenshots</source>
        <translation>Skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="181"/>
        <source>&amp;Enable screenshots</source>
        <translation>&amp;Aktiver skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <source>&amp;Folder:</source>
        <translation>&amp;Mappe:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1290"/>
        <source>Global volume</source>
        <translation>Altomfattende volum</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1291"/>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation>Hvis denne innstillingen er valgt, vil det samme volumnivået bli brukt i alle filene du spiller av. Hvis innstillingen ikke er valgt, vil hver fil ha sitt eget volum.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1294"/>
        <source>This option also applies for the mute control.</source>
        <translation>Dette alternativet gjelder også for dempeknappen.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="879"/>
        <source>Glo&amp;bal volume</source>
        <translation>Altom&amp;fattende volum</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1236"/>
        <source>Switch screensaver off</source>
        <translation>Skru av skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1237"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation>Denne innstillingen skrur skjermspareren av rett før avspilling av en fil, og skrur den på igjen når avspillingen er ferdig. Hvis denne innstillingen er valgt, vil ikke skjermspareren dukke opp, selv under avspilling av lydfiler eller hvis en fil er satt på pause.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1243"/>
        <source>Avoid screensaver</source>
        <translation>Unngå skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1244"/>
        <source>When this option is checked, SMPlayer will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the SMPlayer window is in the foreground.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer prøve å hindre skjermspareren i å bli vist når en videofil blir spilt av. Skjermspareren vil kun være i stand til å vises under avspilling av en lydfil eller i pausemodus. Denne innstillingen fungerer bare hvis SMPlayer-vinduet ikke er minimert.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="648"/>
        <source>Screensaver</source>
        <translation>Skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="654"/>
        <source>Swit&amp;ch screensaver off</source>
        <translation>Sk&amp;ru av skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="661"/>
        <source>Avoid &amp;screensaver</source>
        <translation>Unngå &amp;skjermsparer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1310"/>
        <source>Audio/video auto synchronization</source>
        <translation>Autosynkronisering av lyd/video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1311"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Justerer A/V-synkroniseringen gradvis, basert på lydforsinkelsesmålinger.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1314"/>
        <source>A-V sync correction</source>
        <translation>AV-synkroniseringskorrigering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1315"/>
        <source>Maximum A-V sync correction per frame (in seconds)</source>
        <translation>Maksimal A/V-synkroniseringskorrigering per bilde (i sekunder)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="955"/>
        <source>Synchronization</source>
        <translation>Synkronisering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="966"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Auto&amp;synkronisering av lyd/video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="992"/>
        <source>&amp;Factor:</source>
        <translation>&amp;Faktor:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1028"/>
        <source>A-V sync &amp;correction</source>
        <translation>AV-synkroniserings&amp;korrigering</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1051"/>
        <source>&amp;Max. correction:</source>
        <translation>&amp;Maks korrigering:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1186"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; This option won&apos;t be used for TV channels.</source>
        <translation>&lt;b&gt;Bemerk:&lt;/b&gt; Denne innstillingen vil ikke bli brukt for TV-kanaler.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="488"/>
        <source>Dei&amp;nterlace by default (except for TV):</source>
        <translation>Avf&amp;lett som standard med (Bortsett fra for TV):</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1272"/>
        <source>Uses hardware AC3 passthrough.</source>
        <translation>Bruker direkte AC3 gjennom maskinvareytelse.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1273"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; none of the audio filters will be used when this option is enabled.</source>
        <translation>&lt;b&gt;Bemerk:&lt;/b&gt; Ingen av lydfiltrene vil bli brukt dersom denne innstillingen er aktivert.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="499"/>
        <source>snap mode</source>
        <translation>Klistremodus</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="500"/>
        <source>slower dive mode</source>
        <translation>Modus for tregere stuping</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="385"/>
        <source>Configu&amp;re...</source>
        <translation>Konfigu&amp;rer...</translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <location filename="../prefinput.cpp" line="52"/>
        <source>Keyboard and mouse</source>
        <translation>Tastatur og mus</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="24"/>
        <source>&amp;Keyboard</source>
        <translation>&amp;Tastatur</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="84"/>
        <source>&amp;Use the multimedia keys as global shortcuts</source>
        <translation>&amp;Bruk multimedieknappene som globale snarveier</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="107"/>
        <source>Select &amp;keys...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="117"/>
        <source>&amp;Mouse</source>
        <translation>&amp;Mus</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="167"/>
        <source>Button functions:</source>
        <translation>Knappefunksjoner:</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="364"/>
        <source>Dra&amp;g function:</source>
        <translation>Dr&amp;a-funksjon:</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="406"/>
        <source>Don&apos;t &amp;trigger the left click action with a double click</source>
        <translation>Ikke &amp;utløs venstreklikkhandlingen med et dobbeltklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="161"/>
        <location filename="../prefinput.cpp" line="438"/>
        <source>Media seeking</source>
        <translation>Spoling frem/tilbake</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="162"/>
        <location filename="../prefinput.cpp" line="441"/>
        <source>Volume control</source>
        <translation>Volumkontroller</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="163"/>
        <location filename="../prefinput.cpp" line="444"/>
        <source>Zoom video</source>
        <translation>Zoom video</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="67"/>
        <location filename="../prefinput.cpp" line="174"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="57"/>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Her kan du endre alle hurtigtaster. For å gjøre det, dobbeltklikk eller trykk Enter over et hurtigtastfelt. Alternativt kan du lagre listen for å dele den med andre folk eller laste den inn på en annen datamaskin.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="183"/>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Her kan du endre alle hurtigtaster. For å gjøre det, dobbeltklikk eller begynn å skrive mens du er over et hurtigtastfelt. Alternativt kan du lagre listen for å dele den med andre folk eller laste den inn på en annen datamaskin.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="177"/>
        <source>&amp;Left click</source>
        <translation>&amp;Venstreklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="200"/>
        <source>&amp;Double click</source>
        <translation>&amp;Dobbeltklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="321"/>
        <source>&amp;Wheel function:</source>
        <translation>&amp;Musehjulfunksjon:</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="380"/>
        <source>Shortcut editor</source>
        <translation>Snarveisredigering</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="381"/>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation>Denne tabellen tillater deg å endre tastatursnarveiene til de fleste tilgjengelige handlingene. Dobbeltklikk eller trykk Enter på en gjenstand, eller klikk på &lt;b&gt;Endre snarvei&lt;/b&gt;-knappen for å skrive inn i &lt;i&gt;Modifiser snarvei&lt;/i&gt;-dialogen. Det er to måter å endre på en snarvei: Hvis &lt;b&gt;Opptak&lt;/b&gt;-knappen er skrudd på, trenger du bare å trykke på den nye tasten eller tastekombinasjonen som du vil knytte til handlingen (Dessverre fungerer det ikke med alle taster). Hvis &lt;b&gt;Opptak&lt;/b&gt;-knappen er skrudd av, kan du da skrive inn tastens fulle navn.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="399"/>
        <source>Left click</source>
        <translation>Venstreklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="400"/>
        <source>Select the action for left click on the mouse.</source>
        <translation>Velg handlingen til et venstreklikk med musen.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="402"/>
        <source>Double click</source>
        <translation>Dobbeltklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="403"/>
        <source>Select the action for double click on the mouse.</source>
        <translation>Velg handlingen til et dobbeltklikk med musen.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="414"/>
        <source>Wheel function</source>
        <translation>Musehjulfunksjon</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="415"/>
        <source>Select the action for the mouse wheel.</source>
        <translation>Velg handlingen til musehjulet.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="68"/>
        <source>Play</source>
        <translation>Spill av</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="70"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="72"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="83"/>
        <source>Fullscreen</source>
        <translation>Fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="84"/>
        <source>Compact</source>
        <translation>Kompakt</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="85"/>
        <source>Screenshot</source>
        <translation>Skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="89"/>
        <source>Mute</source>
        <translation>Demp</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="95"/>
        <source>Frame counter</source>
        <translation>Bildeteller</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="92"/>
        <source>Reset zoom</source>
        <translation>Tilbakestill zooming</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="93"/>
        <source>Exit fullscreen</source>
        <translation>Gå ut av fullskjerm</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="97"/>
        <source>Double size</source>
        <translation>Dobbel størrelse</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="69"/>
        <source>Play / Pause</source>
        <translation>Spill av / Pause</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="71"/>
        <source>Pause / Frame step</source>
        <translation>Pause / Ett bilde fremover</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="91"/>
        <source>Playlist</source>
        <translation>Spilleliste</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="96"/>
        <source>Preferences</source>
        <translation>Foretrukne valg</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="160"/>
        <source>No function</source>
        <translation>Ingen funksjon</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="164"/>
        <location filename="../prefinput.cpp" line="447"/>
        <source>Change speed</source>
        <translation>Endre fart</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="94"/>
        <source>Normal speed</source>
        <translation>Vanlig fart</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="378"/>
        <source>Keyboard</source>
        <translation>Tastatur</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="397"/>
        <source>Mouse</source>
        <translation>Mus</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="405"/>
        <source>Middle click</source>
        <translation>Mellomklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="406"/>
        <source>Select the action for middle click on the mouse.</source>
        <translation>Velg handlingen til et mellomklikk med musen.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="246"/>
        <source>M&amp;iddle click</source>
        <translation>M&amp;ellomklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="259"/>
        <source>X Button &amp;1</source>
        <translation>Ekstraknapp &amp;1</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="272"/>
        <source>X Button &amp;2</source>
        <translation>Ekstraknapp &amp;2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="73"/>
        <source>Go backward (short)</source>
        <translation>Gå bakover (kort)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="74"/>
        <source>Go backward (medium)</source>
        <translation>Gå bakover (middels)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="75"/>
        <source>Go backward (long)</source>
        <translation>Gå bakover (langt)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="76"/>
        <source>Go forward (short)</source>
        <translation>Gå fremover (kort)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="77"/>
        <source>Go forward (medium)</source>
        <translation>Gå fremover (middels)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="78"/>
        <source>Go forward (long)</source>
        <translation>Gå fremover (langt)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="90"/>
        <source>OSD - Next level</source>
        <translation>OSD - Neste nivå</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="102"/>
        <source>Show context menu</source>
        <translation>Vis kontekstmeny</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="223"/>
        <source>&amp;Right click</source>
        <translation>&amp;Høyreklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="79"/>
        <source>Increase volume</source>
        <translation>Øk volum</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="80"/>
        <source>Decrease volume</source>
        <translation>Senk volum</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="408"/>
        <source>X Button 1</source>
        <translation>Ekstraknapp 1</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="409"/>
        <source>Select the action for the X button 1.</source>
        <translation>Velg handlingen til ekstraknapp 1.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="411"/>
        <source>X Button 2</source>
        <translation>Ekstraknapp 2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="412"/>
        <source>Select the action for the X button 2.</source>
        <translation>Velg handlingen til ekstraknapp 2.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="100"/>
        <source>Show video equalizer</source>
        <translation>Vis videotonekontroller</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="101"/>
        <source>Show audio equalizer</source>
        <translation>Vis lydtonekontroller</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="86"/>
        <source>Always on top</source>
        <translation>Alltid øverst</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="81"/>
        <source>Play next</source>
        <translation>Spill av neste</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="82"/>
        <source>Play previous</source>
        <translation>Spill av forrige</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="87"/>
        <source>Never on top</source>
        <translation>Aldri øverst</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="88"/>
        <source>On top while playing</source>
        <translation>Øverst under avspilling</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="98"/>
        <source>Next chapter</source>
        <translation>Neste kapittel</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="99"/>
        <source>Previous chapter</source>
        <translation>Forrige kapittel</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="105"/>
        <source>Activate option under mouse in DVD menus</source>
        <translation>Aktiver innstilling ved musebruk i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="106"/>
        <source>Return to main DVD menu</source>
        <translation>Gå tilbake til DVDens hovedmeny</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="107"/>
        <source>Return to previous menu in DVD menus</source>
        <translation>Gå tilbake til DVDens forrige meny</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="108"/>
        <source>Move cursor up in DVD menus</source>
        <translation>Flytt markøren opp i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="109"/>
        <source>Move cursor down in DVD menus</source>
        <translation>Flytt markøren ned i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="110"/>
        <source>Move cursor left in DVD menus</source>
        <translation>Flytt markøren til venstre i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="111"/>
        <source>Move cursor right in DVD menus</source>
        <translation>Flytt markøren til høyre i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="112"/>
        <source>Activate highlighted option in DVD menus</source>
        <translation>Aktiver fremhevet innstilling i DVD-menyer</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="175"/>
        <location filename="../prefinput.cpp" line="419"/>
        <source>Move window</source>
        <translation>Flytt på vindu</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="177"/>
        <location filename="../prefinput.cpp" line="421"/>
        <source>Seek and volume</source>
        <translation>Spoling og volum</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="392"/>
        <source>Use the multimedia keys as global shortcuts</source>
        <translation>Bruk multimedieknappene som globale snarveier</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="393"/>
        <source>When this option is enabled the multimedia keys (Play, Stop, Volume+/-, Mute, etc.) will work even when SMPlayer is running in the background.</source>
        <translation>Når denne innstillingen er valgt, vil multimedieknappene (Spill av, Stopp, Volum±, osv.) fungere også når SMPlayer kjører i bakgrunnen.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="417"/>
        <source>Drag function</source>
        <translation>Dra-funksjon</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="418"/>
        <source>This option controls what to do when the mouse is moved while pressing the left button.</source>
        <translation>Denne innstillingen styrer hva som skjer når musen beveges mens venstre musetast holdes inne.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="419"/>
        <source>the main window is moved</source>
        <translation>hovedvinduet blir flyttet på</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="422"/>
        <source>a horizontal movement changes the time position while a vertical movement changes the volume</source>
        <translation>En sidelengs bevegelse endrer tidsposisjonen, mens en loddrett bevegelse endrer volumet</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="426"/>
        <source>Don&apos;t trigger the left click function with a double click</source>
        <translation>Ikke utløs venstreklikkhandlingen med et dobbeltklikk</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="427"/>
        <source>If this option is enabled when you double click on the video area only the double click function will be triggered. The left click action won&apos;t be activated.</source>
        <translation>Hvis denne innstillingen er valgt: Dersom du dobbeltklikker i videoområdet, vil kun dobbeltklikkeffekten finne sted. Venstreklikkfunksjonen vil ikke finne sted.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="430"/>
        <source>By enabling this option the left click is delayed %1 milliseconds because it&apos;s necessary to wait that time to know if there&apos;s a double click or not.</source>
        <translation>Ved å aktivere denne innstillingen, vil venstreklikk bli forsinket med %1 millisekunder, fordi det er nødvendig å vente såpass lenge for å se om det er et dobbeltklikk eller ikke.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="103"/>
        <source>Change function of wheel</source>
        <translation>Bytt musehjulets funksjon</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="459"/>
        <location filename="../prefinput.cpp" line="167"/>
        <source>Media &amp;seeking</source>
        <translation>&amp;Spoling frem/tilbake</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="473"/>
        <location filename="../prefinput.cpp" line="168"/>
        <source>&amp;Zoom video</source>
        <translation>&amp;Zoom video</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="466"/>
        <location filename="../prefinput.cpp" line="169"/>
        <source>&amp;Volume control</source>
        <translation>&amp;Volumkontroller</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="480"/>
        <location filename="../prefinput.cpp" line="170"/>
        <source>&amp;Change speed</source>
        <translation>&amp;Endre fart</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="436"/>
        <source>Mouse wheel functions</source>
        <translation>Musehjulfunksjoner</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="439"/>
        <source>Check it to enable seeking as one function.</source>
        <translation>Velg dette for å aktivere spoling som én funksjon.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="442"/>
        <source>Check it to enable changing volume as one function.</source>
        <translation>Velg dette for å aktivere endring av volum som én funksjon.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="445"/>
        <source>Check it to enable zooming as one function.</source>
        <translation>Velg dette for å aktivere zooming som én funksjon.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="448"/>
        <source>Check it to enable changing speed as one function.</source>
        <translation>Velg dette for å aktivere endring av hastighet som én funksjon.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="437"/>
        <source>M&amp;ouse wheel functions</source>
        <translation>M&amp;usehjulfunksjoner</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="449"/>
        <source>Select the actions that should be cycled through when using the &quot;Change function of wheel&quot; option.</source>
        <translation>Velg handlingene som skal byttes mellom ved bruk av &quot;Bytt musehjulets funksjon&quot;-innstillingen.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="433"/>
        <source>Reverse mouse wheel seeking</source>
        <translation>Baklengs musehjulsspoling</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="434"/>
        <source>Check it to seek in the opposite direction.</source>
        <translation>Velg dette for å spole i motsatt retning.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="413"/>
        <source>R&amp;everse wheel media seeking</source>
        <translation>B&amp;aklengs musehjulsspoling</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <location filename="../prefinterface.cpp" line="158"/>
        <location filename="../prefinterface.cpp" line="740"/>
        <source>Interface</source>
        <translation>Grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="228"/>
        <location filename="../prefinterface.cpp" line="232"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="27"/>
        <source>&amp;Interface</source>
        <translation>&amp;Grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="58"/>
        <source>Never</source>
        <translation>Aldri</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="63"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Når enn det behøves</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="68"/>
        <source>Only after loading a new video</source>
        <translation>Kun etter innlasting av en ny video</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="830"/>
        <source>Privac&amp;y</source>
        <translation>Privatli&amp;v</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="836"/>
        <location filename="../prefinterface.cpp" line="879"/>
        <source>Recent files</source>
        <translation>Nylige filer</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="760"/>
        <source>Language</source>
        <translation>Språk</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="761"/>
        <source>Here you can change the language of the application.</source>
        <translation>Her kan du endre programmets språk.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="202"/>
        <source>&amp;Short jump</source>
        <translation>&amp;Kort hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="173"/>
        <source>System language</source>
        <translation>Systemspråk</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="203"/>
        <source>&amp;Medium jump</source>
        <translation>&amp;Middels hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="204"/>
        <source>&amp;Long jump</source>
        <translation>&amp;Langt hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="205"/>
        <source>Mouse &amp;wheel jump</source>
        <translation>Muse&amp;hjulhopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="636"/>
        <source>&amp;Use only one running instance of SMPlayer</source>
        <translation>&amp;Bruk kun én pågående SMPlayer-prosess om gangen</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="848"/>
        <source>Ma&amp;x. items</source>
        <translation>Ma&amp;ks antall gjenstander</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="338"/>
        <source>St&amp;yle:</source>
        <translation>St&amp;il:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="242"/>
        <source>Ico&amp;n set:</source>
        <translation>Iko&amp;nliste:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="173"/>
        <source>L&amp;anguage:</source>
        <translation>S&amp;pråk:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="33"/>
        <source>Main window</source>
        <translation>Hovedvindu</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="41"/>
        <source>Auto&amp;resize:</source>
        <translation>Auto-&amp;omskaler:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="112"/>
        <source>&amp;Prevent window to get outside of screen</source>
        <translation>&amp;Forhindre at vinduet forlater skjermområdet</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="134"/>
        <source>Center &amp;window</source>
        <translation>Sentrer &amp;vindu</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="141"/>
        <source>R&amp;emember position and size</source>
        <translation>H&amp;usk posisjon og størrelse</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="290"/>
        <source>S&amp;kin:</source>
        <translation>U&amp;tseende:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="397"/>
        <source>Default font:</source>
        <translation>Standardfont:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="411"/>
        <source>&amp;Change...</source>
        <translation>&amp;Endre...</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="420"/>
        <source>Use the syste&amp;m native file dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="506"/>
        <source>&amp;Behaviour of time slider:</source>
        <translation>&amp;Tidsgliderens oppførsel:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="523"/>
        <source>Seek to position while dragging</source>
        <translation>Spol frem til en posisjon når du drar musen</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="528"/>
        <source>Seek to position when released</source>
        <translation>Spol frem til en posisjon når musen blir sluppet</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="613"/>
        <source>Pressi&amp;ng the stop button once resets the time position</source>
        <translation>Å try&amp;kke på Stopp-knappen én gang, tilbakestiller tidsposisjonen</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="678"/>
        <source>The floating control appears in fullscreen mode when the mouse is moved.</source>
        <translation>Den svevende kontrolleren dukker opp i fullskjermsmodus når musen flyttes på.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="765"/>
        <source>Show only when moving the mouse to the &amp;bottom of the screen</source>
        <translation>Vis kun når du flytter musen til &amp;bunnen av skjermen</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="781"/>
        <source>Tim&amp;e (in milliseconds) to hide the control:</source>
        <translation>Ti&amp;d (i millisekunder) før skjuling av kontrolleren:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="887"/>
        <source>URLs</source>
        <translation>Nettadresser</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="899"/>
        <source>&amp;Max. items</source>
        <translation>&amp;Ma&amp;ks antall gjenstander</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="938"/>
        <source>&amp;Remember last directory</source>
        <translation>&amp;Husk forrige plassering</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="959"/>
        <source>High &amp;DPI</source>
        <translation>Høy pikseltetthet</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="965"/>
        <source>SMPlayer can scale the interface in high DPI screens. Here you can disable this feature or change the scale factor.</source>
        <translation>SMPlayer kan skalere grensesnittet på skjermer med høy pikseltetthet. Her kan du skru av funksjonen eller endre skaleringsfaktoren.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="975"/>
        <source>&amp;Enable support for high DPI screens</source>
        <translation>&amp;Aktiver støtte for skjermer med høy pikseltetthet</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="985"/>
        <source>Scale</source>
        <translation>Skaler</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="991"/>
        <source>A&amp;uto</source>
        <translation>A&amp;uto</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="1047"/>
        <source>Changes in this section requires to restart SMPlayer in order to take effect</source>
        <translation>Endringer i denne seksjonen krever en omstart av SMPlayer for å bli brukt.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="629"/>
        <source>TextLabel</source>
        <translation>Tekstmerke</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="441"/>
        <source>&amp;Seeking</source>
        <translation>&amp;Spoling</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="563"/>
        <source>&amp;Absolute seeking</source>
        <translation>&amp;Absolutt spoling</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="576"/>
        <source>&amp;Relative seeking</source>
        <translation>&amp;Relativ spoling</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="621"/>
        <source>Ins&amp;tances</source>
        <translation>Pro&amp;sesser</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="742"/>
        <source>Autoresize</source>
        <translation>Auto-omskaler</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="743"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>Hovedvinduet kan bli omskalert automatisk. Velg det alternativet som du foretrekker.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="753"/>
        <source>Remember position and size</source>
        <translation>Husk posisjon og størrelse</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="754"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run SMPlayer again.</source>
        <translation>Hvis du velger dette alternativet, vil plasseringen og størrelsen til hovedvinduet lagres og brukes når du starter opp SMPlayer igjen.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="764"/>
        <source>Select the graphic interface you prefer for the application.</source>
        <translation>Velg det grafiske grensesnittet du foretrekker for programmet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="765"/>
        <source>The &lt;b&gt;Basic GUI&lt;/b&gt; provides the traditional interface, with the toolbar and control bar.</source>
        <translation>Det &lt;b&gt;grunnleggende grafiske snittet&lt;/b&gt; tilbyr det tradisjonale grensesnittet, med verktøylinjen og kontrollinjen.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="767"/>
        <source>The &lt;b&gt;Mini GUI&lt;/b&gt; provides a more simple interface, without toolbar and a control bar with few buttons.</source>
        <translation>&lt;b&gt;Minigrensesnittet&lt;/b&gt; tilbyr et mer enkelt grensesnitt, uten verktøylinjen, og med en kontrollinje med kun noen knapper.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="775"/>
        <source>The &lt;b&gt;Skinnable GUI&lt;/b&gt; provides an interface where several skins are available.</source>
        <translation>Det &lt;b&gt;tematiserbare grensesnittet&lt;/b&gt; tilbyr et grensesnitt hvor flere temaer er tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="771"/>
        <source>The &lt;b&gt;Mpc GUI&lt;/b&gt; looks like the interface in Media Player Classic.</source>
        <translation>&lt;b&gt;Mpc-grensesnittet&lt;/b&gt; ser ut som grensesnittet til Media Player Classic.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="877"/>
        <source>Privacy</source>
        <translation>Privatliv</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="880"/>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation>Velg maks antall gjenstander som skal vises i &lt;b&gt;Åpne→Nylige filer&lt;/b&gt;-undermenyen. Hvis du har satt det til 0, vil ikke den menyen vises i det hele tatt.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="780"/>
        <source>Icon set</source>
        <translation>Ikonliste</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="226"/>
        <source>Classic</source>
        <translation>Klassisk</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="238"/>
        <source>Basic GUI</source>
        <translation>Enkelt grafisk grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="247"/>
        <source>Skinnable GUI</source>
        <translation>Tematiserbart grafisk grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="260"/>
        <source>Scale fact&amp;or:</source>
        <translation>Skaleringsfakt&amp;or:</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="263"/>
        <source>Pixel rati&amp;o:</source>
        <translation>Pikselfrekven&amp;s:</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="746"/>
        <source>Prevent window to get outside of screen</source>
        <translation>Forhindre at vinduet forlater skjermområdet</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="747"/>
        <source>If after an autoresize the main window gets outside of the screen this option will center the window to prevent it.</source>
        <translation>Dersom hovedvinduet, etter en autojustering, havner utenfor skjermen, vil denne innstillingen sentrere vinduet for å forhindre at det skjer.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="750"/>
        <source>Center window</source>
        <translation>Sentrer vindu</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="751"/>
        <source>When this option is enabled, the main window will be centered on the desktop.</source>
        <translation>Hvis dette alternativet er valgt, vil hovedvinduet bli sentrert på skrivebordet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="781"/>
        <source>Select the icon set you prefer for the application.</source>
        <translation>Velg ikonet som du foretrekker for dette programmet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="784"/>
        <source>Skin</source>
        <translation>Utseende</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="785"/>
        <source>Select the skin you prefer for the application. Only available with the skinnable GUI.</source>
        <translation>Velg utseendet du foretrekker for programmet. Kun tilgjengelig med det tematiserbare grensesnittet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="788"/>
        <source>Style</source>
        <translation>Stil</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="789"/>
        <source>Select the style you prefer for the application.</source>
        <translation>Velg stilen du foretrekker for dette programmet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="792"/>
        <source>Default font</source>
        <translation>Standardfont</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="793"/>
        <source>You can change here the application&apos;s font.</source>
        <translation>Du kan endre programmets font her.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="795"/>
        <source>Use the system native file dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="796"/>
        <source>When this option is enabled, SMPlayer will try to use the system native file dialog. Otherwise it will use the internal one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="798"/>
        <source>Seeking</source>
        <translation>Spoling</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="800"/>
        <source>Short jump</source>
        <translation>Kort hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="801"/>
        <location filename="../prefinterface.cpp" line="805"/>
        <location filename="../prefinterface.cpp" line="809"/>
        <source>Select the time that should be go forward or backward when you choose the %1 action.</source>
        <translation>Velg tidsmengden som skal hoppes frem eller tilbake når du bruker %1-handlingen.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="802"/>
        <source>short jump</source>
        <translation>Kort hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="804"/>
        <source>Medium jump</source>
        <translation>Middels hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="806"/>
        <source>medium jump</source>
        <translation>Middels hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="808"/>
        <source>Long jump</source>
        <translation>Langt hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="810"/>
        <source>long jump</source>
        <translation>Langt hopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="812"/>
        <source>Mouse wheel jump</source>
        <translation>Musehjulhopp</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="813"/>
        <source>Select the time that should be go forward or backward when you move the mouse wheel.</source>
        <translation>Velg tidsmengden som skal hoppes frem eller tilbake når du ruller musehjulet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="816"/>
        <source>Behaviour of time slider</source>
        <translation>Tidsgliderens oppførsel</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="817"/>
        <source>Select what to do when dragging the time slider.</source>
        <translation>Velg hva du skal gjøre når du drar i tidsglideren.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="829"/>
        <source>Note: this option only works when using mpv as multimedia engine.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="831"/>
        <source>Pressing the stop button once resets the time position</source>
        <translation>Å trykke på Stopp-knappen én gang, tilbakestiller tidsposisjonen</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="862"/>
        <source>Show only when moving the mouse to the bottom of the screen</source>
        <translation>Vis kun når du flytter musen til bunnen av skjermen</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="863"/>
        <source>If this option is checked, the floating control will only be displayed when the mouse is moved to the bottom of the screen. Otherwise the control will appear whenever the mouse is moved, no matter its position.</source>
        <translation>Hvis denne innstillingen er valgt, vil den svevende kontrolleren kun vises når musen flyttes til bunnen av skjermen. Utover det vil kontrolleren kun dukke opp når musen flyttes på, uansett hvor den er hen.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="868"/>
        <source>If this option is enabled, the floating control will appear in compact mode too.</source>
        <translation>Hvis dette alternativet er valgt, vil den svevende kontrolleren dukke opp også i kompakt modus.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="870"/>
        <source>This option only works with the basic GUI.</source>
        <translation>Denne innstillingen fungerer bare med det enkle grafiske grensesnittet.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="871"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; the floating control has not been designed for compact mode and it might not work properly.</source>
        <translation>&lt;b&gt;Advarsel:&lt;/b&gt; Den svevende kontrolleren har ikke blitt laget med Kompakt modus i tankene, og det kan kanskje ikke fungere riktig.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="874"/>
        <source>Time to hide the control</source>
        <translation>Tid for å skjule kontrolleren</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="875"/>
        <source>Sets the time (in milliseconds) to hide the control after the mouse went away from the control.</source>
        <translation>Velger tiden (i millisekunder) før kontrolleren skal skjules, etter at musen har blitt flyttet bort fra kontrolleren.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="884"/>
        <source>Max. URLs</source>
        <translation>Maks nettadresser</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="885"/>
        <source>Select the maximum number of items that the &lt;b&gt;Open-&gt;URL&lt;/b&gt; dialog will remember. Set it to 0 if you don&apos;t want any URL to be stored.</source>
        <translation>Velg maks antall gjenstander som &lt;b&gt;Åpne→Nettadresse&lt;/b&gt;-dialogen skal huske. Hvis du har satt det til 0, vil ikke noen nettadresser bli husket.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="889"/>
        <source>Remember last directory</source>
        <translation>Husk forrige plassering</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="890"/>
        <source>If this option is checked, SMPlayer will remember the last folder you use to open a file.</source>
        <translation>Hvis dette alternativet er valgt, vil SMPlayer husk den foregående mappen du har brukt til å åpne en fil.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="551"/>
        <location filename="../prefinterface.cpp" line="820"/>
        <source>Seeking method</source>
        <translation>Spolemetode</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="821"/>
        <source>Sets the method to be used when seeking with the slider. Absolute seeking may be a little bit more accurate, while relative seeking may work better with files with a wrong length.</source>
        <translation>Velger metoden som skal brukes ved søking med glideren. Absolutt spoling kan være bittelitt mer nøyaktig, mens relativ søking kan fungere bedre med filer som har feil tidslengde.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="832"/>
        <source>By default when the stop button is pressed the time position is remembered so if you press play button the media will resume at the same point. You need to press the stop button twice to reset the time position, but if this option is checked the time position will be set to 0 with only one press of the stop button.</source>
        <translation>Som standard, når Stopp-knappen trykkes på, blir tidsposisjonen husket. Så når du trykker på Spill av-knappen, fortsetter mediet fra den samme posisjonen. Du må trykke på Stopp-knapper to ganger for å tilbakestille tidsposisjonen, men hvis dette alternativet er valgt vil tidsposisjonen stilles tilbake til 0 med kun ett trykk på Stopp-knappen.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="839"/>
        <source>Instances</source>
        <translation>Prosesser</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="842"/>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Bruk kun én pågående SMPlayer-prosess om gangen</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="843"/>
        <source>Check this option if you want to use an already running instance of SMPlayer when opening other files.</source>
        <translation>Velg denne innstillingen hvis du vil bruke en allerede pågående SMPlayer-prosess når du åpner andre filer.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="241"/>
        <source>Mini GUI</source>
        <translation>Minigrensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="763"/>
        <source>GUI</source>
        <translation>Grafisk grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="209"/>
        <source>&amp;GUI</source>
        <translation>&amp;Grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="847"/>
        <source>Floating control</source>
        <translation>Svevende kontroller</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="849"/>
        <source>Animated</source>
        <translation>Animert</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="850"/>
        <source>If this option is enabled, the floating control will appear with an animation.</source>
        <translation>Hvis dette alternativet er valgt, vil den svevende kontrolleren dukke opp med en animasjon.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="853"/>
        <source>Width</source>
        <translation>Bredde</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="854"/>
        <source>Specifies the width of the control (as a percentage).</source>
        <translation>Velger bredden til kontrolleren (som en prosentmengde).</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="856"/>
        <source>Margin</source>
        <translation>Margin</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="857"/>
        <source>This option sets the number of pixels that the floating control will be away from the bottom of the screen. Useful when the screen is a TV, as the overscan might prevent the control to be visible.</source>
        <translation>Dette alternativet velger antall piksler som den svevende kontrolleren skal ha som mellomrom til bunnen av skjermen. Nyttig for enkelte TV-er, siden TV-er som ikke er i skjermtilpasningsmodus kan hindre at kontrolleren vises.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="867"/>
        <source>Display in compact mode too</source>
        <translation>Vis også i kompakt modus</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="672"/>
        <source>&amp;Floating control</source>
        <translation>&amp;Svevende kontroller</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="688"/>
        <source>&amp;Animated</source>
        <translation>&amp;Animert</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="697"/>
        <source>&amp;Width:</source>
        <translation>&amp;Bredde:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="723"/>
        <location filename="../prefinterface.ui" line="756"/>
        <location filename="../prefinterface.ui" line="1032"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="730"/>
        <source>&amp;Margin:</source>
        <translation>&amp;Margin:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="772"/>
        <source>Display in &amp;compact mode too</source>
        <translation>Vis også i &amp;kompakt modus</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="244"/>
        <source>Mpc GUI</source>
        <translation>Mpc-grensesnitt</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="757"/>
        <source>Hide video window when playing audio files</source>
        <translation>Skjul videovinduet under avspilling av lydfiler</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="758"/>
        <source>If this option is enabled the video window will be hidden when playing audio files.</source>
        <translation>Hvis dette alternativet er valgt, vil videovinduet bli skjult under avspilling av lydfiler.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="148"/>
        <source>&amp;Hide video window when playing audio files</source>
        <translation>&amp;Skjul videovinduet under avspilling av lydfiler</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="826"/>
        <source>Precise seeking</source>
        <translation>Nøyaktig spoling</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="827"/>
        <source>If this option is enabled, seeks are more accurate but they can be a little bit slower. May not work with some video formats.</source>
        <translation>Hvis denne innstillingen er valgt, vil spolehoppene være mer nøyaktige, men de kan være litt tregere. Det kan kanskje ikke virke med noen videoformater.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="599"/>
        <source>&amp;Precise seeking</source>
        <translation>&amp;Nøyaktig spoling</translation>
    </message>
</context>
<context>
    <name>PrefNetwork</name>
    <message>
        <location filename="../prefnetwork.ui" line="24"/>
        <source>&amp;YouTube (and other sites)</source>
        <translation>&amp;YouTube (og andre sider)</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="32"/>
        <source>Support for &amp;video sites:</source>
        <translation>Støtte for &amp;videosider:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="89"/>
        <source>P&amp;referred quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="118"/>
        <source>Options for YouTube</source>
        <translation>YouTube-innstillinger</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="126"/>
        <source>Playback &amp;quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="154"/>
        <source>Use a&amp;daptive streams (resolution up to 4K)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="188"/>
        <source>Use &amp;60 fps if available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="209"/>
        <source>&amp;User agent:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="227"/>
        <source>YouTube support application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="253"/>
        <source>C&amp;hromecast</source>
        <translation>C&amp;hromecast</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="259"/>
        <source>Web Server</source>
        <translation>Nettverkstjener</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="271"/>
        <source>Changes in this section will be applied the next time the web server is restarted</source>
        <translation>Endringer i denne seksjonen, vil bli tatt i bruk neste gang tjeneren startes på nytt.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="291"/>
        <source>&amp;Directory listing</source>
        <translation>&amp;Mappeoppføring</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="298"/>
        <source>Local &amp;IP:</source>
        <translation>Lokal &amp;IP:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="344"/>
        <source>In order to serve local media from this computer to Chromecast, SMPlayer will run a tiny web server. You can adjust here some of the settings.</source>
        <translation>For å kunne sende lokale medier fra denne datamaskinen til en Chromecast, må din SMPlayer drifte en knøttliten nettverkstjener. Her kan du justere noen av innstillingene.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="371"/>
        <source>Subtitles</source>
        <translation>Undertekster</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="377"/>
        <source>Convert SRT subtitles to &amp;VTT</source>
        <translation>Konverter SRT-undertekster til &amp;VTT</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="409"/>
        <source>&amp;Overwrite existing VTT files</source>
        <translation>&amp;Overskriv eksisterende VTT-filer</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="416"/>
        <source>Try to &amp;remove advertisements</source>
        <translation>Prøv å &amp;fjerne reklamer</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="425"/>
        <source>Position of &amp;subtitles on screen:</source>
        <translation>Undertekstenes plassering på skjermen:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="480"/>
        <source>&amp;Proxy</source>
        <translation>&amp;Proxy</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="486"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Aktiver proxy</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="499"/>
        <source>&amp;Host:</source>
        <translation>&amp;Vert:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="321"/>
        <location filename="../prefnetwork.ui" line="512"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="200"/>
        <source>Allow AV&amp;1 codec</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="532"/>
        <source>&amp;Username:</source>
        <translation>&amp;Brukernavn:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="545"/>
        <source>Pa&amp;ssword:</source>
        <translation>Pa&amp;ssord:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="562"/>
        <source>&amp;Type:</source>
        <translation>&amp;Type:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="40"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="41"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="80"/>
        <source>Network</source>
        <translation>Nettverk</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="332"/>
        <source>it will try to use mpv + youtube-dl only for the sites that require it</source>
        <translation>Den vil prøve å bruke mpv + youtube-dl kun på de sidene som krever det.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="371"/>
        <source>User agent</source>
        <translation>Brukeragent</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="92"/>
        <location filename="../prefnetwork.cpp" line="330"/>
        <source>Disabled</source>
        <translation>Deaktivert</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="94"/>
        <location filename="../prefnetwork.cpp" line="299"/>
        <location filename="../prefnetwork.cpp" line="332"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="110"/>
        <location filename="../prefnetwork.cpp" line="347"/>
        <source>Best video and audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="118"/>
        <location filename="../prefnetwork.cpp" line="350"/>
        <source>Worst</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="326"/>
        <source>YouTube</source>
        <translation>YouTube</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="328"/>
        <source>Support for video sites</source>
        <translation>Støtte for videosider</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="330"/>
        <source>support for video sites is turned off</source>
        <translation>Støtte for videosider er skrudd av</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="335"/>
        <source>only the internal support for YouTube will be used</source>
        <translation>Kun den interne støtten for YouTube vil bli brukt</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="338"/>
        <source>uses mpv + youtube-dl for all sites</source>
        <translation>Bruker mpv + youtube-dl på alle sider</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="344"/>
        <source>Preferred quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="345"/>
        <source>This option specifies the preferred quality for the video streams handled by youtube-dl.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="347"/>
        <source>selects the best video and audio streams available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="111"/>
        <location filename="../prefnetwork.cpp" line="348"/>
        <source>Best</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="231"/>
        <source>yt-dlp (based on youtube-dl with improvements)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="249"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="348"/>
        <source>selects the best quality format available as a single file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="349"/>
        <source>1080p, 720p...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="349"/>
        <source>will try to use the selected resolution if available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="350"/>
        <source>selects the worst quality format available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="359"/>
        <source>Playback quality</source>
        <translation>Avspillingskvalitet</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="360"/>
        <source>Select the preferred quality for YouTube videos.</source>
        <translation>Velg den foretrukne kvaliteten på YouTube-videoene.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="363"/>
        <source>Use adaptive streams</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="364"/>
        <source>This option enables adaptive streams which can provide videos up to 4K.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="366"/>
        <source>Use 60 fps if available</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="367"/>
        <source>This option enables streams at 60 frames per second if available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="372"/>
        <source>Set the user agent that SMPlayer will use when connecting to YouTube.</source>
        <translation>Velg brukeragenten som SMPlayer skal bruke når den kobler opp til YouTube.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="385"/>
        <source>Chromecast</source>
        <translation>Chromecast</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="387"/>
        <source>Local IP</source>
        <translation>Lokal IP</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="388"/>
        <source>The local IP address of this computer. It will be passed to Chromecast so that it can access the files from this computer.</source>
        <translation>Denne datamaskinens lokale IP-adresse. Informasjonen om den vil bli sendt til din Chromecast, sånn at den kan få tilgang til filene på denne datamaskinen.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="392"/>
        <source>The port that the web server will use.</source>
        <translation>Porten som nettverkstjeneren skal bruke.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="394"/>
        <source>Directory listing</source>
        <translation>Mappeoppføring</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="395"/>
        <source>When the web server is running, any device in your network can access the files from this computer. If this option is on, any device can get a listing of the files in this computer. If this option is off, the list won&apos;t be available.</source>
        <translation>Når nettverkstjeneren kjører, kan alle enheter på nettverket ditt få tilgang til filene på denne datamaskinen. Hvis denne innstillingen er skrudd på, kan alle enheter få tilgang til en liste over filene på denne maskinen. Hvis innstillingen er skrudd av, vil ikke listen være tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="401"/>
        <source>Convert SRT subtitles to VTT</source>
        <translation>Konverter SRT-undertekster til VTT</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="402"/>
        <source>When this option is enabled SMPlayer will convert automatically subtitle files in SRT format to VTT format. The VTT subtitle will have the same filename but extension .vtt</source>
        <translation>Når denne innstillingen er skrudd på, vil SMPlayer automatisk konvertere undertekster i SRT-formatet til VTT-formatet. VTT-underteksten vil ha det samme filnavnet men med .vtt-filutvidelsen.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="405"/>
        <source>Overwrite existing VTT files</source>
        <translation>Overskriv eksisterende VTT-filer</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="406"/>
        <source>If this option is enabled SMPlayer will overwrite existing VTT files.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer overskrive eksisterende VTT-filer.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="408"/>
        <source>Try to remove advertisements</source>
        <translation>Prøv å fjerne reklamer</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="409"/>
        <source>If this option is enabled SMPlayer will try to find advertisements in the subtitles and remove them.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer prøve å finne reklamer i undertekstene og så fjerne dem.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="412"/>
        <source>Position of subtitles on screen</source>
        <translation>&amp;Undertekstenes plassering på skjermen</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="413"/>
        <source>This option sets the position on the screen where the subtitles are displayed.</source>
        <translation>Denne innstillingen bestemmer hvor på skjermen undertekstene skal vises.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="414"/>
        <source>0 is the top of the screen, 100 is the bottom of the screen.</source>
        <translation>0 er toppen av skjermen, mens 100 er bunnen av skjermen.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="415"/>
        <source>The special value -1 means the default position.</source>
        <translation>Spesialverdien -1 betyr at standardplasseringen skal brukes.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="419"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="421"/>
        <source>Enable proxy</source>
        <translation>Aktiver proxy</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="422"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Aktiver eller deaktiver bruken av en proxy.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="424"/>
        <source>Host</source>
        <translation>Vert</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="425"/>
        <source>The host name of the proxy.</source>
        <translation>Proxyens vertsnavn.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="391"/>
        <location filename="../prefnetwork.cpp" line="427"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="428"/>
        <source>The port of the proxy.</source>
        <translation>Proxyens port.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="430"/>
        <source>Username</source>
        <translation>Brukernavn</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="431"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Hvis proxyen krever pålogging, vil dette velge brukernavnet.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="433"/>
        <source>Password</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="434"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Proxyens passord. &lt;b&gt;Advarsel:&lt;/b&gt; passordet vil bli lagret som ren tekst i konfigurasjonsfilen.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="437"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="438"/>
        <source>Select the proxy type to be used.</source>
        <translation>Velg proxytypen som skal brukes.</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <location filename="../prefperformance.cpp" line="85"/>
        <location filename="../prefperformance.cpp" line="302"/>
        <source>Performance</source>
        <translation>Yteevne</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="27"/>
        <source>&amp;Performance</source>
        <translation>&amp;Yteevne</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="33"/>
        <location filename="../prefperformance.cpp" line="306"/>
        <source>Priority</source>
        <translation>Prioritering</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="77"/>
        <source>realtime</source>
        <translation>Direkte</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="82"/>
        <source>high</source>
        <translation>Høy</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="87"/>
        <source>abovenormal</source>
        <translation>Mer enn vanlig</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="92"/>
        <source>normal</source>
        <translation>Vanlig</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="97"/>
        <source>belownormal</source>
        <translation>Mindre enn vanlig</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="102"/>
        <source>idle</source>
        <translation>Hvilende</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="145"/>
        <source>Decoding</source>
        <translation>Dekoding</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="199"/>
        <source>Hardware &amp;decoding</source>
        <translation>Maskinvare&amp;dekoding</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="355"/>
        <source>A&amp;uto</source>
        <translation>A&amp;uto</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="391"/>
        <location filename="../prefperformance.ui" line="428"/>
        <location filename="../prefperformance.ui" line="465"/>
        <location filename="../prefperformance.ui" line="502"/>
        <location filename="../prefperformance.ui" line="539"/>
        <location filename="../prefperformance.ui" line="576"/>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="345"/>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Å velge en mellomlagring, kan øke yteevnen til trege medier</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="312"/>
        <source>Allow frame drop</source>
        <translation>Tillat å droppe sene bilder</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="313"/>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Hopp over å vise enkelte bilder for å opprettholde A/V-synkronisering på trege maskiner.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="315"/>
        <source>Allow hard frame drop</source>
        <translation>Tillat hardt bildedropp</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="316"/>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Mer intens bildedropping (Omgår dekoding). Det vil føre til bildeforstyrrelser!</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="63"/>
        <source>Priorit&amp;y:</source>
        <translation>Priorite&amp;t:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="131"/>
        <source>&amp;Allow frame drop</source>
        <translation>&amp;Tillat å droppe sene bilder</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="138"/>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation>Tillat &amp;hardt bildedropp (Kan føre til bildeforstyrrelser)</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="290"/>
        <source>&amp;Fast audio track switching</source>
        <translation>&amp;Rask skifting av lydspor</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="318"/>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation>Hurtig&amp;spol frem til kapitler i DVDer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="366"/>
        <source>Fast audio track switching</source>
        <translation>Rask skifting av lydspor</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="377"/>
        <source>Fast seek to chapters in dvds</source>
        <translation>Hurtigspol frem til kapitler i DVDer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="378"/>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation>Hvis dette er valgt, vil den prøve med den raskeste metoden å spole etter kapitler med, men det kan kanskje ikke fungere med noen disker.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="344"/>
        <source>Skip loop filter</source>
        <translation>Hopp over løkkefilter</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="230"/>
        <source>H.264</source>
        <translation>H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="367"/>
        <source>Possible values:&lt;br&gt; &lt;b&gt;Yes&lt;/b&gt;: it will try the fastest method to switch the audio track (it might not work with some formats).&lt;br&gt; &lt;b&gt;No&lt;/b&gt;: the MPlayer process will be restarted whenever you change the audio track.&lt;br&gt; &lt;b&gt;Auto&lt;/b&gt;: SMPlayer will decide what to do according to the MPlayer version.</source>
        <translation>Mulige verdier:&lt;br&gt; &lt;b&gt;Ja:&lt;/b&gt; Den vil prøve å bruke den raskeste metoden å skifte lydspor på (Det kan muligens ikke virke med noen formater).&lt;br&gt; &lt;b&gt;Nei&lt;/b&gt;: MPlayer-prosessen vil startes på nytt når enn du ønsker å skifte skifte lydsporet.&lt;be&gt; &lt;b&gt;Auto&lt;/b&gt;: SMPlayer vil bestemme hva som skal gjøres, avhengig av MPlayer-versjonen.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="387"/>
        <source>Cache for files</source>
        <translation>Mellomlagring for filer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="388"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation>Denne innstillingen bestemmer hvor mye minne (i kiloBytes) som skal brukes ved før-mellomlagring av en fil.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="391"/>
        <source>Cache for streams</source>
        <translation>Mellomlagring for strømmer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="392"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation>Denne innstillingen bestemmer hvor mye minne (i kiloBytes) som skal brukes ved før-mellomlagring av en nettadresse.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="395"/>
        <source>Cache for DVDs</source>
        <translation>Mellomlagring for DVDer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="396"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation>Denne innstillingen bestemmer hvor mye minne (i kiloBytes) som skal brukes ved før-mellomlagring av en DVD.&lt;br&gt;&lt;b&gt;Advarsel:&lt;/b&gt; Spoling kan kanskje ikke fungere riktig (inkludert under kapittelbytte) når du bruker et mellomlager for DVDer.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="339"/>
        <source>&amp;Cache</source>
        <translation>&amp;Mellomlager</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="448"/>
        <source>Cache for &amp;DVDs:</source>
        <translation>Mellomlagring for &amp;DVDer:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="374"/>
        <source>Cache for &amp;local files:</source>
        <translation>Mellomlagring for &amp;lokale filer:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="45"/>
        <source>Select the priority for the player process.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="411"/>
        <source>Cache for &amp;streams:</source>
        <translation>Mellomlagring for &amp;strømmer:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="100"/>
        <source>Enabled</source>
        <translation>Skrudd på</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="101"/>
        <source>Skip (always)</source>
        <translation>Hopp over (alltid)</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="102"/>
        <source>Skip only on HD videos</source>
        <translation>Hopp kun over i HD-videoer</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="244"/>
        <source>Loop &amp;filter</source>
        <translation>Løkke&amp;filter</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="345"/>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation>Denne innstillingen tillater å hoppe over løkkefiltre (altså avblokking) under H.264-dekodinger. Siden det filtrerte bildet er ment å brukes som en referanse for dekoding av avhengige bilder, har dette en verre effekt på kvaliteten enn å ikke deblokke f.eks. MPEG-2-videoer. Men for HD-TV-programmer med høye bitfrekvenser sørger dette for raskere innlastingen uten synlige kvalitetstap.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="33"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="34"/>
        <location filename="../prefperformance.cpp" line="384"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="307"/>
        <source>Set process priority for %1 according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Velger prosessprioriteten for %1 ifølge de forhåndsdefinerte prioritetene som Windows tilbyr.&lt;br&gt;&lt;b&gt;Advarsel:&lt;/b&gt; Å bruke fulltidsprioritet kan føre til systemfrys.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="323"/>
        <source>Hardware decoding</source>
        <translation>Maskinvaredekoding</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="324"/>
        <source>Sets the hardware video decoding API. If hardware decoding is not possible, software decoding will be used instead.</source>
        <translation>Velger APIen som skal brukes til maskinvaredekoding. Hvis maskinvaredekoding ikke er mulig, vil programvaredekoding brukes i stedet.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="326"/>
        <source>Available options:</source>
        <translation>Tilgjengelige innstillinger:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="328"/>
        <source>None: only software decoding will be used.</source>
        <translation>Ingen: Kun programvaredekoding vil bli brukt.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="329"/>
        <source>Auto: it tries to automatically enable hardware decoding using the first available method.</source>
        <translation>Auto: Den forsøker å automatisk starte opp maskinvarekoding med den første tilgjengelige metoden.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="331"/>
        <source>vdpau: for the vdpau and opengl video outputs.</source>
        <translation>vdpau: Til VDPAU- og OpenGL-videoutdataene.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="332"/>
        <source>vaapi: for the opengl and vaapi video outputs. For Intel GPUs only.</source>
        <translation>vaapi: Til OpenGL og VAAPI-videoutdataene. Kun for Intel-grafikkløsninger.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="333"/>
        <source>vaapi-copy: it copies video back into system RAM. For Intel GPUs only.</source>
        <translation>vaapi-copy: Den kopierer videoen tilbake til maskin-RAMen. Kun for Intel-skjermkort.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="336"/>
        <source>dxva2-copy: it copies video back to system RAM. Experimental.</source>
        <translation>dxva2-copy: Den kopierer videoen tilbake til maskin-RAMen. Eksperimentell.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="340"/>
        <source>This option only works with mpv.</source>
        <translation>Denne innstillingen fungerer bare med mpv.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="352"/>
        <source>Possible values:</source>
        <translation>Mulige verdier:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="353"/>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation>&lt;b&gt;Skrudd på&lt;/b&gt;: Løkkefilteret blir ikke hoppet over</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="354"/>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation>&lt;b&gt;Hopp alltid over&lt;/b&gt;: Løkkefilteret blir hoppet over, uansett hva videoens oppløsning er</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="356"/>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation>&lt;b&gt;Hopp kun over i HD-videoer&lt;/b&gt;: Løkkefilteret vil kun bli hoppet over for videoer som har en høyde på ≥%1.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="361"/>
        <source>Try to use the non-free CoreAVC codec when no other codec is specified and a non-VDPAU video output is selected.</source>
        <translation>Prøv med å bruke den ufrie CoreAVC-kodeken, dersom ingen andre kodeker er valgt og at en videoutdata uten VDPAU er valgt.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="363"/>
        <source>Requires a %1 build with CoreAVC support.</source>
        <translation>Krever en %1-versjon med CoreAVC-støtte.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="382"/>
        <source>Cache</source>
        <translation>Mellomlager</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="385"/>
        <source>Usually this option will enable the cache when it&apos;s necessary.</source>
        <translation>Vanligvis vil denne innstillingen aktivere mellomlageret når det er nødvendig.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="400"/>
        <source>Cache for audio CDs</source>
        <translation>Mellomlagring for lyd-CDer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="401"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation>Denne innstillingen bestemmer hvor mye minne (i kiloBytes) som skal brukes ved før-mellomlagring av en lyd-CD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="485"/>
        <source>Cache for &amp;audio CDs:</source>
        <translation>Mellomlagring for &amp;lyd-CDer:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="404"/>
        <source>Cache for VCDs</source>
        <translation>Mellomlagring for VCDer</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="405"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation>Denne innstillingen bestemmer hvor mye minne (i kiloBytes) som skal brukes ved før-mellomlagring av en VCD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="522"/>
        <source>Cache for &amp;VCDs:</source>
        <translation>Mellomlagring for &amp;VCDer:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="319"/>
        <source>Threads for decoding</source>
        <translation>Tråder til dekoding</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="320"/>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation>Velg antall tråder som skal brukes til dekoding. Kun for MPEG-1/2 og H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="159"/>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation>&amp;Tråder til dekoding (Kun for MPEG-1/2 og H.264):</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="360"/>
        <source>Use CoreAVC if no other codec specified</source>
        <translation>Bruk CoreAVC hvis ingen andre kodeker er spesifisert</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="272"/>
        <source>&amp;Use CoreAVC if no other codec specified</source>
        <translation>&amp;Bruk CoreAVC hvis ingen andre kodeker er spesifisert</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="559"/>
        <source>Cache for &amp;TV:</source>
        <translation>Mellomlagring for &amp;TV:</translation>
    </message>
</context>
<context>
    <name>PrefPlaylist</name>
    <message>
        <location filename="../prefplaylist.cpp" line="39"/>
        <source>Playlist</source>
        <translation>Spilleliste</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="208"/>
        <source>If this option is enabled, every time a file is opened, SMPlayer will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>Hvis denne innstillingen er valgt, vil SMPlayer tømme spillelisten hver gang en fil åpnes, og vil så legge til en fil til listen. Når det gjelder DVDer, CDer og VCDer, vil alle titlene på disken legges til i spillelisten.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="51"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="52"/>
        <source>Video files</source>
        <translation>Videofiler</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="53"/>
        <source>Audio files</source>
        <translation>Lydfiler</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="54"/>
        <source>Video and audio files</source>
        <translation>Video- og lyd-filer</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="55"/>
        <source>Consecutive files</source>
        <translation>Etterfølgende filer</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="197"/>
        <source>Start playback after loading a playlist</source>
        <translation>Start avspilling etter innlasting av en spilleliste</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="198"/>
        <source>Playback will start just after loading a playlist.</source>
        <translation>Avspillingen vil begynne rett etter innlasting av en spilleliste.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="200"/>
        <source>Play next file automatically</source>
        <translation>Spill av neste fil automatisk</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="201"/>
        <source>When a file reaches the end, the next file will be played automatically.</source>
        <translation>Når en fil er ferdig avspilt, starter den neste filen automatisk.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="203"/>
        <source>Ignore playback errors</source>
        <translation>Overse avspillingsfeilmeldinger</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="207"/>
        <source>Add files to the playlist automatically</source>
        <translation>Legg til filer i spillelisten automatisk</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="213"/>
        <source>Add files from folder</source>
        <translation>Legg til filer fra en mappe</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="234"/>
        <source>Display title name instead of filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="235"/>
        <source>The playlist will display the title (if any) instead of the filename.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="237"/>
        <source>The playlist window is dockable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="238"/>
        <source>If this option is checked, the playlist window can be docked inside the main window. Otherwise the playlist would be a regular window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="241"/>
        <source>Misc</source>
        <translation>Diverse</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="243"/>
        <source>Auto sort</source>
        <translation>Auto-sorter</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="244"/>
        <source>If this option is enabled the list will be sorted automatically after adding files.</source>
        <translation>Hvis dette alternativet er valgt, vil listen bli automatisk sortert når filer legges til.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="246"/>
        <source>Case sensitive search</source>
        <translation>Søk med forskjell på stor/liten bokstav</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="247"/>
        <source>This option specifies whether the search in the playlist is case sensitive or not.</source>
        <translation>Denne innstillingen bestemmer om spillelistesøkingen skiller mellom store/små bokstaver eller ikke.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="249"/>
        <source>Save a copy of the playlist on exit</source>
        <translation>Lagre en kopi av spillelisten ved lukking</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="250"/>
        <source>If this option is checked, a copy of the playlist will be saved in the configuration file when SMPlayer is closed, and it will reloaded automatically when SMPlayer is run again.</source>
        <translation>Hvis denne innstillingen er valgt, vil en kopi av spillelisten lagres i SMPlayer-konfigureringen når SMPlayer lukkes, og den vil automatisk bli lastet inn igjen når SMPlayer startes opp igjen.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="255"/>
        <source>Enable the option to delete files from disk</source>
        <translation>Aktiver muligheten til å slette filer fra harddisken</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="256"/>
        <source>This option allows you to enable the option to delete files from disk in the playlist&apos;s context menu. To prevent accidental deletions this option is disabled by default.</source>
        <translation>Denne innstillingen gjør at du aktivere muligheten til å slette filer fra disken i en spillelistes nedfallsmeny. For å hindre at ting blir slettet ved et uhell, er denne innstillingen deaktivert som standard.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="215"/>
        <source>&lt;b&gt;None&lt;/b&gt;: no files will be added</source>
        <translation>&lt;b&gt;Ingen:&lt;/b&gt; ingen filer vil bli lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="216"/>
        <source>&lt;b&gt;Video files&lt;/b&gt;: all video files found in the folder will be added</source>
        <translation>&lt;b&gt;Videofiler&lt;/b&gt;: Alle videofiler som blir funnet i mappen vil bli lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="217"/>
        <source>&lt;b&gt;Audio files&lt;/b&gt;: all audio files found in the folder will be added</source>
        <translation>&lt;b&gt;Lydfiler&lt;/b&gt;: Alle lydfiler som blir funnet i mappen vil bli lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="218"/>
        <source>&lt;b&gt;Video and audio files&lt;/b&gt;: all video and audio files found in the folder will be added</source>
        <translation>&lt;b&gt;Video- og lyd-filer&lt;/b&gt;: Alle video- og lyd-filer som blir funnet i mappen vil bli lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="219"/>
        <source>&lt;b&gt;Consecutive files&lt;/b&gt;: consecutive files (like video_1.avi, video_2.avi) will be added</source>
        <translation>&lt;b&gt;Etterfølgende filer&lt;/b&gt;: Etterfølgende filer (slik som video_1.avi, video_2.avi) vil bli lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="192"/>
        <source>Play files from start</source>
        <translation>Spill av filer fra begynnelsen</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="193"/>
        <source>If this option is enabled, all files from the playlist will start to play from the beginning instead of resuming from a previous playback.</source>
        <translation>Hvis denne innstillingen er valgt, vil alle filer i spillelisten startes fra begynnelsen i stedet for å fortsette fra en tidligere avspilling.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="214"/>
        <source>This option can be used to add files automatically to the playlist:</source>
        <translation>Denne innstillingen gjør at du automatisk kan legge til filer til spillelisten:</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="227"/>
        <source>Get info automatically about files added</source>
        <translation>Hent automatisk informasjon om filer som er lagt til</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="204"/>
        <source>If this option is enabled, the playlist will ignore playback errors from a previous file and will play the next file in the list.</source>
        <translation>Hvis denne innstillingen er valgt, vil spillelisten ignorere avspillingsfeil fra en tidligere fil og deretter spille av den neste filen på listen.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="24"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Spilleliste</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="222"/>
        <source>Add files in directories recursively</source>
        <translation>Legg til filer i plassering med tilbakevirking</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="223"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Velg denne innstillingen hvis du vil at det å legge til en mappe også skal legge til undermappene retroaktivt. Ellers vil kun filene i den valgte mappen legges til.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="228"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Velg dette alternativet for å forsøke å hente info fra filer som blir lagt til i spillelisten. Dette gjør det mulig å vise tittelnavnet (om tilgjengelig) og lengden til filene. Ellers vil denne infoen ikke være tilgjengelig før filen faktisk spilles av. Notis: Dette alternativet kan være treg, særlig hvis du legger til mange filer.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="101"/>
        <source>Add files from &amp;folder:</source>
        <translation>Legg til filer fra en &amp;mappe:</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="36"/>
        <source>P&amp;lay files from start</source>
        <translation>S&amp;pill av filer fra begynnelsen</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="30"/>
        <source>Playback</source>
        <translation>Avspilling</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="43"/>
        <source>S&amp;tart playback after loading a playlist</source>
        <translation>S&amp;tart avspilling etter innlasting av en spilleliste</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="50"/>
        <source>Pla&amp;y next file automatically</source>
        <translation>Spil&amp;l av neste fil automatisk</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="57"/>
        <source>Ig&amp;nore playback errors</source>
        <translation>O&amp;verse avspillingsfeilmeldinger</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="67"/>
        <source>Adding files</source>
        <translation>Legger til filer</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="73"/>
        <source>&amp;Add files to the playlist automatically</source>
        <translation>&amp;Legg til filer i spillelisten automatisk</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="133"/>
        <source>Add files in directories &amp;recursively</source>
        <translation>Legg til filer i plassering med &amp;tilbakevirking</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="140"/>
        <source>Get &amp;info automatically about files added (slow)</source>
        <translation>Hent automatisk informasjon om filer som er lagt til (Tregt)</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="157"/>
        <source>Display title name instead of &amp;filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="164"/>
        <source>The playlist window is &amp;dockable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="185"/>
        <source>&amp;Misc</source>
        <translation>&amp;Diverse</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="191"/>
        <source>A&amp;uto sort</source>
        <translation>A&amp;uto-sorter</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="198"/>
        <source>Cas&amp;e sensitive search</source>
        <translation>Sø&amp;k med forskjell på stor/liten bokstav</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="205"/>
        <source>&amp;Save a copy of the playlist on exit</source>
        <translation>&amp;Lagre en kopi av spillelisten ved lukking</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="212"/>
        <source>Enable the option to delete files from &amp;disk</source>
        <translation>Aktiver muligheten til å slette filer fra &amp;harddisken</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="61"/>
        <location filename="../prefsubtitles.cpp" line="400"/>
        <source>Subtitles</source>
        <translation>Undertekster</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="30"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Undertekster</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="39"/>
        <location filename="../prefsubtitles.cpp" line="402"/>
        <source>Autoload</source>
        <translation>Autoinnlasting</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>Same name as movie</source>
        <translation>Samme navn som filmen</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="230"/>
        <source>Use the &amp;ASS library</source>
        <translation>Bruk &amp;ASS-biblioteket</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="244"/>
        <source>Enable &amp;Windows fonts</source>
        <translation>Aktiver Windows-fonter</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="368"/>
        <location filename="../prefsubtitles.cpp" line="450"/>
        <location filename="../prefsubtitles.cpp" line="469"/>
        <source>Font</source>
        <translation>Font</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="472"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="51"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>La&amp;st automatisk inn undertekstfiler (*.srt, *.sub...):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="64"/>
        <source>S&amp;elect first available subtitle</source>
        <translation>V&amp;elg første tilgjengelige undertekst</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="77"/>
        <source>All subtitles containing the movie name</source>
        <translation>Alle undertekster som inneholder filmnavnet</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="82"/>
        <source>All subtitles in the directory</source>
        <translation>Alle undertekster i filplasseringen</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="123"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>&amp;Standard undertekstomkoding:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="210"/>
        <source>&amp;Include subtitles on screenshots</source>
        <translation>&amp;Inkluder undertekster i skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="405"/>
        <source>Select first available subtitle</source>
        <translation>Velg første tilgjengelige undertekst</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="411"/>
        <source>Default subtitle encoding</source>
        <translation>Standard undertekstomkoding</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="427"/>
        <source>Include subtitles on screenshots</source>
        <translation>Inkluder undertekster i skjermklipp</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="481"/>
        <source>Text color</source>
        <translation>Tekstfarge</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="482"/>
        <source>Select the color for the text of the subtitles.</source>
        <translation>Velg fargen til undertekstenes font.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="484"/>
        <source>Border color</source>
        <translation>Kantfarge</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="485"/>
        <source>Select the color for the border of the subtitles.</source>
        <translation>Velg fargen til undertekstkantene.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="403"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Velg autoinnlastningsmetoden for undertekster.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="406"/>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation>Hvis det er ett eller flere undertekstspor tilgjengelige, vil en av dem bli automatisk valgt, vanligvis den første. Skjønt hvis en av dem samstemmer med brukerens foretrukne språk, vil den bli brukt i stedet.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="412"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Velg standardomkodingen som skal brukes til undertekster som standard.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="415"/>
        <source>Try to autodetect for this language</source>
        <translation>Prøv å auto-oppdag for dette språket</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="422"/>
        <source>Subtitle language</source>
        <translation>Undertekstspråk</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="423"/>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation>Velg språket hvor du ønsker at kodingen skal gjettes automatisk.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="109"/>
        <source>Encoding</source>
        <translation>Omkoding</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="172"/>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation>Prøv å &amp;auto-oppdag for dette språket:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="511"/>
        <source>Outline</source>
        <translation>Kantlinje</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="470"/>
        <source>Select the font for the subtitles.</source>
        <translation>Velg fonten for undertekster.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="431"/>
        <source>Use the ASS library</source>
        <translation>Bruk ASS-biblioteket</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="432"/>
        <source>This option enables the ASS library, which allows to display subtitles with multiple colors, fonts...</source>
        <translation>Denne innstillingen aktiverer ASS-biblioteket, som tillater å vise undertekster i flere farger, fonter, og annet...</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="442"/>
        <source>Enable Windows fonts</source>
        <translation>Aktiver Windows-fonter</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="443"/>
        <source>If this option is enabled the Windows system fonts will be available for subtitles. There&apos;s an inconvenience: a font cache have to be created which can take some time.</source>
        <translation>Hvis dette alternativet er valgt, vil WIndows systemfonter være tilgjengelige til undertekstene. Det er en hake: et fontmellomlager må opprettes, som kan ta litt tid.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="446"/>
        <source>If this option is not checked then only a few fonts bundled with SMPlayer can be used, but this is faster.</source>
        <translation>Hvis dette alternativet ikke er valgt, vil bare noen få fonter som fulgte med SMPlayer kunne brukes, skjønt det vil være raskere slik.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="473"/>
        <source>The size in pixels.</source>
        <translation>Størrelsen i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="475"/>
        <source>Bold</source>
        <translation>Tykk</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="476"/>
        <source>If checked, the text will be displayed in &lt;b&gt;bold&lt;/b&gt;.</source>
        <translation>Hvis valgt, vil teksten vises som &lt;b&gt;fet&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="478"/>
        <source>Italic</source>
        <translation>Kursiv</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="479"/>
        <source>If checked, the text will be displayed in &lt;i&gt;italic&lt;/i&gt;.</source>
        <translation>Hvis valgt, vil teksten vises i &lt;i&gt;kursiv&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="490"/>
        <source>Left margin</source>
        <translation>Margin til venstre</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="491"/>
        <source>Specifies the left margin in pixels.</source>
        <translation>Spesifiserer marginen til venstre i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="493"/>
        <source>Right margin</source>
        <translation>Margin til høyre</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="494"/>
        <source>Specifies the right margin in pixels.</source>
        <translation>Spesifiserer marginen til høyre i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="496"/>
        <source>Vertical margin</source>
        <translation>Loddrett margin</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="497"/>
        <source>Specifies the vertical margin in pixels.</source>
        <translation>Spesifiserer den loddrette marginen i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="499"/>
        <source>Horizontal alignment</source>
        <translation>Vannrett justering</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="500"/>
        <source>Specifies the horizontal alignment. Possible values are left, centered and right.</source>
        <translation>Spesifiserer den vannrette justeringen. Mulige verdier: Sentrert, til venstre, og til høyre.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="503"/>
        <source>Vertical alignment</source>
        <translation>Loddrett justering</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="504"/>
        <source>Specifies the vertical alignment. Possible values: bottom, middle and top.</source>
        <translation>Spesifiserer den loddrette justeringen. Mulige verdier: Bunnen, midten, og toppen.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="507"/>
        <source>Border style</source>
        <translation>Kantstil</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="508"/>
        <source>Specifies the border style. Possible values: outline and opaque box.</source>
        <translation>Spesifiserer kantstilen. Mulige verdier: Kantlinjen, og boksens gjennomsiktighet.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="515"/>
        <source>Shadow</source>
        <translation>Skygge</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="519"/>
        <source>Apply style to ASS files too</source>
        <translation>Bruk stilen også til ASS-filer</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="386"/>
        <source>Si&amp;ze:</source>
        <translation>St&amp;ørrelse:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="428"/>
        <source>Bol&amp;d</source>
        <translation>Tyk&amp;k</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="435"/>
        <source>&amp;Italic</source>
        <translation>&amp;Kursiv</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="447"/>
        <source>Colors</source>
        <translation>Farger</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="456"/>
        <source>&amp;Text:</source>
        <translation>&amp;Tekst:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="482"/>
        <source>&amp;Border:</source>
        <translation>&amp;Kanter:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="534"/>
        <source>Margins</source>
        <translation>Marginer</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="543"/>
        <source>L&amp;eft:</source>
        <translation>V&amp;enstre</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="563"/>
        <source>&amp;Right:</source>
        <translation>&amp;Høyre:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="583"/>
        <source>Verti&amp;cal:</source>
        <translation>Loddr&amp;ett:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="619"/>
        <source>Alignment</source>
        <translation>Justering</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="628"/>
        <source>&amp;Horizontal:</source>
        <translation>&amp;Vannrett:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="644"/>
        <source>&amp;Vertical:</source>
        <translation>&amp;Loddrett:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="665"/>
        <source>Border st&amp;yle:</source>
        <translation>Kantst&amp;il:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="694"/>
        <source>Opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="730"/>
        <source>&amp;Outline:</source>
        <translation>&amp;Kantlinje:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="750"/>
        <source>Shado&amp;w:</source>
        <translation>Skygg&amp;e:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="790"/>
        <source>A&amp;pply style to ASS files too</source>
        <translation>B&amp;ruk stilen også til ASS-filer</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="839"/>
        <source>Use custo&amp;m style</source>
        <translation>Bruk tilpas&amp;set stil</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="466"/>
        <source>The following options allows you to define the style to be used for non-styled subtitles (srt, sub...).</source>
        <translation>De følgende innstillingene tillater deg å definere stilen som skal brukes til undertekster uten innebygde stiler (.srt, .sub...).</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="106"/>
        <source>Left</source>
        <comment>horizontal alignment</comment>
        <translation>Til venstre</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="107"/>
        <source>Centered</source>
        <comment>horizontal alignment</comment>
        <translation>Sentrert</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="108"/>
        <source>Right</source>
        <comment>horizontal alignment</comment>
        <translation>Til høyre</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="113"/>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation>Bunnen</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="114"/>
        <source>Middle</source>
        <comment>vertical alignment</comment>
        <translation>Midten</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="115"/>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation>Toppen</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="120"/>
        <source>Outline</source>
        <comment>border style</comment>
        <translation>Kantlinje</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="121"/>
        <source>Opaque box</source>
        <comment>border style</comment>
        <translation>Gjennomsiktig boks</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="416"/>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a %1 with ENCA support.</source>
        <translation>Når denne innstillingen er valgt, vil undertekstenes koding bli forsøkt autooppdaget for det valgte språket. Det vil falle tilabke til standardkoding hvis autooppdagingen mislykkes. Denne innstillingen krever en %1 med ENCA-støtte.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="436"/>
        <source>You should normally not disable this option. Do it only if your %1 is compiled without freetype support. &lt;b&gt;Disabling this option could make subtitles not to work at all!&lt;/b&gt;</source>
        <translation>Du burde vanligvis ikke skru av dette alternativet. Gjør det bare hvis din %1 er kompilert uten Freetype-støtte. &lt;b&gt;Å skru av dette alternativet, kan gjøre at undertekster ikke fungerer i det hele tatt!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="512"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the width of the outline around the text in pixels.</source>
        <translation>Hvis kantstilen er satt til &lt;i&gt;kantlinje&lt;/i&gt;, vil denne innstillingen bestemme bredden til kantlinjen rundt teksten i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="516"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the depth of the drop shadow behind the text in pixels.</source>
        <translation>Hvis kantstilen er satt til &lt;i&gt;kantlinje&lt;/i&gt;, vil denne innstillingen bestemme dybden til bakgrunnsskyggen bak teksten i piksler.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="452"/>
        <source>This option does NOT change the size of the subtitles in the current video. To do so, use the options &lt;i&gt;Size+&lt;/i&gt; and &lt;i&gt;Size-&lt;/i&gt; in the subtitles menu.</source>
        <translation>Denne innstillingen endrer IKKE på undertekstenes størrelse i den nåværende videoen. For å gjøre det, bruk innstillingene &lt;i&gt;Størrelse +&lt;/i&gt; og &lt;i&gt;Størrelse -&lt;/i&gt; i Undertekst-menyen.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="456"/>
        <source>Default scale</source>
        <translation>Standard skalering</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="457"/>
        <source>This option specifies the default font scale for SSA/ASS subtitles which will be used for new opened files.</source>
        <translation>Denne innstillingen bestemmer standardfontskaleringen for SSA/ASS-undertekster som skal brukes for nyåpnede filer.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="461"/>
        <source>Line spacing</source>
        <translation>Mellomrom mellom linjer</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="462"/>
        <source>This specifies the spacing that will be used to separate multiple lines. It can have negative values.</source>
        <translation>Dette velger mellomrommet som skal brukes til å skille mellom linjer. Man kan også velge et negativt tall.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="271"/>
        <source>&amp;Font and colors</source>
        <translation>&amp;Font og farger</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="298"/>
        <source>Defa&amp;ult scale:</source>
        <translation>Stand&amp;ard skalering:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="337"/>
        <source>&amp;Line spacing:</source>
        <translation>&amp;Mellomrom mellom linjer:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="435"/>
        <source>Freetype support</source>
        <translation>Freetype-støtte</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="237"/>
        <source>Freet&amp;ype support</source>
        <translation>Freet&amp;ype-støtte</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="428"/>
        <source>If this option is checked, the subtitles will appear in the screenshots. &lt;b&gt;Note:&lt;/b&gt; it may cause some troubles sometimes.</source>
        <translation>Hvis dette alternativet er valgt, vil undertekster vises i skjermklippene. &lt;b&gt;Bemerk:&lt;/b&gt; Det kan forårsake noen problemer i blant.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="349"/>
        <source>Customize SSA/ASS style</source>
        <translation>Tilpass SSA/ASS-stil</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="350"/>
        <source>Here you can enter your customized SSA/ASS style.</source>
        <translation>Her kan du velge din tilpassede SSA/ASS-stil.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="351"/>
        <source>Clear the edit line to disable the customized style.</source>
        <translation>Fjern alt i redigeringslinjen for å skru av den tilpassede stilen.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="465"/>
        <source>SSA/ASS style</source>
        <translation>SSA/ASS-stil</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="487"/>
        <source>Shadow color</source>
        <translation>Skyggefarge</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="488"/>
        <source>This color will be used for the shadow of the subtitles.</source>
        <translation>Fargen vil bli brukt til undertekstenes skygge.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="508"/>
        <source>Shadow:</source>
        <translation>Skygge:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="813"/>
        <source>Custo&amp;mize...</source>
        <translation>Til&amp;pass...</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="520"/>
        <source>If this option is checked, the style defined above will be applied to ass subtitles too.</source>
        <translation>Hvis dette alternativet er valgt, vil stilen som er valgt ovenfor også bli gjeldende for ASS-undertekster.</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <location filename="../preftv.cpp" line="41"/>
        <source>TV and radio</source>
        <translation>TV og radio</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="53"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="54"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="55"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (normal)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="56"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (dobbel bildefrekvens)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="57"/>
        <source>Linear Blend</source>
        <translation>Lineær sammenblanding</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="58"/>
        <source>Kerndeint</source>
        <translation>Kerndeint</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="105"/>
        <source>Deinterlace by default for TV</source>
        <translation>Avflett som standard for TV</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="106"/>
        <source>Select the deinterlace filter that you want to be used for TV channels.</source>
        <translation>Velg avflettingsfilteret du vil bruke til TV-kanaler.</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="109"/>
        <source>Rescan ~/.mplayer/channels.conf on startup</source>
        <translation>Skann ~/.mplayer/channels.conf på nytt ved oppstart</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="32"/>
        <source>&amp;TV and radio</source>
        <translation>&amp;TV og radio</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="55"/>
        <source>Dei&amp;nterlace by default for TV:</source>
        <translation>Av&amp;flett som standard for TV:</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="110"/>
        <source>If this option is enabled, SMPlayer will look for new TV and radio channels on ~/.mplayer/channels.conf.ter or ~/.mplayer/channels.conf.</source>
        <translation>Hvis dette alternativet er valgt, vil SMPlayer lete etter nye TV- og radio-kanaler i ~/.mplayer/channels.conf.ter eller ~/.mplayer/channels.conf.</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="90"/>
        <source>&amp;Check for new channels on startup</source>
        <translation>&amp;Se etter nye kanaler ved oppdatering</translation>
    </message>
</context>
<context>
    <name>PrefUpdates</name>
    <message>
        <location filename="../prefupdates.ui" line="24"/>
        <source>U&amp;pdates</source>
        <translation>O&amp;ppdateringer</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="30"/>
        <source>Check for &amp;updates</source>
        <translation>Se etter &amp;oppdateringer</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="62"/>
        <source>Check interval (in &amp;days)</source>
        <translation>Tidsrom mellom søk (i &amp;dager)</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="104"/>
        <source>&amp;Open an informative page after an upgrade</source>
        <translation>&amp;Åpne en informasjonsside etter en oppgradering</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="46"/>
        <source>Updates</source>
        <translation>Oppdateringer</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="86"/>
        <source>Check for updates</source>
        <translation>Se etter oppdateringer</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="87"/>
        <source>If this option is enabled, SMPlayer will check for updates and display a notification if a new version is available.</source>
        <translation>Hvis denne innstillingenen er valgt, vil SMPlayer lete etter oppdateringer og informere deg hvis en ny versjon er tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="90"/>
        <source>Check interval</source>
        <translation>Intervall mellom letinger</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="91"/>
        <source>You can enter here the interval (in days) for the update checks.</source>
        <translation>Du kan her velge tidsrommet (i dager) mellom oppdateringssjekkene.</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="95"/>
        <source>Open an informative page after an upgrade</source>
        <translation>Åpne en informasjonsside etter en oppgradering</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="96"/>
        <source>If this option is enabled, an informative page about SMPlayer will be opened after an upgrade.</source>
        <translation>Hvis dette alternativet er valgt, vil en informasjonsside om SMPlayer åpnes etter en oppgradering.</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="171"/>
        <source>SMPlayer - Help</source>
        <translation>SMPlayer - Hjelp</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation>Bruk</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="13"/>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer - Preferanser</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="183"/>
        <source>will show this message and then will exit.</source>
        <translation>vil vise denne meldingen og så lukkes.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="150"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>Hovedvinduet vil lukkes når filen/spillelisten er ferdig.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="605"/>
        <source>This is SMPlayer v. %1 running on %2</source>
        <translation>Dette er SMPlayer ver. %1 som kjører på %2</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="135"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>Prøver å lage en tilkobling til en annen kjørende instans og så sende den spesifiserte handlingen til den. Eksempel: -send-action pause&lt;br&gt;Resten av innstillingene (hvis det er noen) vil bli ignorert og programmet vil bli lukket. Det vil melde tilbake med 0 ved suksess eller -1 hvis det mislyktes.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="142"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>Handlingsliste er en liste over handlinger, som er adskilt med mellomrom. Handlingene vil bli eskekvert rett etter innlasting av filen (hvis det er noen) i den rekkefølgen som du skrev dem her. For avkryssbare handlinger kan du føre opp &quot;true&quot; eller &quot;false&quot; som parametre. Eksempel: -actions &quot;fullscreen compact true&quot;. Hermetegn er nødvendig hvis du trenger å sende av gårde mer enn én handling.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="100"/>
        <location filename="../clhelp.cpp" line="192"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="186"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>Hvis det er en annen kjørende prosess, vil mediet bli lagt til i den prosessens spilleliste. Hvis det ikke er noen andre prosesser, vil denne innstillingen bli ignorert, og filene vil bli åpnet i en ny prosess.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="153"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>Hovedvinduet vil ikke lukkes når filen/spillelisten er ferdig.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="156"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>Denne videoen vil bli spilt av i fullskjermsmodus.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="159"/>
        <source>the video will be played in window mode.</source>
        <translation>Denne videoen vil bli spilt av i vindusmodus.</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="254"/>
        <source>Enqueue in SMPlayer</source>
        <translation>Sett i kø i SMPlayer</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="117"/>
        <source>opens the mini gui instead of the default one.</source>
        <translation>Åpner minigrensesnittet i stedet for den vanlige.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Fjerner de gamle filtilknytningene og rydder opp i registeret.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <location filename="../clhelp.cpp" line="109"/>
        <source>Usage:</source>
        <translation>Bruk:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="95"/>
        <source>directory</source>
        <translation>plassering</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="96"/>
        <source>action_name</source>
        <translation>handlingsnavn</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="97"/>
        <source>action_list</source>
        <translation>Handlingsliste</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="123"/>
        <source>opens the default gui.</source>
        <translation>Åpner standardgrensesnittet.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="98"/>
        <source>subtitle_file</source>
        <translation>undertekst_fil</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="168"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>Velger undertekstfilen som skal lastes inn til den første videoen.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="127"/>
        <location filename="../helper.cpp" line="133"/>
        <source>%n second(s)</source>
        <translation>
            <numerusform>%n sekund</numerusform>
            <numerusform>%n sekunder</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="130"/>
        <location filename="../helper.cpp" line="132"/>
        <source>%n minute(s)</source>
        <translation>
            <numerusform>%n minutt</numerusform>
            <numerusform>%n minutter</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="134"/>
        <source>%1 and %2</source>
        <translation>%1 og %2</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="131"/>
        <source>specifies the directory where smplayer will store its configuration files (smplayer.ini, smplayer_files.ini...)</source>
        <translation>spesifiserer plasseringen hvor SMPlayer vil lagre sine konfigureringsfiler (smplayer.ini, smplayer_files.ini...)</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="188"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>Deaktivert</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="199"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="200"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>Ukjent</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="120"/>
        <source>opens the mpc gui.</source>
        <translation>Åpner det grafiske mpc-grensesnittet.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="99"/>
        <source>width</source>
        <translation>Bredde</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="99"/>
        <source>height</source>
        <translation>Høyde</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="101"/>
        <source>time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the gui with support for skins.</source>
        <translation>Åpner grensesnittet med støtte for utseender.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="162"/>
        <source>sets the stay on top option to always.</source>
        <translation>Setter &quot;Alltid øverst&quot;-innstillingen til Alltid.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="165"/>
        <source>sets the stay on top option to never.</source>
        <translation>Setter &quot;Alltid øverst&quot;-innstillingen til Aldri.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="171"/>
        <source>sets the media title for the first video.</source>
        <translation>Velger medienavnet til den første videoen.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="174"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>spesifiserer koordinatene hvor hovedvinduet vil bli vist.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="177"/>
        <source>specifies the size of the main window.</source>
        <translation>Velger størrelsen på hovedvinduet.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="180"/>
        <source>specifies the start time (in seconds) of the first file to be played. Also valid h:m:s and m:s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="192"/>
        <source>&apos;media&apos; is any kind of file that SMPlayer can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls.</source>
        <translation>&apos;medie&apos; er en hver type fil som SMPlayer kan åpne. Det kan være en lokal fil, en DVD (f.eks. dvd://1), en internettstrøm (f.eks. mms://....), eller en lokal spilleliste i m3u- eller pls-formatene.</translation>
    </message>
    <message>
        <location filename="../sharedata.cpp" line="40"/>
        <source>SMPlayer is my favorite media player for my PC. Check it out!</source>
        <comment>This text is to be published on twitter and the translation should not be more than 99 characters long</comment>
        <translation>SMPlayer ba meg om å skrive dette for å spre ordet, om denne gode mediespilleren!</translation>
    </message>
    <message>
        <location filename="../version.cpp" line="44"/>
        <source>%1 (revision %2) %3</source>
        <translation>%1 (revisjon %2) %3</translation>
    </message>
    <message>
        <location filename="../version.cpp" line="46"/>
        <source>%1 (revision %2)</source>
        <translation>%1 (revisjon %2)</translation>
    </message>
</context>
<context>
    <name>ShareDialog</name>
    <message>
        <location filename="../sharedialog.ui" line="14"/>
        <source>Support SMPlayer</source>
        <translation>Støtt SMPlayer</translation>
    </message>
    <message>
        <location filename="../sharedialog.ui" line="89"/>
        <source>&amp;Remind me later</source>
        <translation>&amp;Minn meg på det senere</translation>
    </message>
    <message>
        <location filename="../sharedialog.cpp" line="33"/>
        <source>Donate with PayPal</source>
        <translation>Donér med PayPal</translation>
    </message>
    <message>
        <location filename="../sharedialog.cpp" line="47"/>
        <source>You can support SMPlayer by sending a donation or sharing it with your friends.</source>
        <translation>Du kan støtte SMPlayer ved å sende en donasjon eller ved å dele det med vennene dine.</translation>
    </message>
</context>
<context>
    <name>ShareWidget</name>
    <message>
        <location filename="../sharewidget.cpp" line="113"/>
        <source>Donate with PayPal</source>
        <translation>Donér med PayPal</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="114"/>
        <source>Share SMPlayer in Facebook</source>
        <translation>Del SMPlayer på Facebook</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="115"/>
        <source>Share SMPlayer in Twitter</source>
        <translation>Del SMPlayer på Twitter</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="117"/>
        <source>Support SMPlayer</source>
        <translation>Støtt SMPlayer</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="118"/>
        <source>Donate / Share SMPlayer with your friends</source>
        <translation>Donér, eller del SMPlayer med dine venner</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="267"/>
        <source>Modify shortcut</source>
        <translation>Endre snarvei</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="310"/>
        <source>Clear</source>
        <translation>Fjern</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Press the key combination you want to assign</source>
        <translation>Trykk inn knappekombinasjonen du vil knytte til</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="280"/>
        <source>Add shortcut</source>
        <translation>Legg til snarvei</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="284"/>
        <source>Remove shortcut</source>
        <translation>Fjern snarvei</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="312"/>
        <source>Capture</source>
        <translation>Ta opp</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="313"/>
        <source>Capture keystrokes</source>
        <translation>Ta opp tastaturtrykk</translation>
    </message>
</context>
<context>
    <name>ShutdownDialog</name>
    <message>
        <location filename="../shutdowndialog.ui" line="14"/>
        <source>Shutting down computer</source>
        <translation>Skrur av datamaskinen</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="41"/>
        <source>Playback has finished. SMPlayer is about to exit.</source>
        <translation>Avspillingen er ferdig. SMPlayer er i ferd med å lukkes.</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="42"/>
        <source>The computer will shut down in %1 seconds.</source>
        <translation>Datamaskinen vil skrus av om %1 sekunder.</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="42"/>
        <source>Press &lt;b&gt;Cancel&lt;/b&gt; to abort shutdown.</source>
        <translation>Trykk &lt;b&gt;Lukk&lt;/b&gt; for å ikke skru av.</translation>
    </message>
</context>
<context>
    <name>SkinGui</name>
    <message>
        <location filename="../skingui/skingui.cpp" line="391"/>
        <source>&amp;Toolbars</source>
        <translation>&amp;Verktøylinjer</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="394"/>
        <source>Status&amp;bar</source>
        <translation>Status&amp;linje</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="397"/>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Hovedverktøylinje</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="401"/>
        <source>Edit main &amp;toolbar</source>
        <translation>Rediger hoved&amp;verktøylinjen</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="403"/>
        <source>Edit &amp;floating control</source>
        <translation>Rediger &amp;svevende kontroller</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="407"/>
        <source>&amp;Video info</source>
        <translation>&amp;Videoinfo</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="408"/>
        <source>&amp;Scroll title</source>
        <translation>&amp;Rull tittelen</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="416"/>
        <source>Playing</source>
        <translation>Spiller av</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="417"/>
        <source>Pause</source>
        <translation>Pause</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="418"/>
        <source>Stop</source>
        <translation>Stopp</translation>
    </message>
</context>
<context>
    <name>Stereo3dDialog</name>
    <message>
        <location filename="../stereo3ddialog.ui" line="14"/>
        <source>Stereo 3D filter</source>
        <translation>3D-visningsfilter</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.ui" line="20"/>
        <source>&amp;3D format of the video:</source>
        <translation>&amp;Videoens 3D-format:</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.ui" line="33"/>
        <source>&amp;Output format:</source>
        <translation>&amp;Utdataformat:</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="26"/>
        <source>Side by side parallel (left eye left, right eye right)</source>
        <translation>Sidestilt parallelt (venstre øye for venstre, høyre øye for høyre)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="27"/>
        <source>Side by side crosseye (right eye left, left eye right)</source>
        <translation>Sidestilt for kryssøyne (høyre øye for venstre, venstre øye for høyre)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="28"/>
        <source>Side by side with half width resolution (left eye left, right eye right)</source>
        <translation>Sidestilt med halvert breddeoppløsning (venstre øye for venstre, høyre øye for høyre)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="29"/>
        <source>Side by side with half width resolution (right eye left, left eye right)</source>
        <translation>Sidestilt med halvert breddeoppløsning (høyre øye for venstre, venstre øye for høyre)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="31"/>
        <source>Above-below (left eye above, right eye below)</source>
        <translation>Loddrett oppstilt (venstre øye øverst, høyre øye nederst)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="32"/>
        <source>Above-below (right eye above, left eye below)</source>
        <translation>Loddrett oppstilt (høyre øye øverst, venstre øye nederst)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="33"/>
        <source>Above-below with half height resolution (left eye above, right eye below)</source>
        <translation>Loddrett oppstilt med halvert breddeoppløsning (venstre øye øverst, høyre øye nederst)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="34"/>
        <source>Above-below with half height resolution (right eye above, left eye below)</source>
        <translation>Loddrett oppstilt med halvert breddeoppløsning (høyre øye øverst, venstre øye nederst)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="41"/>
        <source>Anaglyph red/cyan gray</source>
        <translation>Anaglyf rød-cyan, grå</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="42"/>
        <source>Anaglyph red/cyan half colored</source>
        <translation>Anaglyf rød-cyan, halvfarget</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="43"/>
        <source>Anaglyph red/cyan color</source>
        <translation>Anaglyf rød-cyan, farge</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="44"/>
        <source>Anaglyph red/cyan color optimized with the least-squares projection of Dubois</source>
        <translation>Anaglyf rød-cyan-farging, optimalisert med Dubois sin færreste-firkanter-projeksjon.</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="46"/>
        <source>Anaglyph green/magenta gray</source>
        <translation>Anaglyf grønn-magenta, grå</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="47"/>
        <source>Anaglyph green/magenta half colored</source>
        <translation>Anaglyf grønn-magenta, halvfarget</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="48"/>
        <source>Anaglyph green/magenta colored</source>
        <translation>Anaglyf grønn-magenta, farge</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="50"/>
        <source>Anaglyph yellow/blue gray</source>
        <translation>Anaglyf gul-blå, grå</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="51"/>
        <source>Anaglyph yellow/blue half colored</source>
        <translation>Anaglyf gul-blå, halvfarget</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="52"/>
        <source>Anaglyph yellow/blue colored</source>
        <translation>Anaglyf gul-blå, farge</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="54"/>
        <source>Interleaved rows (left eye has top row, right eye starts on next row)</source>
        <translation>Sammenflettede rekker (venstre øye har toppraden, høyre øye har neste rad)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="55"/>
        <source>Interleaved rows (right eye has top row, left eye starts on next row)</source>
        <translation>Sammenflettede rekker (høyre øye har toppraden, venstre øye har neste rad)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="57"/>
        <source>Mono output (left eye only)</source>
        <translation>Mono-utdata (kun venstre øye)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="58"/>
        <source>Mono output (right eye only)</source>
        <translation>Mono-utdata (kun høyre øye)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="60"/>
        <source>None</source>
        <translation>Ingen</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="61"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Undertekstvalg</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Dette arkivet inneholder mer enn én undertekstfil. Vennligst velg de som du vil ekstraktere.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Velg alle</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Velg ingen</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="115"/>
        <source>Channel editor</source>
        <translation>Kanalredigering</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="116"/>
        <source>TV/Radio list</source>
        <translation>TV- og radio-liste</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Hopp til:</translation>
    </message>
    <message>
        <location filename="../timedialog.cpp" line="26"/>
        <source>SMPlayer - Seek</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolbarEditor</name>
    <message>
        <location filename="../toolbareditor.ui" line="14"/>
        <source>Toolbar Editor</source>
        <translation>Verktøylinjeredigering</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="22"/>
        <source>&amp;Available actions:</source>
        <translation>Tilgjengelige handlinger:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="57"/>
        <source>&amp;Left</source>
        <translation>&amp;Venstre</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="67"/>
        <source>&amp;Right</source>
        <translation>&amp;Høyre</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="77"/>
        <source>&amp;Down</source>
        <translation>&amp;Ned</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="87"/>
        <source>&amp;Up</source>
        <translation>&amp;Opp</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="113"/>
        <source>Curre&amp;nt actions:</source>
        <translation>Nåvær&amp;ende handlinger:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="130"/>
        <source>&amp;Icon size:</source>
        <translation>&amp;Ikonstørrelse:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="163"/>
        <source>Add &amp;separator</source>
        <translation>Legg til &amp;skillepinne</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="255"/>
        <source>Time slider</source>
        <translation>Tidsmåler</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="257"/>
        <source>Volume slider</source>
        <translation>Volummåler</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="259"/>
        <source>Display time</source>
        <translation>Vis tid</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="261"/>
        <source>Current time</source>
        <translation>Nåværende tid</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="263"/>
        <source>Total time</source>
        <translation>Total tid</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="265"/>
        <source>Remaining time</source>
        <translation>Gjenværende tid</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="267"/>
        <source>3 in 1 rewind</source>
        <translation>3-i-1-tilbakespoling</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="269"/>
        <source>3 in 1 forward</source>
        <translation>3-i-1-fremspoling</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="271"/>
        <source>Quick access menu</source>
        <translation>Hurtigtilgangsmeny</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="34"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="35"/>
        <source>Yes</source>
        <translation>Ja</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>No</source>
        <translation>Nei</translation>
    </message>
</context>
<context>
    <name>UpdateChecker</name>
    <message>
        <location filename="../updatechecker.cpp" line="167"/>
        <source>Failed to get the latest version number</source>
        <translation>Klarte ikke å hente det seneste versjonnummeret</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="202"/>
        <source>New version available</source>
        <translation>En ny versjon er tilgjengelig</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="203"/>
        <source>A new version of SMPlayer is available.</source>
        <translation>En ny versjon av SMPlayer er tilgjengelig.</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="204"/>
        <location filename="../updatechecker.cpp" line="221"/>
        <source>Installed version: %1</source>
        <translation>Installert versjon: %1</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="205"/>
        <location filename="../updatechecker.cpp" line="222"/>
        <source>Available version: %1</source>
        <translation>Tilgjengelig versjon: %1</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="206"/>
        <source>Would you like to know more about this new version?</source>
        <translation>Vil du vite mer om denne nye versjonen?</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="219"/>
        <source>Checking for updates</source>
        <translation>Se etter oppdateringer</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="220"/>
        <source>Congratulations, SMPlayer is up to date.</source>
        <translation>Gratulerer, din SMPlayer er allerede fullt oppdatert.</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="227"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="228"/>
        <source>An error happened while trying to retrieve information about the latest version available.</source>
        <translation>En feil oppstod under et forsøk på å hente informasjon om den nyeste tilgjengelige versjonen.</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="229"/>
        <source>Error code: %1</source>
        <translation>Feilkode: %1</translation>
    </message>
</context>
<context>
    <name>VDPAUProperties</name>
    <message>
        <location filename="../vdpauproperties.ui" line="14"/>
        <source>VDPAU Properties</source>
        <translation>VDPAU-egenskaper</translation>
    </message>
    <message>
        <location filename="../vdpauproperties.ui" line="20"/>
        <source>Select the vdpau codecs to use. Not all of them may work.</source>
        <translation>Velg vdpau-kodekene du vil bruke. Det kan hende at ikke alle sammen virker.</translation>
    </message>
    <message>
        <location filename="../vdpauproperties.ui" line="79"/>
        <source>&amp;Disable software video filters</source>
        <translation>&amp;Skru av programvarevideofiltre</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.ui" line="14"/>
        <source>Video Equalizer</source>
        <translation>Videotonekontroll</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="22"/>
        <source>&amp;Contrast</source>
        <translation>&amp;Kontrast</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="76"/>
        <source>&amp;Brightness</source>
        <translation>&amp;Lysstyrke</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="130"/>
        <source>&amp;Hue</source>
        <translation>&amp;Kulør</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="184"/>
        <source>&amp;Saturation</source>
        <translation>&amp;Fargemetning</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="238"/>
        <source>&amp;Gamma</source>
        <translation>&amp;Gamma</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="309"/>
        <source>Software &amp;equalizer</source>
        <translation>Programvare&amp;tonekontroll</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="316"/>
        <source>Set as &amp;default values</source>
        <translation>Sett som &amp;standardverdier</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="323"/>
        <source>&amp;Reset</source>
        <translation>&amp;Tilbakestill</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="330"/>
        <source>&amp;Close</source>
        <translation>&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Bruk de nåværende verdiene som standardverdier for nye videoer.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="103"/>
        <source>Set all controls to zero.</source>
        <translation>Sett alle kontrollene til 0.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>Video preview</source>
        <translation>Videoforhåndsvisning</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="169"/>
        <source>Cancel</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="128"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="129"/>
        <source>&amp;Save</source>
        <translation type="unfinished">&amp;Lagre</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="168"/>
        <source>Thumbnail Generator</source>
        <translation>Forhåndsvisningsgenerator</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="257"/>
        <source>Creating thumbnails...</source>
        <translation>Lager forhåndsvisninger...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="516"/>
        <source>Size: %1 MB</source>
        <translation>Størrelse: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="518"/>
        <source>Length: %1</source>
        <translation>Lengde: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="520"/>
        <source>FPS: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="522"/>
        <source>Audio format: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="697"/>
        <source>Save file</source>
        <translation>Lagre fil</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="714"/>
        <source>Error saving file</source>
        <translation>Feil ved lagring av fil</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="715"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Filen kunne ikke lagres</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="213"/>
        <source>Error</source>
        <translation>Feil</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="214"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>Den følgende feilen oppstod under oppretting av forhåndsvisningene:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="240"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Den midlertidige mappen (%1) kunne ikke opprettes</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="403"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>MPlayer-prosessen kjørte ikke</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="517"/>
        <source>Resolution: %1x%2</source>
        <translation>Oppløsning: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="521"/>
        <source>Video format: %1</source>
        <translation>Videoformat: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="524"/>
        <source>Aspect ratio: %1</source>
        <translation>Visningsaspekt: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="423"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>%1-filen kunne ikke lastes inn</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="561"/>
        <source>No filename</source>
        <translation>Ingen filnavn</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="655"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Mplayer-prosessen mislyktes i å starte opp mens den prøvde å hente info om videoen</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="231"/>
        <source>The length of the video is 0</source>
        <translation>Lengden på denne videoen er 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="275"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>%1-filen finnes ikke</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="698"/>
        <source>Images</source>
        <translation>Bilder</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="501"/>
        <source>No info</source>
        <translation>Ingen informasjon</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="504"/>
        <location filename="../videopreview/videopreview.cpp" line="505"/>
        <source>%1 kbps</source>
        <translation>%1 Kb/s</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="506"/>
        <source>%1 Hz</source>
        <translation>%1Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Video bitrate: %1</source>
        <translation>Videobitfrekvens: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Audio bitrate: %1</source>
        <translation>Lydbitfrekvens: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="528"/>
        <source>Audio rate: %1</source>
        <translation>Lydfrekvens: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="37"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="14"/>
        <source>Thumbnail Generator</source>
        <translation>Forhåndsvisningsgenerator</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="22"/>
        <source>&amp;File:</source>
        <translation>&amp;Fil:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="56"/>
        <source>&amp;Columns:</source>
        <translation>&amp;Kolonner:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="92"/>
        <source>&amp;Rows:</source>
        <translation>&amp;Rekker:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="136"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Visningsaspekt</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="200"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Maks bredde:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="28"/>
        <source>&amp;OK</source>
        <translation type="unfinished">&amp;OK</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="29"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Lukk</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Forhåndsvisningen vil bli lagd for videoen som du velger her.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Forhåndsvisningene vil bli sortert i en tabell.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Denne innstillingen bestemmer antall kolonner i tabellen.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Denne innstillingen bestemmer antall rader i tabellen.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="51"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Hvis du velger dette alternativet, vil avspillingstiden bli vist nederst i hver forhåndsvisning.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Hvis visningsaspektet i videoen er feil, kan du velge et annet aspekt her.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Vanligvis er de første bildene sorte, så det er en god idé å hoppe over noen sekunder i starten av videoen. Denne innstillingen tillater deg å velge hvor mange sekunder som skal hoppes over.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="55"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Denne innstillingen spesifiserer maksbredden i piksler som det genererte forhåndsvisningsbildet skal ha.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="56"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Noen bilder vil bli utvunnet fra videoen for å kunne lage forhåndsvisningen. Her kan du velge bildeformatet til de utvunnede bildene. .PNG kan gi bedre kvalitet.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="114"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Legg til spille&amp;tiden til forhåndsvisningene</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="166"/>
        <source>&amp;Seconds to skip at the beginning:</source>
        <translation>&amp;Antall sekunder å hoppe over i starten:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="250"/>
        <source>&amp;Extract frames as</source>
        <translation>&amp;Ekstrakter bilder som</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Velg DVD-enheten eller en mappe med en DVD-avbilding.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="39"/>
        <source>&amp;DVD device:</source>
        <translation>&amp;DVD-enhet:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="291"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Husk mappen som ble brukt til å &amp;lagre forhåndsvisningen</translation>
    </message>
</context>
<context>
    <name>VolumeControlPanel</name>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="132"/>
        <source>Playlist</source>
        <translation>Spilleliste</translation>
    </message>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="133"/>
        <source>Fullscreen on/off</source>
        <translation>Fullskjerm av/på</translation>
    </message>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="134"/>
        <source>Video equalizer</source>
        <translation>Videotonekontroll</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="196"/>
        <source>Volume</source>
        <translation>Volum</translation>
    </message>
</context>
</TS>
