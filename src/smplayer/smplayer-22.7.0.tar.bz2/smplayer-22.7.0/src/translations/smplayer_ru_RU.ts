<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.0" language="ru">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="64"/>
        <source>Version: %1</source>
        <translation>Версия: %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="65"/>
        <source>Development version</source>
        <translation>Тестовая версия</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="72"/>
        <source>Links:</source>
        <translation>Ссылки:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="73"/>
        <source>Official website:</source>
        <translation>Официальный сайт:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="85"/>
        <source>SMPlayer is a graphical interface for %1.</source>
        <translation>SMPlayer — это графическая оболочка для %1.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="170"/>
        <source>Click here to know the translators from the transifex teams</source>
        <translation>Нажмите сюда, чтобы ознакомиться со списком переводчиков из команды Transifex</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="166"/>
        <source>Many people contributed with translations.</source>
        <translation>Многие люди приняли участие в локализации.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>You can also help to translate SMPlayer into your own language.</source>
        <translation>Вы тоже можете помочь перевести SMPlayer на свой родной язык</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>Visit %1 and join a translation team.</source>
        <translation>Посетите %1 и присоединяйтесь к команде переводчиков.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="60"/>
        <source>Using %1</source>
        <translation>Используется %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="44"/>
        <source>&amp;OK</source>
        <translation>&amp;ОК</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="81"/>
        <source>SMPlayer is a graphical interface for %1 and %2.</source>
        <translation>SMPlayer — это графическая оболочка для %1 и %2.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="14"/>
        <source>About SMPlayer</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../about.ui" line="33"/>
        <source>Page</source>
        <translation>Страница</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>&amp;Info</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <location filename="../about.ui" line="58"/>
        <location filename="../about.ui" line="114"/>
        <location filename="../about.ui" line="170"/>
        <location filename="../about.ui" line="226"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../about.ui" line="94"/>
        <source>&amp;Contributions</source>
        <translation>&amp;Участники</translation>
    </message>
    <message>
        <location filename="../about.ui" line="150"/>
        <source>&amp;Translators</source>
        <translation>Пере&amp;водчики</translation>
    </message>
    <message>
        <location filename="../about.ui" line="206"/>
        <source>&amp;License</source>
        <translation>&amp;Лицензия</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="67"/>
        <source>Portable Edition</source>
        <translation>Переносной вариант</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="70"/>
        <source>Using Qt %1 (compiled with Qt %2)</source>
        <translation>Используется Qt %1 (скомпилировано с Qt %2)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="126"/>
        <source>SMPlayer logo by %1</source>
        <translation>Логотип SMPlayer от %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="107"/>
        <source>Read the entire license</source>
        <translation>Прочесть полную лицензию</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="115"/>
        <source>Read a translation</source>
        <translation>Прочесть перевод</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="127"/>
        <source>Packages for Windows created by %1</source>
        <translation>Пакеты для Windows созданы %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="128"/>
        <source>Many other people contributed with patches. See the Changelog for details.</source>
        <translation>Многие люди внесли вклад своими патчами. Смотрите подробности в списке изменений.</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="240"/>
        <source>Shortcut</source>
        <translation>Сочетание клавиш</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="242"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="245"/>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="503"/>
        <location filename="../actionseditor.cpp" line="553"/>
        <source>Key files</source>
        <translation>Файлы клавиш</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="501"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="213"/>
        <source>Type to search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="512"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="513"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 уже существует.
Хотите перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="552"/>
        <source>Choose a file</source>
        <translation>Выбор файла</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="525"/>
        <location filename="../actionseditor.cpp" line="559"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="526"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранён</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="560"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файл не может быть загружен</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="249"/>
        <source>&amp;Change shortcut...</source>
        <translation>Изменить &amp;сочетание клавиш…</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="189"/>
        <source>Audio Equalizer</source>
        <translation>Аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="192"/>
        <location filename="../audioequalizer.cpp" line="193"/>
        <location filename="../audioequalizer.cpp" line="194"/>
        <location filename="../audioequalizer.cpp" line="195"/>
        <location filename="../audioequalizer.cpp" line="196"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="197"/>
        <location filename="../audioequalizer.cpp" line="198"/>
        <location filename="../audioequalizer.cpp" line="199"/>
        <location filename="../audioequalizer.cpp" line="200"/>
        <location filename="../audioequalizer.cpp" line="201"/>
        <source>%1 kHz</source>
        <translation>%1 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="203"/>
        <source>&amp;Preset</source>
        <translation>&amp;Предустановка</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="204"/>
        <source>&amp;Apply</source>
        <translation>&amp;Применить</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="205"/>
        <source>&amp;Reset</source>
        <translation>&amp;Сброс</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="206"/>
        <source>&amp;Set as default values</source>
        <translation>Сохранить как &amp;значения по умолчанию</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="207"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="212"/>
        <source>Flat</source>
        <translation>Плоский</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="213"/>
        <source>Classical</source>
        <translation>Классика</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="214"/>
        <source>Club</source>
        <translation>Клуб</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="215"/>
        <source>Dance</source>
        <translation>Танец</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="216"/>
        <source>Full bass</source>
        <translation>Низкие частоты</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="217"/>
        <source>Full bass and treble</source>
        <translation>Низкие и высокие частоты</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="218"/>
        <source>Full treble</source>
        <translation>Высокие частоты</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="219"/>
        <source>Headphones</source>
        <translation>Наушники</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="220"/>
        <source>Large hall</source>
        <translation>Большой зал</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="221"/>
        <source>Live</source>
        <translation>Живой</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="222"/>
        <source>Party</source>
        <translation>Вечеринка</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="223"/>
        <source>Pop</source>
        <translation>Поп</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="224"/>
        <source>Reggae</source>
        <translation>Регги</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="225"/>
        <source>Rock</source>
        <translation>Рок</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="226"/>
        <source>Ska</source>
        <translation>Ска</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="227"/>
        <source>Soft</source>
        <translation>Мягкий</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="228"/>
        <source>Soft rock</source>
        <translation>Мягкий рок</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="229"/>
        <source>Techno</source>
        <translation>Техно</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="230"/>
        <source>Custom</source>
        <translation>Ручной</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="235"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать текущие значения по умолчанию для новых файлов.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="237"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="252"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="253"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие значения были сохранены в качестве стандартных.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="2001"/>
        <source>&amp;Open</source>
        <translation>&amp;Открыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2002"/>
        <source>&amp;Play</source>
        <translation>&amp;Проигрывание</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2003"/>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2004"/>
        <source>&amp;Audio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2005"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2006"/>
        <source>&amp;Browse</source>
        <translation>О&amp;бзор</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2008"/>
        <source>Op&amp;tions</source>
        <translation>С&amp;ервис</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2009"/>
        <source>&amp;Help</source>
        <translation>Сп&amp;равка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;File...</source>
        <translation>&amp;Файл…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1717"/>
        <source>D&amp;irectory...</source>
        <translation>Ката&amp;лог…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1718"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Плейлист…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1721"/>
        <source>&amp;DVD from drive</source>
        <translation>DVD с диск&amp;а</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1722"/>
        <source>D&amp;VD from folder...</source>
        <translation>DVD из &amp;каталога…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>&amp;URL...</source>
        <translation>А&amp;дрес…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2025"/>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2023"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Недавние файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1751"/>
        <source>P&amp;lay</source>
        <translation>&amp;Воспроизвести</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1754"/>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1755"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1756"/>
        <source>&amp;Frame step</source>
        <translation>С&amp;ледующий кадр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1775"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Обычная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1777"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Удвоенная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1778"/>
        <source>Speed &amp;-10%</source>
        <translation>Скорос&amp;ть –10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1779"/>
        <source>Speed &amp;+10%</source>
        <translation>Скорост&amp;ь +10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1873"/>
        <source>&amp;Off</source>
        <comment>closed captions menu</comment>
        <translation>О&amp;тключён</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2043"/>
        <source>Sp&amp;eed</source>
        <translation>С&amp;корость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1770"/>
        <source>&amp;Repeat</source>
        <translation>Пов&amp;торить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1786"/>
        <source>&amp;Fullscreen</source>
        <translation>Полный экр&amp;ан</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1787"/>
        <source>&amp;Compact mode</source>
        <translation>&amp;Компактный режим</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2053"/>
        <source>Si&amp;ze</source>
        <translation>&amp;Размер видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2063"/>
        <source>&amp;Aspect ratio</source>
        <translation>&amp;Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2102"/>
        <location filename="../basegui.cpp" line="3616"/>
        <location filename="../basegui.cpp" line="3630"/>
        <source>&amp;None</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2103"/>
        <source>&amp;Lowpass5</source>
        <translation>Lowpass&amp;5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2106"/>
        <source>Linear &amp;Blend</source>
        <translation>Линейное &amp;смешивание</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2066"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Устранение чересстрочности</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1815"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постобработка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1816"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автоопределять фазу</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1817"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Удаление блочности</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1818"/>
        <source>De&amp;ring</source>
        <translation>Удалять к&amp;раевые артефакты</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1820"/>
        <source>Add n&amp;oise</source>
        <translation>Добавить &amp;шумы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2069"/>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;ильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1788"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1789"/>
        <source>&amp;Screenshot</source>
        <translation>С&amp;нимок экрана</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2075"/>
        <source>S&amp;tay on top</source>
        <translation>Повер&amp;х всех окон</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1838"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Расширенное стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1839"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке (подавление голоса)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2138"/>
        <source>&amp;Filters</source>
        <translation>&amp;Фильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2148"/>
        <location filename="../basegui.cpp" line="2154"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2149"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 окружение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2150"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 окружение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2141"/>
        <source>&amp;Channels</source>
        <translation>&amp;Каналы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2155"/>
        <source>&amp;Left channel</source>
        <translation>&amp;Левый канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2156"/>
        <source>&amp;Right channel</source>
        <translation>&amp;Правый канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2144"/>
        <source>&amp;Stereo mode</source>
        <translation>&amp;Режим стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1828"/>
        <source>&amp;Mute</source>
        <translation>&amp;Приглушить звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1829"/>
        <source>Volume &amp;-</source>
        <translation>Г&amp;ромкость –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1830"/>
        <source>Volume &amp;+</source>
        <translation>Гр&amp;омкость +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1831"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Задержка –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1832"/>
        <source>D&amp;elay +</source>
        <translation>З&amp;адержка +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2164"/>
        <source>&amp;Select</source>
        <translation>Вы&amp;брать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1846"/>
        <source>&amp;Load...</source>
        <translation>Загрузить из &amp;файла…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1848"/>
        <source>Delay &amp;-</source>
        <translation>&amp;Задержка –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1849"/>
        <source>Delay &amp;+</source>
        <translation>З&amp;адержка +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1851"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1852"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2182"/>
        <source>&amp;Title</source>
        <translation>&amp;Заголовок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2185"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Глава</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2188"/>
        <source>&amp;Angle</source>
        <translation>&amp;Ракурс</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1888"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Плейлист</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2100"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Отключено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2220"/>
        <source>&amp;OSD</source>
        <translation>&amp;Экранное меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1890"/>
        <source>P&amp;references</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1924"/>
        <source>About &amp;SMPlayer</source>
        <translation>&amp;О программе</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3653"/>
        <location filename="../basegui.cpp" line="3669"/>
        <location filename="../basegui.cpp" line="3685"/>
        <location filename="../basegui.cpp" line="3700"/>
        <location filename="../basegui.cpp" line="3734"/>
        <location filename="../basegui.cpp" line="3754"/>
        <location filename="../basegui.cpp" line="3830"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4294"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4295"/>
        <location filename="../basegui.cpp" line="4545"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4296"/>
        <source>Playlists</source>
        <translation>Плейлисты</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4297"/>
        <location filename="../basegui.cpp" line="4520"/>
        <location filename="../basegui.cpp" line="4546"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4292"/>
        <location filename="../basegui.cpp" line="4517"/>
        <location filename="../basegui.cpp" line="4543"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1892"/>
        <source>&amp;YouTube%1 browser</source>
        <translation>Браузер &amp;YouTube%1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1920"/>
        <source>&amp;Donate / Share with your friends</source>
        <translation>&amp;Пожертвовать / Поделиться с друзьями</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4356"/>
        <source>SMPlayer - Information</source>
        <translation>SMPlayer – Информация</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4357"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Приводы CD/DVD ещё не настроены.
Вы сможете сделать это в окне настроек этих устройств.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4470"/>
        <source>Select the Blu-ray folder</source>
        <translation>Выберите каталог Blu-ray</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4483"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4519"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4633"/>
        <source>&amp;Donate with PayPal</source>
        <translation>&amp;Пожертвовать в PayPal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4634"/>
        <source>&amp;Not now</source>
        <translation>&amp;Позже</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4637"/>
        <source>&amp;No</source>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5165"/>
        <location filename="../basegui.cpp" line="5194"/>
        <source>Error detected</source>
        <translation>Обнаружена ошибка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5195"/>
        <source>Unfortunately this video can&apos;t be played.</source>
        <translation>К сожалению, это видео нельзя воспроизвести.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5432"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5433"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1759"/>
        <source>Play / Pause</source>
        <translation>Воспроизвести / Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1762"/>
        <source>Pause / Frame step</source>
        <translation>Пауза / Следующий кадр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1835"/>
        <location filename="../basegui.cpp" line="1847"/>
        <source>U&amp;nload</source>
        <translation>В&amp;ыгрузить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1719"/>
        <source>V&amp;CD</source>
        <translation>Ви&amp;део-CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>C&amp;lose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1803"/>
        <source>Zoom &amp;-</source>
        <translation>&amp;Масштаб –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1804"/>
        <source>Zoom &amp;+</source>
        <translation>М&amp;асштаб +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1805"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1809"/>
        <source>Move &amp;left</source>
        <translation>Переместить в&amp;лево</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1810"/>
        <source>Move &amp;right</source>
        <translation>Переместить в&amp;право</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1811"/>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1812"/>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1856"/>
        <source>&amp;Previous line in subtitles</source>
        <translation>&amp;Предыдущая строка субтитра</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1858"/>
        <source>N&amp;ext line in subtitles</source>
        <translation>С&amp;ледующая строка субтитра</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1897"/>
        <location filename="../basegui.cpp" line="2242"/>
        <source>%1 log</source>
        <translation>Журнал %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1900"/>
        <location filename="../basegui.cpp" line="2245"/>
        <source>SMPlayer log</source>
        <translation>Журнал SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2258"/>
        <location filename="../basegui.cpp" line="2259"/>
        <location filename="../basegui.cpp" line="2260"/>
        <source>-%1</source>
        <translation>–%1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2262"/>
        <location filename="../basegui.cpp" line="2263"/>
        <location filename="../basegui.cpp" line="2264"/>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1953"/>
        <source>Dec volume (2)</source>
        <translation>Уменьшить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>&amp;Blu-ray from drive</source>
        <translation>Blu-ray с &amp;устройства</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1725"/>
        <source>Blu-&amp;ray from folder...</source>
        <translation>Blu-ray из ка&amp;талога</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1757"/>
        <source>Fra&amp;me back step</source>
        <translation>&amp;Предыдущий кадр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1776"/>
        <source>&amp;Half speed</source>
        <translation>&amp;Половинная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1790"/>
        <source>Screenshot with subtitles</source>
        <translation>Снимок экрана с субтитрами</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1791"/>
        <source>Screenshot without subtitles</source>
        <translation>Снимок экрана без субтитров</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1794"/>
        <source>Start/stop capturing stream</source>
        <translation>Старт/стоп захвата потока</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1797"/>
        <source>Thumb&amp;nail Generator...</source>
        <translation>Генератор миниа&amp;тюр…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1801"/>
        <source>Stereo &amp;3D filter</source>
        <translation>Стерео &amp;3D-фильтр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1819"/>
        <source>Debanding (&amp;gradfun)</source>
        <translation>Убрать &amp;ступенчатость (gradfun)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1842"/>
        <source>&amp;Headphone optimization</source>
        <translation>&amp;Оптимизация для наушников</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1860"/>
        <source>Seek to next subtitle</source>
        <translation>Перемотать на следующий субтитр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1861"/>
        <source>Seek to previous subtitle</source>
        <translation>Перемотать на предыдущий субтитр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1863"/>
        <source>Use custo&amp;m style</source>
        <translation>Использовать &amp;особый стиль</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1869"/>
        <source>Find subtitles at &amp;OpenSubtitles.org...</source>
        <translation>&amp;Поиск субтитров в OpenSubtitles.org</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1879"/>
        <source>&amp;Default</source>
        <comment>subfps menu</comment>
        <translation>По &amp;умолчанию</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1889"/>
        <source>&amp;Information and properties...</source>
        <translation>&amp;Информация и свойства…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1902"/>
        <source>T&amp;ablet mode</source>
        <translation>П&amp;ланшетный режим</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1905"/>
        <source>First Steps &amp;Guide</source>
        <translation>&amp;Начальное руководство</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1912"/>
        <source>Update &amp;YouTube support</source>
        <translation>&amp;Обновить поддержку YouTube</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1914"/>
        <source>Install / Update &amp;YouTube support</source>
        <translation>&amp;Установить/обновить поддержку YouTube</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1918"/>
        <source>&amp;Open configuration folder</source>
        <translation>Открыть каталог &amp;настроек</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1922"/>
        <location filename="../basegui.cpp" line="4636"/>
        <source>&amp;Donate</source>
        <translation>&amp;Сделать пожертвование</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1935"/>
        <source>Size &amp;+</source>
        <translation>Размер &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1936"/>
        <source>Size &amp;-</source>
        <translation>Размер &amp;–</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1939"/>
        <source>Show times with &amp;milliseconds</source>
        <translation>Показать время с &amp;миллисекундами</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1954"/>
        <source>Inc volume (2)</source>
        <translation>Увеличить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1957"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из полного экрана</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1959"/>
        <source>OSD - Next level</source>
        <translation>Экранное меню – след. уровень</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1960"/>
        <source>Dec contrast</source>
        <translation>Уменьшить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1961"/>
        <source>Inc contrast</source>
        <translation>Повысить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1962"/>
        <source>Dec brightness</source>
        <translation>Уменьшить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1963"/>
        <source>Inc brightness</source>
        <translation>Повысить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1964"/>
        <source>Dec hue</source>
        <translation>Повысить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1965"/>
        <source>Inc hue</source>
        <translation>Уменьшить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1966"/>
        <source>Dec saturation</source>
        <translation>Уменьшить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1968"/>
        <source>Dec gamma</source>
        <translation>Уменьшить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1970"/>
        <source>Previous video</source>
        <translation>Предыдущее видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1972"/>
        <source>Previous audio</source>
        <translation>Предыдущее аудио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1973"/>
        <source>Next audio</source>
        <translation>Следующая звуковая дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1974"/>
        <source>Previous subtitle</source>
        <translation>Предыдущие субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1975"/>
        <source>Next subtitle</source>
        <translation>Следующий субтитр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1976"/>
        <source>Next chapter</source>
        <translation>Следующий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1977"/>
        <source>Previous chapter</source>
        <translation>Предыдущий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1985"/>
        <source>Show filename on OSD</source>
        <translation>Отображать имя файла на экранном меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1986"/>
        <source>Show &amp;info on OSD</source>
        <translation>Отобразить &amp;сведения на экранном меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1987"/>
        <source>Show playback time on OSD</source>
        <translation>Отображать время проигрывания на экранном меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2007"/>
        <source>Vie&amp;w</source>
        <translation>Ви&amp;д</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2083"/>
        <source>De&amp;noise</source>
        <translation>Понижение &amp;шумов</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2086"/>
        <source>Blur/S&amp;harp</source>
        <translation>Размытие/ре&amp;зкость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2109"/>
        <source>&amp;Off</source>
        <comment>denoise menu</comment>
        <translation>О&amp;тключено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2110"/>
        <source>&amp;Normal</source>
        <comment>denoise menu</comment>
        <translation>&amp;Нормальное</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2111"/>
        <source>&amp;Soft</source>
        <comment>denoise menu</comment>
        <translation>&amp;Мягкое</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2113"/>
        <source>&amp;None</source>
        <comment>unsharp menu</comment>
        <translation>&amp;Нет</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2114"/>
        <source>&amp;Blur</source>
        <comment>unsharp menu</comment>
        <translation>Размы&amp;тие</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2115"/>
        <source>&amp;Sharpen</source>
        <comment>unsharp menu</comment>
        <translation>&amp;Резкость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2122"/>
        <source>Rotate by 1&amp;80 degrees</source>
        <translation>По&amp;вернуть на 180°</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2136"/>
        <source>Select audio track</source>
        <translation>Выбрать аудиодорожку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2151"/>
        <source>&amp;6.1 Surround</source>
        <translation>&amp;6.1 окружение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2152"/>
        <source>&amp;7.1 Surround</source>
        <translation>&amp;7.1 окружение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2157"/>
        <source>&amp;Mono</source>
        <translation>&amp;Моно</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2158"/>
        <source>Re&amp;verse</source>
        <translation>Обратный</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2162"/>
        <source>Prim&amp;ary track</source>
        <translation>&amp;Главная дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2167"/>
        <source>Select subtitle track</source>
        <translation>Выбрать субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2170"/>
        <source>Secondary trac&amp;k</source>
        <translation>&amp;Дополнительная дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2172"/>
        <source>Select secondary subtitle track</source>
        <translation>Выбрать дополнительные субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2178"/>
        <source>F&amp;rames per second</source>
        <translation>Ч&amp;астота кадров</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2192"/>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Закладки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2202"/>
        <source>&amp;Add new bookmark</source>
        <translation>&amp;Добавить новую закладку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2203"/>
        <source>&amp;Edit bookmarks</source>
        <translation>&amp;Править закладки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2204"/>
        <source>Previous bookmark</source>
        <translation>Предыдущая закладка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2205"/>
        <source>Next bookmark</source>
        <translation>Следующая закладка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2234"/>
        <source>Quick access menu</source>
        <translation>Меню быстрого запуска</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3047"/>
        <source>Logs</source>
        <translation>Журналы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3352"/>
        <source>You need to restart SMPlayer in order to apply the new preferences.</source>
        <translation>Вы должны перезапустить SMPlayer для применения новых настроек.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4630"/>
        <source>Support SMPlayer</source>
        <translation>Поддержать SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4641"/>
        <source>SMPlayer needs you</source>
        <translation>SMPlayer нуждается в вас</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4642"/>
        <source>SMPlayer is free software. However the development requires a lot of time and a lot of work.</source>
        <translation>SMPlayer является свободным программным обеспечением. Однако его развитие требует много времени и работы.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4643"/>
        <source>In order to keep developing SMPlayer with new features we need your help.</source>
        <translation>Для того, чтобы продолжать разработку SMPlayer и добавлять новые возможности, нам нужна ваша помощь.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4644"/>
        <source>Please consider to support the SMPlayer project by sending a donation.</source>
        <translation>Пожалуйста, рассмотрите возможность пожертвования проекту SMPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4645"/>
        <source>Even the smallest amount will help a lot.</source>
        <translation>Даже самая маленькая сумма очень поможет.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5166"/>
        <source>The youtube-dl process failed because of missing libraries.</source>
        <translation>Процесс youtube-dl завершился неудачей из-за отсутствия библиотек.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5167"/>
        <source>You&apos;ll probably need to install %1.</source>
        <translation>Вероятно, вам нужно установить %1.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5169"/>
        <source>the Microsoft Visual C++ 2010 Redistributable Package</source>
        <translation>распространяемый пакет Microsoft Visual C++ 2010</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6159"/>
        <location filename="../basegui.cpp" line="6212"/>
        <source>More info in the log.</source>
        <translation>Подробнее в журнале</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6165"/>
        <location filename="../basegui.cpp" line="6218"/>
        <source>%1 Error</source>
        <translation>Ошибка %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6159"/>
        <location filename="../basegui.cpp" line="6166"/>
        <source>%1 has finished unexpectedly.</source>
        <translation>Неожиданное завершение %1.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4649"/>
        <source>It&apos;s also possible to donate with cryptocurrencies.</source>
        <translation>Также можно пожертвовать криптовалюту.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6191"/>
        <source>The component youtube-dl failed to run.</source>
        <translation>Не удалось запустить youtube-dl.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6192"/>
        <source>Installing the Microsoft Visual C++ 2010 Redistributable Package (x86) may fix the problem.</source>
        <translation>Установка Распространяемого пакета Microsoft Visual C++ 2010 (x86) может исправить проблему.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6194"/>
        <source>Click here to get it</source>
        <translation>Нажмите сюда для загрузки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6212"/>
        <location filename="../basegui.cpp" line="6220"/>
        <source>%1 failed to start.</source>
        <translation>Ошибка запуска %1.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6221"/>
        <source>Please check the %1 path in preferences.</source>
        <translation>Проверьте путь к %1 в настройках.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6223"/>
        <source>%1 has crashed.</source>
        <translation>Сбой %1.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6318"/>
        <source>The YouTube Browser is not installed.</source>
        <translation>Браузер YouTube не установлен.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6319"/>
        <location filename="../basegui.cpp" line="6331"/>
        <source>Visit %1 to get it.</source>
        <translation>Посетите %1 для загрузки.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6329"/>
        <source>The YouTube Browser failed to run.</source>
        <translation>Не удалось запустить браузер YouTube.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6330"/>
        <source>Be sure it&apos;s installed correctly.</source>
        <translation>Убедитесь, что он установлен правильно.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6497"/>
        <source>The system has switched to tablet mode. Should SMPlayer change to tablet mode as well?</source>
        <translation>Система переключена в планшетный режим. Должен ли SMPlayer также изменить решим на планшетный?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6499"/>
        <source>The system has exited tablet mode. Should SMPlayer turn off the tablet mode as well?</source>
        <translation>Система вышла из планшетного режима. Должен ли SMPlayer также отключить планшетный режим?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6503"/>
        <source>Remember my decision and don&apos;t ask again</source>
        <translation>Запомнить моё решение и не спрашивать снова</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2224"/>
        <source>S&amp;hare SMPlayer with your friends</source>
        <translation>По&amp;делиться SMPlayer с друзьями</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3351"/>
        <location filename="../basegui.cpp" line="4087"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3842"/>
        <source>Confirm deletion - SMPlayer</source>
        <translation>Подтвердить удаление — SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3843"/>
        <source>Delete the list of recent files?</source>
        <translation>Очистить список недавних файлов?</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4088"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие значения были сохранены в качестве стандартных.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1967"/>
        <source>Inc saturation</source>
        <translation>Повысить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1969"/>
        <source>Inc gamma</source>
        <translation>Повысить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1834"/>
        <source>&amp;Load external file...</source>
        <translation>За&amp;грузить из файла…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2107"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Адаптивное (kerndeint)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2104"/>
        <source>&amp;Yadif (normal)</source>
        <translation>Yadif (&amp;обычный)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2105"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Yadif (2× &amp;частота кадров)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1943"/>
        <source>&amp;Next</source>
        <translation>Сл&amp;едующий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1944"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1840"/>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Нормализация громкости</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Аудио-CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1978"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Двойной размер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1853"/>
        <source>S&amp;ize -</source>
        <translation>Р&amp;азмер –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1854"/>
        <source>Si&amp;ze +</source>
        <translation>Ра&amp;змер +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1821"/>
        <source>Add &amp;black borders</source>
        <translation>Добавить &amp;чёрные полосы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1822"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Масштабировать про&amp;граммно</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1906"/>
        <source>&amp;FAQ</source>
        <translation>&amp;ЧаВо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1907"/>
        <source>&amp;Command line options</source>
        <translation>Параметры командной &amp;строки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4565"/>
        <source>SMPlayer command line options</source>
        <translation>Параметры командной строки SMPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1864"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Только форсированные</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1979"/>
        <source>Reset video equalizer</source>
        <translation>Сброс видеоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5196"/>
        <source>The server returned &apos;%1&apos;</source>
        <translation>Сервер вернул &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6167"/>
        <source>Exit code: %1</source>
        <translation>Код ошибки: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="6224"/>
        <source>See the log for more info.</source>
        <translation>Смотрите журнал для подробностей.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2072"/>
        <source>&amp;Rotate</source>
        <translation>По&amp;ворот</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2117"/>
        <source>&amp;Off</source>
        <translation>О&amp;тключён</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2118"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>На 90° по часовой стрелке с &amp;отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2119"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>На 90° &amp;по часовой стрелке</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2120"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>На 90° п&amp;ротив часовой стрелки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2121"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>На 90° против часовой &amp;стрелки с отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1772"/>
        <source>&amp;Jump to...</source>
        <translation>П&amp;ерейти к…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1981"/>
        <source>Show context menu</source>
        <translation>Показать контекстное меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4293"/>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1825"/>
        <source>E&amp;qualizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1980"/>
        <source>Reset audio equalizer</source>
        <translation>Сброс аудиоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1870"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Отправить &amp;субтитры в OpenSubtitles.org</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2089"/>
        <source>&amp;Auto</source>
        <translation>&amp;Автоматически</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1780"/>
        <source>Speed -&amp;4%</source>
        <translation>Скор&amp;ость –4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1781"/>
        <source>&amp;Speed +4%</source>
        <translation>Скоро&amp;сть +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1782"/>
        <source>Speed -&amp;1%</source>
        <translation>&amp;Скорость –1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1783"/>
        <source>S&amp;peed +1%</source>
        <translation>С&amp;корость +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2079"/>
        <source>Scree&amp;n</source>
        <translation>&amp;Экран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2130"/>
        <location filename="../basegui.cpp" line="2147"/>
        <source>&amp;Default</source>
        <translation>По &amp;умолчанию</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1800"/>
        <source>Mirr&amp;or image</source>
        <translation>&amp;Зеркальное изображение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1971"/>
        <source>Next video</source>
        <translation>Следующий видеофайл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2050"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2134"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5048"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Предупреждение: Используется старая версия MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5049"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. SMPlayer can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Установленная в вашей системе версия MPlayer (%1) устарела. SMPlayer не может работать с ней достаточно хорошо: некоторые параметры не будут работать, выбор субтитров может вызывать ошибку…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5054"/>
        <source>Please, update your MPlayer.</source>
        <translation>Пожалуйста, обновите ваш MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5056"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Это предупреждение больше не будет показано)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1982"/>
        <source>Next aspect ratio</source>
        <translation>Следующее соотношение сторон</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1806"/>
        <source>&amp;Auto zoom</source>
        <translation>&amp;Автомасштаб</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1807"/>
        <source>Zoom for &amp;16:9</source>
        <translation>Масштаб для &amp;16:9</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1808"/>
        <source>Zoom for &amp;2.35:1</source>
        <translation>Масштаб для &amp;2.35:1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2124"/>
        <source>&amp;Always</source>
        <translation>&amp;Всегда</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2125"/>
        <source>&amp;Never</source>
        <translation>&amp;Никогда</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2126"/>
        <source>While &amp;playing</source>
        <translation>П&amp;ри воспроизведении</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>DVD &amp;menu</source>
        <translation>DVD-&amp;меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2215"/>
        <source>DVD &amp;previous menu</source>
        <translation>&amp;Предыдущее DVD-меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2209"/>
        <source>DVD menu, move up</source>
        <translation>DVD-меню, вверх</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2210"/>
        <source>DVD menu, move down</source>
        <translation>DVD-меню, вниз</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2211"/>
        <source>DVD menu, move left</source>
        <translation>DVD-меню, влево</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2212"/>
        <source>DVD menu, move right</source>
        <translation>DVD-меню, вправо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2214"/>
        <source>DVD menu, select option</source>
        <translation>DVD-меню, выбрать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2216"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD-меню, щелчок мыши</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1833"/>
        <source>Set dela&amp;y...</source>
        <translation>Указать &amp;задержку…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1850"/>
        <source>Se&amp;t delay...</source>
        <translation>Указа&amp;ть задержку…</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4712"/>
        <location filename="../basegui.cpp" line="4716"/>
        <source>SMPlayer - Audio delay</source>
        <translation>SMPlayer – Задержка звука</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4713"/>
        <location filename="../basegui.cpp" line="4717"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Задержка звука (в миллисекундах):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4728"/>
        <location filename="../basegui.cpp" line="4732"/>
        <source>SMPlayer - Subtitle delay</source>
        <translation>SMPlayer – Задержка субтитров</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4729"/>
        <location filename="../basegui.cpp" line="4733"/>
        <source>Subtitle delay (in milliseconds):</source>
        <translation>Задержка субтитров (в миллисекундах):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2127"/>
        <source>Toggle stay on top</source>
        <translation>Сменить режим &quot;Поверх всех окон&quot;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="5658"/>
        <location filename="../basegui.cpp" line="6006"/>
        <source>Jump to %1</source>
        <translation>Перейти к %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1792"/>
        <source>Start/stop takin&amp;g screenshots</source>
        <translation>Старт/стоп &amp;создания снимков</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1866"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Отобра&amp;жать субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1983"/>
        <source>Next wheel function</source>
        <translation>Следующая функция колеса</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2197"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>П&amp;рограмма</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2035"/>
        <source>&amp;TV</source>
        <translation>&amp;ТВ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2038"/>
        <source>Radi&amp;o</source>
        <translation>&amp;Радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1994"/>
        <source>Subtitles onl&amp;y</source>
        <translation>Толь&amp;ко субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1995"/>
        <source>Volume + &amp;Seek</source>
        <translation>Громкость + &amp;Перемотка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1996"/>
        <source>Volume + Seek + &amp;Timer</source>
        <translation>Громкость + Перемотка + &amp;Время</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1997"/>
        <source>Volume + Seek + Timer + T&amp;otal time</source>
        <translation>Громкость + Перемотка + Время + &amp;Общее время</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1657"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Видеофильтры отключены при использовании VDPAU</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1799"/>
        <source>Fli&amp;p image</source>
        <translation>Пере&amp;вернуть картинку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2060"/>
        <source>Zoo&amp;m</source>
        <translation>&amp;Масштаб</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1767"/>
        <source>Set &amp;A marker</source>
        <translation>Установить маркер &amp;A</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1768"/>
        <source>Set &amp;B marker</source>
        <translation>Установить маркер &amp;B</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1769"/>
        <source>&amp;Clear A-B markers</source>
        <translation>Очи&amp;стить маркеры A-B</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2046"/>
        <source>&amp;A-B section</source>
        <translation>&amp;Отрезок A-B</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1989"/>
        <source>Toggle deinterlacing</source>
        <translation>Переключить режим устранения чересстрочности</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2175"/>
        <source>&amp;Closed captions</source>
        <translation>&amp;Скрытые субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2027"/>
        <source>&amp;Disc</source>
        <translation>&amp;Диск</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2031"/>
        <source>F&amp;avorites</source>
        <translation>&amp;Избранное</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1908"/>
        <source>Check for &amp;updates</source>
        <translation>Проверить &amp;обновления</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="354"/>
        <source>SMPlayer is still running here</source>
        <translation>SMPlayer всё ещё запущен</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="377"/>
        <source>S&amp;how icon in system tray</source>
        <translation>&amp;Значок в трее</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="386"/>
        <source>&amp;Cast to</source>
        <translation>&amp;Трансляция на</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="389"/>
        <source>&amp;Chromecast</source>
        <translation>&amp;Chromecast</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="391"/>
        <source>&amp;Smartphone/tablet</source>
        <translation>&amp;Смартфон/планшет</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="396"/>
        <source>Send &amp;video to screen</source>
        <translation>Отправить &amp;видео на экран</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="398"/>
        <source>Information about connected &amp;screens</source>
        <translation>Сведения о подключённых &amp;экранах</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="401"/>
        <source>Video is sent to an external screen</source>
        <translation>Видео отправлено на внешний экран</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="405"/>
        <source>Send &amp;audio to</source>
        <translation>Вывод &amp;звука</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="443"/>
        <source>&amp;Hide</source>
        <translation>&amp;Убрать</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="445"/>
        <source>&amp;Restore</source>
        <translation>&amp;Восстановить</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="922"/>
        <source>Information about connected screens</source>
        <translation>Сведения о подключённых экранах</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="925"/>
        <source>Connected screens</source>
        <translation>Подключённые экраны</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="928"/>
        <location filename="../baseguiplus.cpp" line="970"/>
        <source>Number of screens: %1</source>
        <translation>Количество экранов: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="933"/>
        <location filename="../baseguiplus.cpp" line="971"/>
        <source>Primary screen: %1</source>
        <translation>Первичный экран: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="941"/>
        <location filename="../baseguiplus.cpp" line="975"/>
        <source>Information for screen %1</source>
        <translation>Информация для экрана %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="943"/>
        <location filename="../baseguiplus.cpp" line="977"/>
        <source>Available geometry: %1 %2 %3 x %4</source>
        <translation>Доступная геометрия: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="945"/>
        <source>Available size: %1 x %2</source>
        <translation>Доступный размер: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="946"/>
        <source>Available virtual geometry: %1 %2 %3 x %4</source>
        <translation>Доступная виртуальная геометрия: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="950"/>
        <source>Available virtual size: %1 x %2</source>
        <translation>Доступный виртуальный размер: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="952"/>
        <source>Depth: %1 bits</source>
        <translation>Глубина: %1 бит</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="953"/>
        <location filename="../baseguiplus.cpp" line="979"/>
        <source>Geometry: %1 %2 %3 x %4</source>
        <translation>Геометрия: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="955"/>
        <source>Logical DPI: %1</source>
        <translation>Логическое DPI: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="957"/>
        <source>Physical DPI: %1</source>
        <translation>Физическое DPI: %1</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="958"/>
        <source>Physical size: %1 x %2 mm</source>
        <translation>Физический размер: %1 x %2 мм</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="960"/>
        <source>Refresh rate: %1 Hz</source>
        <translation>Частота обновления: %1 Гц</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="961"/>
        <source>Size: %1 x %2</source>
        <translation>Размер: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="962"/>
        <source>Virtual geometry: %1 %2 %3 x %4</source>
        <translation>Виртуальная геометрия: %1 %2 %3 x %4</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="964"/>
        <source>Virtual size: %1 x %2</source>
        <translation>Виртуальный размер: %1 x %2</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1017"/>
        <source>Primary screen</source>
        <translation>Первичный экран</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1102"/>
        <source>SMPlayer external screen output</source>
        <translation>Вывод SMPlayer на внешний экран</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="1151"/>
        <source>&amp;Default audio device</source>
        <translation>&amp;Звуковое устройство по умолчанию</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="373"/>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
</context>
<context>
    <name>BookmarkDialog</name>
    <message>
        <location filename="../bookmarkdialog.ui" line="14"/>
        <source>Edit bookmarks</source>
        <translation>Править закладки</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.ui" line="38"/>
        <source>&amp;New bookmark</source>
        <translation>&amp;Новая закладка</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.ui" line="45"/>
        <source>&amp;Delete bookmark</source>
        <translation>&amp;Удалить закладку</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.cpp" line="76"/>
        <source>Time</source>
        <translation>Время</translation>
    </message>
    <message>
        <location filename="../bookmarkdialog.cpp" line="76"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
</context>
<context>
    <name>Chromecast</name>
    <message>
        <location filename="../chromecast.cpp" line="91"/>
        <source>The SMPlayer web server is running</source>
        <translation>Веб-сервер SMPlayer запущен</translation>
    </message>
    <message>
        <location filename="../chromecast.cpp" line="93"/>
        <source>&amp;Stop the SMPlayer web server</source>
        <translation>&amp;Остановить веб-сервер SMPlayer</translation>
    </message>
</context>
<context>
    <name>CodeDownloader</name>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="50"/>
        <source>Downloading...</source>
        <translation>Скачивание…</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="77"/>
        <source>Connecting to %1</source>
        <translation>Соединение с %1</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="146"/>
        <source>The YouTube code has been installed successfully.</source>
        <translation>Код YouTube был успешно установлен.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="147"/>
        <source>Installed version: %1</source>
        <translation>Установленная версия: %1</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="148"/>
        <source>Success</source>
        <translation>Успешно</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="153"/>
        <location filename="../youtube/codedownloader.cpp" line="158"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="153"/>
        <source>It&apos;s not possible to save %1.</source>
        <translation>Не удалось сохранить %1.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="158"/>
        <source>An error happened while downloading the file:&lt;br&gt;%1</source>
        <translation>Возникла ошибка при загрузке файла:&lt;br&gt;%1</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="170"/>
        <source>It wasn&apos;t possible to find the URL for this video.</source>
        <translation>Не удалось найти ссылку для данного видео.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="166"/>
        <source>%1 failed to communicate with the external YouTube application. Either it&apos;s not installed or it doesn&apos;t work correctly.</source>
        <translation>%1 не удалось связаться с внешним приложением YouTube. Приложение либо не установлено, либо не работает должным образом.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="171"/>
        <source>Maybe you need to update the YouTube code.</source>
        <translation>Возможно вам стоит обновить код YouTube.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="176"/>
        <source>In order to play YouTube videos, %1 needs an external application called youtube-dl.</source>
        <translation>%1 требуется стороннее приложение youtube-dl для воспроизведения видео с YouTube.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="177"/>
        <source>This component needs to be updated frequently.</source>
        <translation>Этот компонент требует частых обновлений.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="178"/>
        <source>You can update it just by reinstalling SMPlayer. The installer will download and install the very latest version.</source>
        <translation>Вы можете обновить его с помощью переустановки SMPlayer. Установщик загрузит и установит самую последнюю версию.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="180"/>
        <source>Install / Update YouTube support</source>
        <translation>Установить/обновить поддержку YouTube</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="240"/>
        <source>In order to play YouTube videos, %1 needs the help of an external application.</source>
        <translation>%1 требуется стороннее приложение youtube-dl для воспроизведения видео с YouTube.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="241"/>
        <source>%1 can download and install this application for you.</source>
        <translation>%1 может загрузить и установить это приложение для вас.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="242"/>
        <source>It will be downloaded from the official website and installed as %1.</source>
        <translation>Оно загрузится с официального сайта и установится в %1.</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="243"/>
        <source>Would you like to proceed?</source>
        <translation>Хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../youtube/codedownloader.cpp" line="247"/>
        <location filename="../youtube/codedownloader.cpp" line="250"/>
        <source>Install YouTube support?</source>
        <translation>Установить поддержку YouTube?</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3249"/>
        <source>Brightness: %1</source>
        <translation>Яркость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3265"/>
        <source>Contrast: %1</source>
        <translation>Контраст: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3280"/>
        <source>Gamma: %1</source>
        <translation>Гамма: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Hue: %1</source>
        <translation>Оттенок: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3310"/>
        <source>Saturation: %1</source>
        <translation>Насыщенность: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3453"/>
        <source>Volume: %1</source>
        <translation>Громкость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4432"/>
        <source>Zoom: %1</source>
        <translation>Масштаб: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3585"/>
        <location filename="../core.cpp" line="3596"/>
        <source>Font scale: %1</source>
        <translation>Масштаб шрифта: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4670"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Обновление кэша шрифтов. Это может занять несколько секунд…</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3510"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Задержка субтитров: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3528"/>
        <source>Audio delay: %1 ms</source>
        <translation>A-V задержка: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Speed: %1</source>
        <translation>Скорость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="580"/>
        <source>Unable to locate the URL of the video</source>
        <translation>Не удаётся обнаружить URL-адрес видео</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3684"/>
        <source>Subtitles on</source>
        <translation>Субтитры включены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3686"/>
        <source>Subtitles off</source>
        <translation>Субтитры отключены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4309"/>
        <source>Mouse wheel seeks now</source>
        <translation>Колесо мыши: перемотка</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4312"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Колесо мыши: громкость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4315"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Колесо мыши: масштаб</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4318"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Колесо мыши: скорость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4646"/>
        <source>Screenshot saved as %1</source>
        <translation>Снимок экрана сохранён как %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4681"/>
        <source>Starting...</source>
        <translation>Запуск…</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1419"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Снимок НЕ получен, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1432"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Снимки НЕ получены, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2851"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>Маркер &quot;A&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2876"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>Маркер &quot;B&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2899"/>
        <source>A-B markers cleared</source>
        <translation>Маркеры A-B очищены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="576"/>
        <source>Connecting to %1</source>
        <translation>Соединение с %1</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="711"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="712"/>
        <source>Subtitle</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="704"/>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Главная панель</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="708"/>
        <source>&amp;Language toolbar</source>
        <translation>&amp;Языковая панель</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="698"/>
        <source>&amp;Toolbars</source>
        <translation>&amp;Панели</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="677"/>
        <source>Ready</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="717"/>
        <source>F&amp;ormat info</source>
        <translation>Информация о ф&amp;ормате</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="760"/>
        <source>A:%1</source>
        <translation>A:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="764"/>
        <source>B:%1</source>
        <translation>B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="701"/>
        <source>Status&amp;bar</source>
        <translation>Панель с&amp;татуса</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="264"/>
        <source>Time format</source>
        <translation>Формат времени</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="715"/>
        <source>&amp;Video info</source>
        <translation>Инфор&amp;мация о видео</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="716"/>
        <source>&amp;Frame counter</source>
        <translation>С&amp;чётчик кадров</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="718"/>
        <source>&amp;Bitrate info</source>
        <translation>&amp;Информация о битрейте</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="719"/>
        <source>&amp;Show the current time with milliseconds</source>
        <translation>&amp;Показать текущее время миллисекундами</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="721"/>
        <source>Display &amp;total time</source>
        <translation>Отображать &amp;общее время</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="722"/>
        <source>Display &amp;remaining time</source>
        <translation>Отображать ос&amp;тавшееся время</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="725"/>
        <source>Edit main &amp;toolbar</source>
        <translation>Изменить &amp;главную панель</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="726"/>
        <source>Edit &amp;control bar</source>
        <translation>Изменить панель &amp;управления</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="727"/>
        <source>Edit m&amp;ini control bar</source>
        <translation>Изменить &amp;мини-панель управления</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="728"/>
        <source>Edit &amp;floating control</source>
        <translation>Изменить &amp;плавающую панель</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="774"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation>%1x%2 %3 к/с</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="786"/>
        <source>V: %1 kbps A: %2 kbps</source>
        <translation>В: %1 кбит/с А: %2 кбит/с</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="40"/>
        <source>Oops, something went wrong</source>
        <translation>Ой, что-то пошло не так</translation>
    </message>
    <message>
        <location filename="../errordialog.cpp" line="67"/>
        <source>Hide log</source>
        <translation>Скрыть журнал</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="91"/>
        <location filename="../errordialog.cpp" line="69"/>
        <source>Show log</source>
        <translation>Показать журнал</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="14"/>
        <source>MPlayer Error</source>
        <translation>Ошибка MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="43"/>
        <source>Oops, something wrong happened</source>
        <translation>Ой, что-то пошло не так</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="62"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Icon</source>
        <translation>Значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="97"/>
        <source>Media</source>
        <translation>Медиа</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="116"/>
        <source>Favorite editor</source>
        <translation>Редактор избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="118"/>
        <location filename="../favoriteeditor.cpp" line="181"/>
        <location filename="../favoriteeditor.cpp" line="281"/>
        <source>Favorite list</source>
        <translation>Список избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="119"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Вы можете изменять, удалять, сортировать и добавлять новые элементы. Дважды щёлкните по ячейке для изменения её содержимого.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="354"/>
        <source>Select an icon file</source>
        <translation>Выбрать файл значка</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="356"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>Delete &amp;all</source>
        <translation>Удалить &amp;все</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="112"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New item</source>
        <translation>&amp;Новый элемент</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="85"/>
        <source>New &amp;submenu</source>
        <translation>Новое &amp;подменю</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="374"/>
        <location filename="../favorites.cpp" line="378"/>
        <source>Jump to item</source>
        <translation>Перейти к элементу</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="375"/>
        <location filename="../favorites.cpp" line="379"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Введите номер элемента списка для перехода:</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="89"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Изменить…</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="90"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Перейти…</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="91"/>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="92"/>
        <source>&amp;Previous</source>
        <translation>Пре&amp;дыдущий</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="93"/>
        <source>&amp;Add current media</source>
        <translation>Добавить &amp;текущее медиа</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.cpp" line="55"/>
        <source>Click to select a file or folder</source>
        <translation>Щёлкните для выбора файла или каталога</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="37"/>
        <source>Downloading...</source>
        <translation>Загрузка…</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="64"/>
        <source>Connecting to %1</source>
        <translation>Соединение с %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>SMPlayer - File properties</source>
        <translation>SMPlayer – Свойства файла</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Демультиплексор</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>В&amp;ыберите демультиплексор для воспроизведения этого файла:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Видеокодек</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>Вы&amp;берите видеокодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>А&amp;удио</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>Выб&amp;ерите аудиокодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,mirror</source>
        <translation>Вы можете передать дополнительные фильтры видео.
Разделяйте их запятой. Не используйте пробелы!
Пример: scale=512:-2,mirror</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: extrastereo,karaoke</source>
        <translation>Аудиофильтры. Используются аналогично видеофильтрам.
Пример: extrastereo,karaoke</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Параметры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видеофильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Аудио&amp;фильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="89"/>
        <source>&amp;OK</source>
        <translation>&amp;ОК</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="90"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Отмена</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="91"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="98"/>
        <source>O&amp;ptions for %1</source>
        <translation>Параметры %1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="99"/>
        <source>Additional Options for %1</source>
        <translation>Дополнительные параметры %1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="100"/>
        <source>Here you can pass extra options to %1.</source>
        <translation>Здесь вы можете указать дополнительные параметры %1.</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="101"/>
        <source>Write them separated by spaces.</source>
        <translation>Разделяйте их пробелами.</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="101"/>
        <source>Example:</source>
        <translation>Пример:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Hash</source>
        <translation>Хеш</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Filename</source>
        <translation>Имя файла</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="30"/>
        <source>Hash and filename</source>
        <translation>Хеш и имя файла</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Включить/отключить использование прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="37"/>
        <source>The host name of the proxy.</source>
        <translation>Имя хоста прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>The port of the proxy.</source>
        <translation>Порт прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="39"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Если прокси требует аутентификации, укажите имя пользователя.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="41"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Пароль для прокси. &lt;b&gt;Внимание:&lt;/b&gt; пароль будет сохранён в виде текста в конфигурационном файле.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="43"/>
        <source>Select the proxy type to be used.</source>
        <translation>Выберите тип прокси, который будет использоваться.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="14"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="227"/>
        <source>Server</source>
        <translation>Сервер</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="235"/>
        <source>&amp;OpenSubtitles server:</source>
        <translation>Сервер &amp;OpenSubtitles:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="113"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="20"/>
        <source>General</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="28"/>
        <source>Search &amp;method:</source>
        <translation>Способ &amp;поиска:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="66"/>
        <source>Opensubtitles Credentials</source>
        <translation>Учётные данные Opensubtitles</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="119"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Включить прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="132"/>
        <source>&amp;Host:</source>
        <translation>&amp;Хост:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="145"/>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="74"/>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="165"/>
        <source>&amp;Username:</source>
        <translation>&amp;Имя пользователя:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="91"/>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="178"/>
        <source>Pa&amp;ssword:</source>
        <translation>Па&amp;роль:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="195"/>
        <source>&amp;Type:</source>
        <translation>&amp;Тип:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="56"/>
        <source>A&amp;ppend language code to the subtitle filename</source>
        <translation>&amp;Добавить код языка к имени файла субтитров</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="252"/>
        <source>Number of &amp;retries:</source>
        <translation>Количество &amp;попыток:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="232"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="233"/>
        <source>Uploaded by</source>
        <translation>Загружено</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="274"/>
        <source>Portuguese - Brasil</source>
        <translation>Португальский (Бразилия)</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="269"/>
        <source>Spanish - Spain</source>
        <translation>Испанский (Испания)</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="247"/>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="251"/>
        <source>Portuguese</source>
        <translation>Португальский</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="270"/>
        <source>Spanish - Latin America</source>
        <translation>Испанский (Латинская Америка)</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="282"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="291"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Subtitles service powered by %1</source>
        <translation>Служба субтитров предоставлена %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="405"/>
        <source>Connecting...</source>
        <translation>Соединение…</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="415"/>
        <source>Login to opensubtitles.org has failed</source>
        <translation>Не удалось войти в OpenSubtitles.org</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="419"/>
        <source>Search has failed</source>
        <translation>Поиск не удался</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="584"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="586"/>
        <source>Save File</source>
        <translation>Сохранить файл</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="667"/>
        <source>Error fixing the subtitle lines</source>
        <translation>Ошибка при исправлении строк субтитров</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>&amp;Download</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="296"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Копировать ссылку в буфер обмена</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="399"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="400"/>
        <source>Download failed: %1.</source>
        <translation>Ошибка загрузки: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="429"/>
        <source>Downloading...</source>
        <translation>Загрузка…</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="437"/>
        <source>Done.</source>
        <translation>Завершено.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="483"/>
        <source>%1 files available</source>
        <translation>%1 файлов доступно</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="492"/>
        <source>Failed to parse the received data.</source>
        <translation>Ошибка обработки полученных данных.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="14"/>
        <source>Find Subtitles</source>
        <translation>Найти субтитры</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="28"/>
        <source>&amp;Video file:</source>
        <translation>&amp;Видеофайл:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="49"/>
        <source>Search for &amp;title:</source>
        <translation>Поиск по &amp;заголовку:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="59"/>
        <source>Type here a movie or TV show title</source>
        <translation>Укажите здесь заголовок фильма или телешоу</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="66"/>
        <source>&amp;Search</source>
        <translation>&amp;Поиск</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Язык:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="603"/>
        <source>Subtitle saved as %1</source>
        <translation>Субтитры сохранены как %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="598"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="599"/>
        <source>It wasn't possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Не удалось сохранить загруженный
файл в каталоге %1
Проверьте права на этот каталог.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="397"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="554"/>
        <source>Download failed</source>
        <translation>Ошибка загрузки</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Параметры</translation>
    </message>
</context>
<context>
    <name>FontCacheDialog</name>
    <message>
        <location filename="../fontcache.cpp" line="27"/>
        <source>SMPlayer is initializing</source>
        <translation>Инициализация SMPlayer</translation>
    </message>
    <message>
        <location filename="../fontcache.cpp" line="28"/>
        <source>Creating a font cache...</source>
        <translation>Создание кэша шрифтов…</translation>
    </message>
</context>
<context>
    <name>GlobalShortcutsDialog</name>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="23"/>
        <source>Select the multimedia keys that SMPlayer will capture.</source>
        <translation>Выберите мультимедийные клавиши, которые SMPlayer будет распознавать.</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="35"/>
        <source>Media &amp;Play</source>
        <translation>Медиа &amp;Играть</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="42"/>
        <source>Media &amp;Stop</source>
        <translation>Медиа &amp;Стоп</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="49"/>
        <source>Media Pre&amp;vious</source>
        <translation>Медиа П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="56"/>
        <source>Media &amp;Next</source>
        <translation>Медиа &amp;Следующий</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="63"/>
        <source>Media P&amp;ause</source>
        <translation>Медиа &amp;Пауза</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="97"/>
        <source>Media &amp;Record</source>
        <translation>Медиа &amp;Запись</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="104"/>
        <source>Volume &amp;Mute</source>
        <translation>Громкость &amp;приглушить</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="111"/>
        <source>Volume &amp;Down</source>
        <translation>Громкость &amp;ниже</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.ui" line="118"/>
        <source>Volume &amp;Up</source>
        <translation>Громкость &amp;выше</translation>
    </message>
    <message>
        <location filename="../globalshortcuts/globalshortcutsdialog.cpp" line="26"/>
        <source>Global Shortcuts</source>
        <translation>Глобальные горячие клавиши</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="78"/>
        <source>General</source>
        <translation>Основная информация</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="82"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="82"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="86"/>
        <source>URL</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="93"/>
        <source>Length</source>
        <translation>Длительность</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="94"/>
        <source>Demuxer</source>
        <translation>Демультиплексор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <location filename="../infofile.cpp" line="141"/>
        <location filename="../infofile.cpp" line="170"/>
        <location filename="../infofile.cpp" line="190"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="100"/>
        <source>Artist</source>
        <translation>Исполнитель</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="103"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Дорожка</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Авторское право</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Примечание</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Программа</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="121"/>
        <source>Clip info</source>
        <translation>Информация о клипе</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="129"/>
        <source>Resolution</source>
        <translation>Разрешение экрана</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <location filename="../infofile.cpp" line="160"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <location filename="../infofile.cpp" line="161"/>
        <source>Bitrate</source>
        <translation>Битрейт</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <location filename="../infofile.cpp" line="161"/>
        <source>%1 kbps</source>
        <translation>%1 кбит/с</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <source>Frames per second</source>
        <translation>Частота кадров</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="164"/>
        <source>Selected codec</source>
        <translation>Выбранный кодек</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="140"/>
        <source>Video Streams</source>
        <translation>Видео-потоки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="159"/>
        <source>Initial Audio Stream</source>
        <translation>Звуковая дорожка по умолчанию</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="162"/>
        <source>Rate</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="162"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="163"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="169"/>
        <source>Audio Streams</source>
        <translation>Звуковые дорожки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <location filename="../infofile.cpp" line="170"/>
        <location filename="../infofile.cpp" line="190"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="248"/>
        <source>Track %1</source>
        <translation>Дорожка %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="251"/>
        <location filename="../infofile.cpp" line="259"/>
        <source>Language: %1</source>
        <translation>Язык: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="252"/>
        <location filename="../infofile.cpp" line="260"/>
        <source>Name: %1</source>
        <translation>Имя: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="253"/>
        <location filename="../infofile.cpp" line="261"/>
        <source>ID: %1</source>
        <translation>Идентификатор: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="255"/>
        <location filename="../infofile.cpp" line="263"/>
        <source>Type: %1</source>
        <translation>Тип: %1</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="189"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="128"/>
        <source>Initial Video Stream</source>
        <translation>Первичный видео-поток</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="190"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Название потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Адрес потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="81"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
</context>
<context>
    <name>InfoWindow</name>
    <message>
        <location filename="../infowindow.ui" line="36"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
</context>
<context>
    <name>InputBookmark</name>
    <message>
        <location filename="../inputbookmark.ui" line="14"/>
        <source>Add new bookmark</source>
        <translation>Добавить новую закладку</translation>
    </message>
    <message>
        <location filename="../inputbookmark.ui" line="22"/>
        <source>&amp;Time:</source>
        <translation>&amp;Время:</translation>
    </message>
    <message>
        <location filename="../inputbookmark.ui" line="48"/>
        <source>&amp;Name (optional):</source>
        <translation>&amp;Имя (необязательно):</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="43"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="13"/>
        <source>SMPlayer - Play a DVD from a folder</source>
        <translation>SMPlayer – Воспроизвести DVD из каталога</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="36"/>
        <source>You can play a DVD from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Вы можете проигрывать DVD с жёсткого диска. Просто укажите папку, содержащую директории VIDEO_TS и AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="69"/>
        <source>Choose a directory...</source>
        <translation>Обзор…</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="14"/>
        <source>SMPlayer - Enter the MPlayer version</source>
        <translation>SMPlayer – Укажите версию MPlayer</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="35"/>
        <source>SMPlayer couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>SMPlayer не может определить используемую вами версию MPlayer.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="58"/>
        <source>Version reported by MPlayer:</source>
        <translation>Версия, полученная от MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="102"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Пожалуйста, &amp;выберите правильную версию:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="113"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 или старше</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="118"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="123"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 или новее</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="13"/>
        <source>SMPlayer - Enter URL</source>
        <translation>SMPlayer – Укажите адрес</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="64"/>
        <source>&amp;URL:</source>
        <translation>&amp;Адрес:</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="24"/>
        <source>Afar</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="25"/>
        <source>Abkhazian</source>
        <translation>Абхазский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afrikaans</source>
        <translation>Африкаанс</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Amharic</source>
        <translation>Амхарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <location filename="../languages.cpp" line="310"/>
        <source>Arabic</source>
        <translation>Арабский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Assamese</source>
        <translation>Ассамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <source>Aymara</source>
        <translation>Аймара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Azerbaijani</source>
        <translation>Азербайджанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Bashkir</source>
        <translation>Башкирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <location filename="../languages.cpp" line="336"/>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bihari</source>
        <translation>Бихари</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Bislama</source>
        <translation>Бислама</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bengali</source>
        <translation>Бенгальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Tibetan</source>
        <translation>Тибетский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Breton</source>
        <translation>Бретонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Catalan</source>
        <translation>Каталонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Corsican</source>
        <translation>Корсиканский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <location filename="../languages.cpp" line="337"/>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <source>Welsh</source>
        <translation>Валлийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Danish</source>
        <translation>Датский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <location filename="../languages.cpp" line="224"/>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Английский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Esperanto</source>
        <translation>Эсперанто</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="338"/>
        <source>Estonian</source>
        <translation>Эстонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Basque</source>
        <translation>Баскский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <source>Persian</source>
        <translation>Персидский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Faroese</source>
        <translation>Фарерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="228"/>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Frisian</source>
        <translation>Фризский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Irish</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Galician</source>
        <translation>Галисийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Guarani</source>
        <translation>Гуарани</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gujarati</source>
        <translation>Гуджарати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Hausa</source>
        <translation>Хауса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Hebrew</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Hindi</source>
        <translation>Хинди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <location filename="../languages.cpp" line="339"/>
        <source>Croatian</source>
        <translation>Хорватский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <location filename="../languages.cpp" line="340"/>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Armenian</source>
        <translation>Армянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Interlingua</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Indonesian</source>
        <translation>Индонезийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Interlingue</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Icelandic</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Inuktitut</source>
        <translation>Инуктитут</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <location filename="../languages.cpp" line="230"/>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <source>Javanese</source>
        <translation>Яванский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kazakh</source>
        <translation>Казахский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Greenlandic</source>
        <translation>Гренландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kannada</source>
        <translation>Каннада</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Korean</source>
        <translation>Корейский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kashmiri</source>
        <translation>Кашмирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <source>Kurdish</source>
        <translation>Курдский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <source>Kirghiz</source>
        <translation>Киргизский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Latin</source>
        <translation>Латинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Lingala</source>
        <translation>Лингала</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <location filename="../languages.cpp" line="341"/>
        <source>Lithuanian</source>
        <translation>Литовский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <location filename="../languages.cpp" line="342"/>
        <source>Latvian</source>
        <translation>Латвийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <source>Malagasy</source>
        <translation>Малагасийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Maori</source>
        <translation>Маори</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Macedonian</source>
        <translation>Македонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Malayalam</source>
        <translation>Малаялам</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Mongolian</source>
        <translation>Монгольский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <source>Moldavian</source>
        <translation>Молдавский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Marathi</source>
        <translation>Маратхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Malay</source>
        <translation>Малайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Maltese</source>
        <translation>Мальтийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Burmese</source>
        <translation>Бирманский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Nauru</source>
        <translation>Науру</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>BokmÃ¥l</source>
        <translation>Букмол</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Nepali</source>
        <translation>Непальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian Nynorsk</source>
        <translation>Норвежский (Нюношк)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="146"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Norwegian</source>
        <translation>Норвежский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Occitan</source>
        <translation>Окситанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Oriya</source>
        <translation>Ория</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <location filename="../languages.cpp" line="343"/>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Portuguese</source>
        <translation>Португальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Quechua</source>
        <translation>Кечуа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <location filename="../languages.cpp" line="234"/>
        <location filename="../languages.cpp" line="317"/>
        <location filename="../languages.cpp" line="344"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Kinyarwanda</source>
        <translation>Киньяруанда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sanskrit</source>
        <translation>Санскрит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sindhi</source>
        <translation>Синдхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="345"/>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Samoan</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Shona</source>
        <translation>Шона</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Somali</source>
        <translation>Сомалийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <source>Albanian</source>
        <translation>Албанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <source>Sundanese</source>
        <translation>Суданский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Swahili</source>
        <translation>Суахили</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Tamil</source>
        <translation>Тамил</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Telugu</source>
        <translation>Телугу</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Tajik</source>
        <translation>Таджикский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Thai</source>
        <translation>Тайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Tigrinya</source>
        <translation>Тигринья</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Turkmen</source>
        <translation>Туркменский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tagalog</source>
        <translation>Тагальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <source>Tonga</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <location filename="../languages.cpp" line="312"/>
        <source>Turkish</source>
        <translation>Турецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tsonga</source>
        <translation>Тсонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Tatar</source>
        <translation>Татарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Twi</source>
        <translation>Тви</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <source>Uighur</source>
        <translation>Уйгурский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <location filename="../languages.cpp" line="347"/>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Urdu</source>
        <translation>Урду</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Uzbek</source>
        <translation>Узбекский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="203"/>
        <source>Vietnamese</source>
        <translation>Вьетнамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>VolapÃ¼k</source>
        <translation>Волапюк</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Wolof</source>
        <translation>Волоф</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Xhosa</source>
        <translation>Коса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="212"/>
        <source>Yiddish</source>
        <translation>Идиш</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="213"/>
        <source>Yoruba</source>
        <translation>Йоруба</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="214"/>
        <source>Zhuang</source>
        <translation>Чжуан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="215"/>
        <location filename="../languages.cpp" line="236"/>
        <location filename="../languages.cpp" line="348"/>
        <source>Chinese</source>
        <translation>Китайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="216"/>
        <source>Zulu</source>
        <translation>Зулусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="245"/>
        <source>Arabic - Syria</source>
        <translation>Арабский - Сирия</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="302"/>
        <source>Unicode</source>
        <translation>Юникод</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="303"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="304"/>
        <source>Western European Languages</source>
        <translation>Восточноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="305"/>
        <source>Western European Languages with Euro</source>
        <translation>Восточноевропейская с Евро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="306"/>
        <source>Slavic/Central European Languages</source>
        <translation>Славянская/центральноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="307"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Эсперанто, Галисийская, Мальтийская, Турецкая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="308"/>
        <source>Old Baltic charset</source>
        <translation>Старая Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="309"/>
        <source>Cyrillic</source>
        <translation>Кириллица</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="311"/>
        <source>Modern Greek</source>
        <translation>Греческая новая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="313"/>
        <source>Baltic</source>
        <translation>Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="314"/>
        <source>Celtic</source>
        <translation>Кельтская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="315"/>
        <source>South-Eastern European</source>
        <translation>Юго-восточноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="316"/>
        <source>Hebrew charsets</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="318"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Украинская, Белорусская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="319"/>
        <source>Simplified Chinese charset</source>
        <translation>Китайская упрощённая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="320"/>
        <source>Traditional Chinese charset</source>
        <translation>Китайская традиционная</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="321"/>
        <source>Japanese charsets</source>
        <translation>Японская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="322"/>
        <source>Korean charset</source>
        <translation>Корейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="323"/>
        <source>Thai charset</source>
        <translation>Тайская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="324"/>
        <source>Cyrillic Windows</source>
        <translation>Кириллица Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="325"/>
        <source>Slavic/Central European Windows</source>
        <translation>Славянская/центральноевропейская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="326"/>
        <source>Arabic Windows</source>
        <translation>Арабская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="26"/>
        <source>Avestan</source>
        <translation>Авестийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Akan</source>
        <translation>Акан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Aragonese</source>
        <translation>Арагонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Avaric</source>
        <translation>Аварский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <location filename="../languages.cpp" line="335"/>
        <source>Belarusian</source>
        <translation>Белорусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <source>Bambara</source>
        <translation>Бамана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bosnian</source>
        <translation>Боснийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Chechen</source>
        <translation>Чеченский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <source>Cree</source>
        <translation>Кри</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Church</source>
        <translation>Церковный</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Chuvash</source>
        <translation>Чувашский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Divehi</source>
        <translation>Мальдивский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Dzongkha</source>
        <translation>Дзонг-кэ</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <source>Ewe</source>
        <translation>Эве</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <source>Fulah</source>
        <translation>Фула</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Fijian</source>
        <translation>Фиджийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <source>Gaelic</source>
        <translation>Гойдельский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <source>Manx</source>
        <translation>Мэнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hiri</source>
        <translation>Хири-моту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Haitian</source>
        <translation>Гаитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Herero</source>
        <translation>Гереро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <source>Chamorro</source>
        <translation>Чаморро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Igbo</source>
        <translation>Игбо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Sichuan</source>
        <translation>Сычуаньский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Inupiaq</source>
        <translation>Инуитский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Ido</source>
        <translation>Идо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <source>Kongo</source>
        <translation>Конго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Kikuyu</source>
        <translation>Кикуйю</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <source>Kuanyama</source>
        <translation>Кваньяма</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Khmer</source>
        <translation>Кхмерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Kanuri</source>
        <translation>Канури</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Komi</source>
        <translation>Коми</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Cornish</source>
        <translation>Корнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Luxembourgish</source>
        <translation>Люксембургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Ganda</source>
        <translation>Луганда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Limburgan</source>
        <translation>Лимбургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Lao</source>
        <translation>Лаосский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Luba-Katanga</source>
        <translation>Луба-Катанга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Marshallese</source>
        <translation>Маршалльский</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Букмол</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <location filename="../languages.cpp" line="147"/>
        <source>Ndebele</source>
        <translation>Ндебеле</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <source>Ndonga</source>
        <translation>Ндонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Navajo</source>
        <translation>Навахо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Chichewa</source>
        <translation>Ньянджа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Ojibwa</source>
        <translation>Оджибва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oromo</source>
        <translation>Оромо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Ossetian</source>
        <translation>Осетинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Panjabi</source>
        <translation>Панджаби</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <source>Pali</source>
        <translation>Пали</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Pushto</source>
        <translation>Пушту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Romansh</source>
        <translation>Романшский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <source>Rundi</source>
        <translation>Рунди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sardinian</source>
        <translation>Сардинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sami</source>
        <translation>Саамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sango</source>
        <translation>Санго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <source>Sinhala</source>
        <translation>Сингальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <location filename="../languages.cpp" line="346"/>
        <source>Slovene</source>
        <translation>Словенский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Swati</source>
        <translation>Свати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sotho</source>
        <translation>Сесото</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tswana</source>
        <translation>Тсвана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Tahitian</source>
        <translation>Таитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <source>Venda</source>
        <translation>Венда</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="207"/>
        <source>Volapük</source>
        <translation>Волапюк</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Walloon</source>
        <translation>Валлонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="327"/>
        <source>Modern Greek Windows</source>
        <translation>Новогреческий язык Windows</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="107"/>
        <source>Choose a filename to save under</source>
        <translation>Выберите имя файла для сохранения</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="114"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файл уже существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="133"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="134"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Не удалось сохранить журнал</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="108"/>
        <source>Logs</source>
        <translation>Журналы</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="58"/>
        <location filename="../logwindow.ui" line="61"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="68"/>
        <location filename="../logwindow.ui" line="71"/>
        <source>Copy to clipboard</source>
        <translation>Копировать в буфер обмена</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="78"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../logwindow.ui" line="81"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
</context>
<context>
    <name>MPVProcess</name>
    <message>
        <location filename="../mpvoptions.cpp" line="203"/>
        <location filename="../mpvprocess.h" line="208"/>
        <source>the &apos;%1&apos; filter is not supported by mpv</source>
        <translation>Фильтр &apos;%1&apos; не поддерживается в mpv</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="929"/>
        <location filename="../mpvprocess.h" line="209"/>
        <source>File:</source>
        <translation>Файл:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="932"/>
        <location filename="../mpvprocess.h" line="210"/>
        <source>Video:</source>
        <translation>Видео:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="933"/>
        <location filename="../mpvprocess.h" line="211"/>
        <source>Resolution:</source>
        <translation>Разрешение:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="934"/>
        <location filename="../mpvprocess.h" line="212"/>
        <source>Frames per second:</source>
        <translation>Частота кадров:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="934"/>
        <location filename="../mpvprocess.h" line="213"/>
        <source>Estimated:</source>
        <translation>Расчётная:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="936"/>
        <location filename="../mpvprocess.h" line="214"/>
        <source>Aspect Ratio:</source>
        <translation>Соотношение сторон:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="937"/>
        <location filename="../mpvoptions.cpp" line="942"/>
        <location filename="../mpvprocess.h" line="215"/>
        <location filename="../mpvprocess.h" line="218"/>
        <source>Bitrate:</source>
        <translation>Битрейт:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="938"/>
        <location filename="../mpvprocess.h" line="216"/>
        <source>Dropped frames:</source>
        <translation>Пропущено кадров:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="941"/>
        <location filename="../mpvprocess.h" line="217"/>
        <source>Audio:</source>
        <translation>Звук:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="943"/>
        <location filename="../mpvprocess.h" line="219"/>
        <source>Sample Rate:</source>
        <translation>Частота дискретизации:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="944"/>
        <location filename="../mpvprocess.h" line="220"/>
        <source>Channels:</source>
        <translation>Каналы:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="947"/>
        <location filename="../mpvprocess.h" line="221"/>
        <source>Audio/video synchronization:</source>
        <translation>Синхронизация аудио/видео:</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="950"/>
        <source>Cache (in seconds):</source>
        <translation>Кэш (в секундах):</translation>
    </message>
    <message>
        <location filename="../mpvoptions.cpp" line="951"/>
        <source>Cache speed:</source>
        <translation>Скорость кэша:</translation>
    </message>
    <message>
        <location filename="../mpvprocess.h" line="222"/>
        <source>Cache fill:</source>
        <translation>Заполнение кэша:</translation>
    </message>
    <message>
        <location filename="../mpvprocess.h" line="223"/>
        <source>Used cache:</source>
        <translation>Использованный кэш:</translation>
    </message>
</context>
<context>
    <name>MediaPanel</name>
    <message>
        <location filename="../skingui/mediapanel.cpp" line="246"/>
        <source>Shuffle playlist</source>
        <translation>Перемешать плейлист</translation>
    </message>
    <message>
        <location filename="../skingui/mediapanel.cpp" line="247"/>
        <source>Repeat playlist</source>
        <translation>Повторять плейлист</translation>
    </message>
</context>
<context>
    <name>MiniGui</name>
    <message>
        <location filename="../minigui.cpp" line="181"/>
        <source>Control bar</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <location filename="../minigui.cpp" line="184"/>
        <source>Edit &amp;control bar</source>
        <translation>Изменить панель &amp;управления</translation>
    </message>
    <message>
        <location filename="../minigui.cpp" line="185"/>
        <source>Edit &amp;floating control</source>
        <translation>Изменить &amp;плавающую панель</translation>
    </message>
</context>
<context>
    <name>MpcGui</name>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="150"/>
        <source>Control bar</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="151"/>
        <source>Seek bar</source>
        <translation>Полоса перемотки</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="463"/>
        <location filename="../mpcgui/mpcgui.cpp" line="464"/>
        <location filename="../mpcgui/mpcgui.cpp" line="465"/>
        <source>-%1</source>
        <translation>–%1</translation>
    </message>
    <message>
        <location filename="../mpcgui/mpcgui.cpp" line="467"/>
        <location filename="../mpcgui/mpcgui.cpp" line="468"/>
        <location filename="../mpcgui/mpcgui.cpp" line="469"/>
        <source>+%1</source>
        <translation>+%1</translation>
    </message>
</context>
<context>
    <name>MplayerProcess</name>
    <message>
        <location filename="../mplayeroptions.cpp" line="434"/>
        <location filename="../mplayeroptions.cpp" line="511"/>
        <source>This option is not supported by MPlayer</source>
        <translation>Этот параметр не поддерживается в MPlayer</translation>
    </message>
</context>
<context>
    <name>MultilineInputDialog</name>
    <message>
        <location filename="../multilineinputdialog.ui" line="13"/>
        <source>Enter URL(s)</source>
        <translation>Введите ссылку(и)</translation>
    </message>
    <message>
        <location filename="../multilineinputdialog.ui" line="19"/>
        <source>Enter the URL(s) to be added to the playlist. One per line.</source>
        <translation>Введите ссылку(и) для добавления в плейлист. По одной на строку.</translation>
    </message>
</context>
<context>
    <name>OpenWithDeviceDialog</name>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="14"/>
        <source>Play on device</source>
        <translation>Проиграть на устройстве</translation>
    </message>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="20"/>
        <source>To play this video in a smartphone or tablet, scan the following QR code with your device:</source>
        <translation>Для того, чтобы проиграть это видео на смартфоне или планшете, надо отсканировать этот QR-код с помощью устройства:</translation>
    </message>
    <message>
        <location filename="../qrcode/openwithdevicedialog.ui" line="46"/>
        <source>Or open this URL in your device&apos;s media player:</source>
        <translation>Или откройте этот URL-адрес в медиаплеере вашего устройства:</translation>
    </message>
</context>
<context>
    <name>PlayControl</name>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="186"/>
        <source>Rewind</source>
        <translation>Перемотка назад</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="187"/>
        <source>Forward</source>
        <translation>Перемотка вперёд</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="188"/>
        <source>Play / Pause</source>
        <translation>Воспроизвести / Пауза</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="189"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="190"/>
        <source>Record</source>
        <translation>Запись</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="191"/>
        <source>Next file in playlist</source>
        <translation>Следующий файл плейлиста</translation>
    </message>
    <message>
        <location filename="../skingui/playcontrol.cpp" line="192"/>
        <source>Previous file in playlist</source>
        <translation>Предыдущий файл плейлиста</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Length</source>
        <translation>Длина</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="730"/>
        <source>&amp;Play</source>
        <translation>&amp;Воспроизвести</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="777"/>
        <source>&amp;Edit</source>
        <translation>&amp;Изменить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1389"/>
        <location filename="../playlist.cpp" line="1425"/>
        <source>Playlists</source>
        <translation>Плейлисты</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1387"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1423"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1435"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1436"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 уже существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1389"/>
        <location filename="../playlist.cpp" line="1425"/>
        <location filename="../playlist.cpp" line="1738"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="399"/>
        <source>Untitled playlist</source>
        <translation>Безымянный плейлист</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="722"/>
        <source>&amp;Load...</source>
        <translation>&amp;Загрузить…</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="724"/>
        <source>Load playlist from &amp;URL...</source>
        <translation>Загрузить плейлист по &amp;ссылке…</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="763"/>
        <source>Play on Chromec&amp;ast</source>
        <translation>Проиграть в Chromec&amp;ast</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="765"/>
        <source>Open stream in &amp;a web browser</source>
        <translation>Открыть поток в &amp;веб-браузере</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="781"/>
        <source>Load/Save</source>
        <translation>Загрузить/сохранить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1735"/>
        <source>Select one or more files to open</source>
        <translation>Выберите один или более файлов</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1804"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2001"/>
        <source>Edit name</source>
        <translation>Изменить имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2002"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Введите имя, которое будет отображаться для этого файла в плейлисте:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Filename / URL</source>
        <translation>Имя файла / адрес</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="720"/>
        <source>Shuffle order</source>
        <translation>Случайный порядок</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="725"/>
        <source>Download playlist from URL</source>
        <translation>Загрузить плейлист по ссылке</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="727"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="728"/>
        <source>Save &amp;as...</source>
        <translation>Сохранить &amp;как…</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="732"/>
        <source>&amp;Next</source>
        <translation>&amp;Следующий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="733"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="739"/>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="740"/>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="742"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Повторить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="743"/>
        <source>S&amp;huffle</source>
        <translation>Пере&amp;мешать</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="746"/>
        <source>Add &amp;current file</source>
        <translation>Добавить &amp;текущий файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="747"/>
        <source>Add &amp;file(s)</source>
        <translation>Добавить &amp;файл(ы)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="748"/>
        <source>Add &amp;directory</source>
        <translation>Добавить &amp;каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="749"/>
        <source>Add &amp;URL(s)</source>
        <translation>Добавить &amp;ссылку(и)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="752"/>
        <source>Remove &amp;selected</source>
        <translation>Убрать &amp;выбранные</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="753"/>
        <source>Remove &amp;all</source>
        <translation>Убрать &amp;все</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="756"/>
        <source>&amp;Delete file from disk</source>
        <translation>&amp;Удалить файл с диска</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="759"/>
        <location filename="../playlist.cpp" line="1533"/>
        <source>&amp;Copy file path to clipboard</source>
        <translation>&amp;Копировать путь к файлу в буфер обмена</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="760"/>
        <source>&amp;Open source folder</source>
        <translation>&amp;Открыть папку источника</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="768"/>
        <location filename="../playlist.cpp" line="789"/>
        <source>Search</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="770"/>
        <source>Show position column</source>
        <translation>Показать столбец позиции</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="771"/>
        <source>Show name column</source>
        <translation>Показать столбец имени</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="772"/>
        <source>Show length column</source>
        <translation>Показать столбец длины</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="773"/>
        <source>Show filename column</source>
        <translation>Показать столбец имени файла</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="774"/>
        <source>Show shuffle column</source>
        <translation>Показать столбец случайного порядка</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1538"/>
        <source>&amp;Copy URL to clipboard</source>
        <translation>&amp;Копировать ссылку в буфер обмена</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2039"/>
        <source>Confirm deletion</source>
        <translation>Подтвердить удаление</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2040"/>
        <source>You&apos;re about to DELETE the file &apos;%1&apos; from your drive.</source>
        <translation>Вы собираетесь УДАЛИТЬ файл &apos;%1&apos; с вашего диска.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2041"/>
        <source>This action cannot be undone. Are you sure you want to proceed?</source>
        <translation>Это действие необратимо. Вы действительно хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2059"/>
        <source>Deletion failed</source>
        <translation>Удаление не удалось</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2060"/>
        <source>It wasn&apos;t possible to delete &apos;%1&apos;</source>
        <translation>Не удалось удалить &apos;%1&apos;</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2065"/>
        <source>Error deleting the file</source>
        <translation>Ошибка при удалении файла</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2066"/>
        <source>It&apos;s not possible to delete &apos;%1&apos; from the filesystem.</source>
        <translation>Невозможно удалить &apos;%1&apos; из файловой системы.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2553"/>
        <source>It&apos;s not possible to load this playlist</source>
        <translation>Невозможно загрузить этот плейлист</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="2553"/>
        <source>Unrecognized format.</source>
        <translation>Неизвестный формат.</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="783"/>
        <source>Add...</source>
        <translation>Добавить…</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="785"/>
        <source>Remove...</source>
        <translation>Убрать…</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1468"/>
        <source>Playlist modified</source>
        <translation>Плейлист изменён</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1469"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>В плейлисте есть несохранённые изменения. Хотите сохранить?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1737"/>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
</context>
<context>
    <name>PrefAdvanced</name>
    <message>
        <location filename="../prefadvanced.cpp" line="79"/>
        <location filename="../prefadvanced.cpp" line="455"/>
        <source>Advanced</source>
        <translation>Дополнительно</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="92"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="24"/>
        <source>&amp;Advanced</source>
        <translation>&amp;Дополнительно</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="568"/>
        <source>Log SMPlayer output</source>
        <translation>Журналировать вывод SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="653"/>
        <source>This option is mainly intended for debugging the application.</source>
        <translation>Эти настройки в основном необходимы для отладки приложения.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="599"/>
        <source>Filter for SMPlayer logs</source>
        <translation>Фильтр для журналов SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="48"/>
        <source>&amp;Monitor aspect:</source>
        <translation>&amp;Соотношение сторон монитора:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="112"/>
        <source>Use the la&amp;vf demuxer by default</source>
        <translation>По умолчанию использовать демультиплексор la&amp;vf</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="200"/>
        <source>O&amp;SD bar position:</source>
        <translation>По&amp;ложение панели OSD:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="238"/>
        <source>Display the name o&amp;f the media in the window title</source>
        <translation>Отобр&amp;ажать название медиа в заголовке окна</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="253"/>
        <source>Color&amp;key:</source>
        <translation>Код &amp;цвета:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="351"/>
        <source>&amp;Options:</source>
        <translation>&amp;Параметры:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="377"/>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видеофильтры:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="586"/>
        <source>SMPlayer</source>
        <translation>SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="592"/>
        <source>Log &amp;SMPlayer output</source>
        <translation>Журналировать &amp;вывод SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="663"/>
        <source>&amp;Filter for SMPlayer logs:</source>
        <translation>&amp;Фильтр для журналов SMPlayer:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="276"/>
        <source>C&amp;hange...</source>
        <translation>Из&amp;менить…</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="565"/>
        <source>Logs</source>
        <translation>Журналы</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="457"/>
        <source>Monitor aspect</source>
        <translation>Соотношение сторон монитора</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="458"/>
        <source>Select the aspect ratio of your monitor.</source>
        <translation>Выберите соотношение сторон монитора.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="467"/>
        <source>Use the lavf demuxer by default</source>
        <translation>По умолчанию использовать демультиплексор lavf</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="468"/>
        <source>If this option is checked, the lavf demuxer will be used for all formats.</source>
        <translation>Если этот параметр включён, для всех форматов будет использоваться демультиплексор lavf.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="545"/>
        <source>This option may be needed to play playlist files (m3u, pls...). However it can involve a security risk when playing internet sources because the way MPlayer parses and uses playlist files is not safe against maliciously constructed files.</source>
        <translation>Данный параметр может быть необходим для воспроизведения плейлистов (m3u, pls и др). Однако это представляет определённую угрозу, ввиду того, что MPlayer практически беззащитен при чтении и использовании различных плейлистов из интернета.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="496"/>
        <source>Limitation: the actions are run only when a file is opened and not when the %1 process is restarted (e.g. you select an audio or video filter).</source>
        <translation>Ограничение: действия запускаются только при открытии файла, но не при перезапуске процесса %1 (например, при выборе аудио или видеофильтра).</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="508"/>
        <source>Colorkey</source>
        <translation>Код цвета</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="509"/>
        <source>If you see parts of the video over any other window, you can change the colorkey to fix it. Try to select a color close to black.</source>
        <translation>Если вы видите, некоторые части видео на других окнах, вы можете изменить код цвета, чтобы исправить это. Попытайтесь выбрать цвет близкий к чёрному.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="517"/>
        <source>Options</source>
        <translation>Параметры</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="521"/>
        <source>Video filters</source>
        <translation>Видеофильтры</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="525"/>
        <source>Audio filters</source>
        <translation>Аудиофильтры</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="472"/>
        <source>Repaint the background of the video window</source>
        <translation>Перерисовывать фон окна с видео</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="119"/>
        <source>Repaint the backgroun&amp;d of the video window</source>
        <translation>Пере&amp;рисовывать фон окна воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="559"/>
        <source>IPv4</source>
        <translation>IPv4</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="560"/>
        <source>Use IPv4 on network connections. Falls back on IPv6 automatically.</source>
        <translation>Использовать IPv4 для сетевых соединений. При ошибках переходит на IPv6 автоматически.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="562"/>
        <source>IPv6</source>
        <translation>IPv6</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="563"/>
        <source>Use IPv6 on network connections. Falls back on IPv4 automatically.</source>
        <translation>Использовать IPv6 для сетевых соединений. При ошибках переходит на IPv4 автоматически.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="472"/>
        <source>Network Connection</source>
        <translation>Сетевое соединение</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="484"/>
        <source>IPv&amp;4</source>
        <translation>IPv&amp;4</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="491"/>
        <source>IPv&amp;6</source>
        <translation>IPv&amp;6</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="515"/>
        <source>Lo&amp;gs</source>
        <translation>&amp;Журналы</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="460"/>
        <source>Rebuild index if needed</source>
        <translation>Перестроить индекс, если необходимо</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="105"/>
        <source>Rebuild &amp;index if needed</source>
        <translation>Перестроить &amp;индекс, если необходимо</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="569"/>
        <source>If this option is checked, SMPlayer will store the debugging messages that SMPlayer outputs (you can see the log in &lt;b&gt;Options -&gt; View logs -&gt; SMPlayer&lt;/b&gt;). This information can be very useful for the developer in case you find a bug.</source>
        <translation>Если этот параметр отмечен, SMPlayer сохранит отладочные сообщения вывода SMPlayer (их можно увидеть в &lt;b&gt;Параметры -&gt; Смотреть журналы -&gt; SMPlayer&lt;/b&gt;). Эта информация может быть полезна разработчикам, если вы нашли баг.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="581"/>
        <source>Log %1 output</source>
        <translation>Журналировать вывод %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="582"/>
        <source>If checked, SMPlayer will store the output of %1 (you can see it in &lt;b&gt;Options -&gt; View logs -&gt; %1&lt;/b&gt;). In case of problems this log can contain important information, so it&apos;s recommended to keep this option checked.</source>
        <translation>Если выбрано, SMPlayer будет сохранять сообщения %1 (их можно просмотреть в &lt;b&gt;Параметры -&gt; Смотреть журналы -&gt; %1&lt;/b&gt;). Журналы могут содержать важную информацию о возникших проблемах, поэтому рекомендуется включить этот параметр.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="587"/>
        <source>Autosave %1 log</source>
        <translation>Автосохранение журнала %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="588"/>
        <source>If this option is checked, the %1 log will be saved to the specified file every time a new file starts to play. It&apos;s intended for external applications, so they can get info about the file you&apos;re playing.</source>
        <translation>Если отмечено, журнал %1 будет сохранён в специальный файл каждый раз, когда начнётся воспроизведение нового файла. Это может требоваться для внешних приложений, которые получают информацию о воспроизводимом файле.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="593"/>
        <source>Autosave %1 log filename</source>
        <translation>Автосохранение имени файла журнала %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="594"/>
        <source>Enter here the path and filename that will be used to save the %1 log.</source>
        <translation>Введите путь и имя файла, используемого для сохранения журнала %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="600"/>
        <source>This option allows to filter the SMPlayer messages that will be stored in the log. Here you can write any regular expression.&lt;br&gt;For instance: &lt;i&gt;^Core::.*&lt;/i&gt; will display only the lines starting with &lt;i&gt;Core::&lt;/i&gt;</source>
        <translation>Этот параметр позволяет фильтровать сообщения SMPlayer, которые сохраняются в журнале. Здесь вы можете записать любое регулярное выражение. &lt;br&gt;Для примера: &lt;i&gt;^Core::.*&lt;/i&gt; будет отображать только строки, начинающиеся с &lt;i&gt;Core::&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="478"/>
        <source>Correct pts</source>
        <translation>Корректировать метки времени</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="94"/>
        <source>&amp;Run %1 in its own window</source>
        <translation>&amp;Запускать %1 в отдельном окне</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="95"/>
        <source>&amp;Pass short filenames (8+3) to %1</source>
        <translation>Передавать &amp;короткие (8+3) имена в %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="519"/>
        <source>Write them separated by spaces.</source>
        <translation>Разделяйте их пробелами.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="101"/>
        <source>Log %1 &amp;output</source>
        <translation>Журна&amp;лировать вывод %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="96"/>
        <source>Notify %1 crash&amp;es</source>
        <translation>Уведомлять о сбо&amp;ях %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="99"/>
        <source>Here you can pass options and filters to %1.</source>
        <translation>Здесь вы можете указать параметры и фильтры %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="102"/>
        <source>A&amp;utosave %1 log to file</source>
        <translation>&amp;Автосохранение журнала %1 в файл</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="104"/>
        <source>Pa&amp;ss the %1 option to MPlayer (security risk)</source>
        <translation>&amp;Отправлять параметр %1 в MPlayer (небезопасно)</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="473"/>
        <source>Unchecking this option may reduce flickering, but it can also produce strange artifacts under certain circumstances.</source>
        <translation>Отключение этого параметра может уменьшить мерцание, но это также может привести к странным артефактам при определённых обстоятельствах.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="500"/>
        <source>OSD bar position</source>
        <translation>Положение панели экранного меню</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="501"/>
        <source>Set the position of the screen where the OSD bar is displayed. 0 is top, 100 bottom.</source>
        <translation>Указывает положение панели экранного меню на экране. 0 – верх, 100 – низ.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="503"/>
        <source>Display the name of the media in the window title</source>
        <translation>Отображать название медиа в заголовке окна</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="504"/>
        <source>If this option is enabled the media title from information tags will be displayed in the window title instead of the filename.</source>
        <translation>Если этот параметр включён, заголовок медиа из информационных тегов будет отображаться в заголовке окна вместо имени файла.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="529"/>
        <source>Run %1 in its own window</source>
        <translation>Запускать %1 в отдельном окне</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="530"/>
        <source>If you check this option, the %1 video window won&apos;t be embedded in SMPlayer&apos;s main window but instead it will use its own window. Note that mouse and keyboard events will be handled directly by %1, that means key shortcuts and mouse clicks probably won&apos;t work as expected when the %1 window has the focus.</source>
        <translation>При выборе этого параметра окно %1 не будет встроено в главное окно SMPlayer, а будет использовать своё собственное. Обратите внимание, что события клавиатуры и мыши будут переданы непосредственно %1, что означает, что назначенные горячие клавиши и события мыши могут не работать как нужно, если окно %1 находится в фокусе.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="538"/>
        <source>Notify %1 crashes</source>
        <translation>Уведомлять о сбоях %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="539"/>
        <source>If this option is checked, a popup window will be displayed to inform about %1 crashes. Otherwise those failures will be silently ignored.</source>
        <translation>Если этот параметр отмечен, то появится всплывающее окно с информацией о сбое %1. В ином случае подобные ошибки будут проигнорированы.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="552"/>
        <source>Pass short filenames (8+3) to %1</source>
        <translation>Передавать короткие (8+3) имена в %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="553"/>
        <source>If this option is checked, SMPlayer will pass to %1 the short version of the filenames.</source>
        <translation>Если этот параметр отмечен, SMPlayer передавать короткие названия файлов в %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="544"/>
        <source>Pass the %1 option to MPlayer (security risk)</source>
        <translation>Отправлять параметр %1 в MPlayer (небезопасно)</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="479"/>
        <source>Switches %1 to an experimental mode where timestamps for video frames are calculated differently and video filters which add new frames or modify timestamps of existing ones are supported. The more accurate timestamps can be visible for example when playing subtitles timed to scene changes with the SSA/ASS library enabled. Without correct pts the subtitle timing will typically be off by some frames. This option does not work correctly with some demuxers and codecs.</source>
        <translation>Переключает %1 в экспериментальный режим, в котором метки времени для кадров видео рассчитываются независимо, и тем самым поддерживаются видео фильтры, добавляющие новые кадры или меняющие метки времени существующих. Более точные метки времени могут быть заметны, например, при воспроизведении субтитров, привязанных к смене сцены, с включённой библиотекой SSA/ASS. Без корректировки меток времени тайминг субтитров, как правило, будет отключён некоторыми кадрами. С некоторыми демультиплексорами и кодеками этот параметр работает некорректно.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="488"/>
        <source>Actions list</source>
        <translation>Список действий</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="489"/>
        <source>Here you can specify a list of &lt;i&gt;actions&lt;/i&gt; which will be run every time a file is opened. You&apos;ll find all available actions in the key shortcut editor in the &lt;b&gt;Keyboard and mouse&lt;/b&gt; section. The actions must be separated by spaces. Checkable actions can be followed by &lt;i&gt;true&lt;/i&gt; or &lt;i&gt;false&lt;/i&gt; to enable or disable the action.</source>
        <translation>Здесь вы можете определить список &lt;i&gt;actions&lt;/i&gt; — действий, которые будут выполняться каждый раз при открытии файла. Список всех возможных действий вы можете найти в разделе &lt;b&gt;Устройства ввода&lt;/b&gt; окна настроек. Все действия должны быть разделены пробелами. Включаемые/отключаемые действия могут иметь последующий параметр &lt;i&gt;true&lt;/i&gt; или &lt;i&gt;false&lt;/i&gt; для включения или отключения действия.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="98"/>
        <source>Options for %1</source>
        <translation>Параметры для %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="518"/>
        <source>Here you can type options for %1.</source>
        <translation>Здесь вы можете указать дополнительные параметры %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="522"/>
        <source>Here you can add video filters for %1.</source>
        <translation>Здесь вы можете добавить видеофильтры %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="523"/>
        <location filename="../prefadvanced.cpp" line="527"/>
        <source>Write them separated by commas. Don&apos;t use spaces!</source>
        <translation>Укажите их, разделяя запятыми, но не используйте пробелы!</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="526"/>
        <source>Here you can add audio filters for %1.</source>
        <translation>Здесь вы можете добавить аудиофильтры %1.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="557"/>
        <source>Network</source>
        <translation>Сеть</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="169"/>
        <source>R&amp;un the following actions every time a file is opened. The actions must be separated with spaces:</source>
        <translation>&amp;Выполнять следующие действия при открытии файла. Действия разделяются пробелами:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="403"/>
        <source>A&amp;udio filters:</source>
        <translation>Аудио&amp;фильтры:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="466"/>
        <source>&amp;Network</source>
        <translation>&amp;Сеть</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="495"/>
        <location filename="../prefadvanced.cpp" line="519"/>
        <location filename="../prefadvanced.cpp" line="523"/>
        <location filename="../prefadvanced.cpp" line="527"/>
        <source>Example:</source>
        <translation>Пример:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="461"/>
        <source>Rebuilds index of files if no index was found, allowing seeking. Useful with broken/incomplete downloads, or badly created files. This option only works if the underlying media supports seeking (i.e. not with stdin, pipe, etc).&lt;br&gt; &lt;b&gt;Note:&lt;/b&gt; the creation of the index may take some time.</source>
        <translation>Перестраивает индекс в файлах, в которых индекс не найден, позволяя перематывать их. Полезно для недогруженных/неполных или плохо созданных файлов. Параметр работает, только если мультимедиа поддерживает перемотку (т.е. не с stdin, pipe, и пр.). &lt;br&gt; &lt;b&gt;Примечание:&lt;/b&gt; создание индекса может занять некоторое время.</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="128"/>
        <source>C&amp;orrect PTS:</source>
        <translation>Корректировать &amp;метки времени:</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="559"/>
        <source>&amp;Verbose</source>
        <translation>&amp;Подробный журнал</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="575"/>
        <source>Save SMPlayer log to file</source>
        <translation>Сохранять журнал SMPlayer в файл</translation>
    </message>
    <message>
        <location filename="../prefadvanced.cpp" line="576"/>
        <source>If this option is checked, the SMPlayer log wil be recorded to %1</source>
        <translation>Если этот параметр отмечен, журнал SMPlayer будет записан в %1</translation>
    </message>
    <message>
        <location filename="../prefadvanced.ui" line="624"/>
        <source>Sa&amp;ve SMPlayer log to a file</source>
        <translation>&amp;Сохранять журнал SMPlayer в файл</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="204"/>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="205"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Не все файлы могут быть ассоциированы. Проверьте свои права и попытайтесь снова.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="215"/>
        <source>File Types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="232"/>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="233"/>
        <source>Check all file types in the list</source>
        <translation>Выбрать все типы файлов в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="236"/>
        <source>Uncheck all file types in the list</source>
        <translation>Ничего не выбирать в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="238"/>
        <source>List of file types</source>
        <translation>Список типов файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="242"/>
        <source>Note:</source>
        <translation>Примечание:</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="243"/>
        <source>Restoration doesn&apos;t work on Windows Vista.</source>
        <translation>Восстановление ассоциаций не работает в Windows Vista.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="26"/>
        <source>File types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="38"/>
        <source>Media files handled by SMPlayer:</source>
        <translation>Ассоциированные с SMPlayer медиафайлы:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="91"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="98"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="239"/>
        <source>Check the media file extensions you would like SMPlayer to handle. When you click Apply, the checked files will be associated with SMPlayer. If you uncheck a media type, the file association will be restored.</source>
        <translation>Отметьте типы файлов, которые хотите связать с SMPlayer. По нажатии «Применить» отмеченные типы файлов будут ассоциированы с SMPlayer. Если убрать отметку, файловая ассоциация будет восстановлена.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="235"/>
        <source>Select none</source>
        <translation>Ничего не выбирать</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <location filename="../prefdrives.ui" line="27"/>
        <location filename="../prefdrives.cpp" line="73"/>
        <source>Drives</source>
        <translation>Устройства</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="219"/>
        <source>CD device</source>
        <translation>CD-устройство</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="220"/>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation>Выберите CD-привод. Он будет использоваться для воспроизведения видео- и аудио-CD.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="223"/>
        <source>DVD device</source>
        <translation>DVD-устройство</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="224"/>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation>Выберите ваш DVD привод. Он будет использоваться для воспроизведения DVD.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="75"/>
        <source>Select your &amp;CD device:</source>
        <translation>Выберите ваше устрой&amp;ство CD:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="176"/>
        <source>Select your &amp;DVD device:</source>
        <translation>Выберите ваше устройст&amp;во DVD:</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="274"/>
        <source>Select your &amp;Blu-ray device:</source>
        <translation>Выбер&amp;ите ваше устройство Blu-ray: </translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="33"/>
        <source>SMPlayer does not choose any CDROM or DVD devices by default. So before you can actually play a CD or DVD you have to select the devices you want to use (they can be the same).</source>
        <translation>SMPlayer не выбирает устройства CDROM или DVD по умолчанию. Поэтому, чтобы воспроизводить CD или DVD, выберите устройства, которые вы хотите использовать (они могут быть одним и тем же устройством).</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="239"/>
        <source>Blu-ray device</source>
        <translation>Устройство Blu-ray</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="240"/>
        <source>Choose your Blu-ray device. It will be used to play Blu-ray discs.</source>
        <translation>Выберите ваш Blu-ray привод. Он будет использоваться для воспроизведения дисков Blu-ray.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="227"/>
        <source>Enable DVD menus</source>
        <translation>Включить DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="228"/>
        <source>If this option is checked, SMPlayer will play DVDs using dvdnav. Requires a version of MPlayer with dvdnav support.</source>
        <translation>Если этот параметр отмечен, SMPlayer будет проигрывать DVD с помощью dvdnav. Требуется версия MPlayer, скомпилированная с поддержкой dvdnav.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="231"/>
        <source>&lt;b&gt;Note 1&lt;/b&gt;: cache will be disabled, this can affect performance.</source>
        <translation>&lt;b&gt;Примечание 1&lt;/b&gt;: кэш будет отключён, это может повлиять на производительность.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="232"/>
        <source>&lt;b&gt;Note 2&lt;/b&gt;: you may want to assign the action &quot;activate option in DVD menus&quot; to one of the mouse buttons.</source>
        <translation>&lt;b&gt;Примечание 2&lt;/b&gt;: вы можете захотеть привязать действие &quot;параметр активации в DVD-меню&quot; к одной из двух кнопок мыши.</translation>
    </message>
    <message>
        <location filename="../prefdrives.cpp" line="234"/>
        <source>&lt;b&gt;Note 3&lt;/b&gt;: this feature is under development, expect a lot of issues with it.</source>
        <translation>&lt;b&gt;Примечание 3&lt;/b&gt;: эта особенность находится в разработке, возможны различные проблемы при её использовании.</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="225"/>
        <source>&amp;Enable DVD menus (experimental)</source>
        <translation>&amp;Включить DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefdrives.ui" line="119"/>
        <source>&amp;Scan for CD/DVD drives</source>
        <translation>Про&amp;верить наличие CD/DVD-приводов</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="153"/>
        <location filename="../prefgeneral.cpp" line="1077"/>
        <source>General</source>
        <translation>Основные</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="27"/>
        <source>&amp;General</source>
        <translation>&amp;Основные</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="76"/>
        <source>Media settings</source>
        <translation>Настройки мультимедиа</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1220"/>
        <source>Start videos in fullscreen</source>
        <translation>Открывать видео на весь экран</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1251"/>
        <source>Disable screensaver</source>
        <translation>Подавить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="176"/>
        <source>7 (6.1 Surround)</source>
        <translation>7 (6.1 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="177"/>
        <source>8 (7.1 Surround)</source>
        <translation>8 (7.1 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="205"/>
        <source>Select the %1 executable</source>
        <translation>Выбрать исполняемый файл %1</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="207"/>
        <source>Executables</source>
        <translation>Исполняемые файлы</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="209"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="211"/>
        <source>Select a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="222"/>
        <source>%1 &amp;executable:</source>
        <translation>&amp;Исполняемый файл %1:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="172"/>
        <location filename="../prefgeneral.cpp" line="483"/>
        <location filename="../prefgeneral.cpp" line="484"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="214"/>
        <source>Here you can type your preferred language for the audio and subtitle streams. When a media with multiple audio or subtitle streams is found, SMPlayer will try to use your preferred language. This only will work with media that offer info about the language of audio and subtitle streams, like DVDs or mkv files.</source>
        <translation>Здесь можно указать предпочитаемый язык для аудио и субтитров. Если медиа содержит несколько потоков субтитров или аудио на разных языках, то SMPlayer выберет из них соответствующие вашим предпочтениям. Это верно для тех типов данных мультимедиа, которые содержат сведения о языке потоков аудио и субтитров, таких как DVD или mkv.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="491"/>
        <source>hardware</source>
        <translation>аппаратное</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="492"/>
        <source>software</source>
        <translation>программное</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1080"/>
        <source>Multimedia engine</source>
        <translation>Движок воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1081"/>
        <source>Select which multimedia engine you want to use, either MPlayer or mpv.</source>
        <translation>Выберите, какой мультимедийный движок вы хотите использовать или MPlayer, или mpv.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1082"/>
        <source>The option &apos;other&apos; allows you to manually select the path of the executable.</source>
        <translation>Параметр «Другой» позволяет вам вручную выбрать путь исполняемого файла.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1085"/>
        <source>%1 executable</source>
        <translation>Исполняемый файл %1</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1086"/>
        <source>Here you must specify the %1 executable that SMPlayer will use.</source>
        <translation>Здесь вы должны указать исполняемый файл %1, который будет использован в SMPlayer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1101"/>
        <source>Remember settings for streams</source>
        <translation>Запоминать настройки для потоков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1102"/>
        <source>When this option is enabled the settings for online streams will be remembered as well.</source>
        <translation>Если этот параметр включён, то настройки для онлайн-потоков будут запоминаться.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1117"/>
        <source>Screenshots folder</source>
        <translation>Каталог снимков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1123"/>
        <source>Template for screenshots</source>
        <translation>Шаблон имени снимков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1125"/>
        <source>For example %1 would save the screenshot as &apos;moviename_0001.png&apos;.</source>
        <translation>Например %1 сохранит снимок как &apos;имяфильма_0001.png&apos;.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1126"/>
        <source>%1 specifies the filename of the video without the extension, %2 adds a 4 digit number padded with zeros.</source>
        <translation>%1 указывает имя видеофайла без расширения, %2 добавляет четырёхзначный номер.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1136"/>
        <source>Format for screenshots</source>
        <translation>Формат снимков экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1137"/>
        <source>This option allows to choose the image file type used for saving screenshots.</source>
        <translation>Данный параметр позволяет выбрать тип графического файла для сохраняемых снимков.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1155"/>
        <source>If this option is enabled, the computer will shut down just after SMPlayer is closed.</source>
        <translation>Если этот параметр включён, компьютер будет выключаться сразу по закрытии SMPlayer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1161"/>
        <source>Video output driver</source>
        <translation>Драйвер вывода видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1162"/>
        <source>Select the video output driver.</source>
        <translation>Выберите драйвер вывода для видео.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1171"/>
        <source>Wayland support</source>
        <translation>Поддержка Wayland</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1172"/>
        <source>This activates some options to prevent the video being displayed outside the main window.</source>
        <translation>Активируются некоторые параметры, предотвращающие отображение видео за пределами главного окна.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1190"/>
        <source>If this option is enabled, black borders will be added to the image by default on new opened files.</source>
        <translation>Если этот параметр включён, то по умолчанию к изображению будут добавлены чёрные полосы в новые открытые файлы.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1260"/>
        <source>Audio output driver</source>
        <translation>Драйвер вывода звука</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1261"/>
        <source>Select the audio output driver.</source>
        <translation>Выберите драйвер вывода звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1091"/>
        <source>Remember settings</source>
        <translation>Запомнить настройки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1319"/>
        <source>Preferred audio language</source>
        <translation>Предпочитаемый язык звуковой дорожки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1331"/>
        <source>Preferred subtitle language</source>
        <translation>Предпочитаемый язык субтитров</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1198"/>
        <source>Software video equalizer</source>
        <translation>Программный видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="168"/>
        <source>Other...</source>
        <translation>Другой…</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1124"/>
        <source>This option specifies the filename template used to save screenshots.</source>
        <translation>Данный параметр указывает шаблон имени сохраняемых снимков.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1128"/>
        <source>For a full list of the template specifiers visit this link:</source>
        <translation>Полный список параметров шаблона представлен тут: </translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1132"/>
        <location filename="../prefgeneral.cpp" line="1139"/>
        <source>This option only works with mpv.</source>
        <translation>Этот параметр работает только с MPV.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1154"/>
        <source>Shut down computer</source>
        <translation>Выключить компьютер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1189"/>
        <source>Add black borders for subtitles by default</source>
        <translation>Добавлять чёрные полосы для субтитров по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1199"/>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation>Вы можете попробовать этот параметр, если видеоэквалайзер не поддерживается вашей видеокартой или выбранным драйвером вывода видео.&lt;br&gt;&lt;b&gt;Обратите внимание:&lt;/b&gt; этот параметр несовместим с некоторыми драйверами вывода видео.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1221"/>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation>Если этот параметр выбран, всё видео будет запускаться в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1266"/>
        <source>Global audio equalizer</source>
        <translation>Глобальный аудиоэквалайзер </translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1267"/>
        <source>If this option is checked, all media files share the audio equalizer.</source>
        <translation>Если эта опция выбрана, все медиафайлы будут использовать аудиоэквалайзер.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1268"/>
        <source>If it&apos;s not checked, the audio equalizer values are saved along each file and loaded back when the file is played later.</source>
        <translation>Если не выбрана, настройки аудиоэквалайзера будут сохранены вместе с каждым файлом и будут загружаться позже при каждом воспроизведении файла.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1271"/>
        <source>AC3/DTS passthrough over S/PDIF and HDMI</source>
        <translation>AC3/DTS через S/PDIF и HDMI</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1277"/>
        <source>Requests the number of playback channels. %1 asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Запрашивает количество каналов воспроизведения. %1 просит декодер декодировать звук в указанное количество каналов. Выполнение задачи ложится на плечи декодера. Обычно это требуется только при воспроизведении видео со звуком AC3 (например, DVD). В этом случае liba52 выполняет декодирование как обычно и корректно сводит аудио в запрошенное количество каналов. &lt;b&gt;ПРИМЕЧАНИЕ&lt;/b&gt;: Эта опция учитывается кодеками (только AC3), фильтрами (окружение) и драйверами вывода звука (как минимум OSS).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1288"/>
        <source>Allows to change the playback speed without altering pitch.</source>
        <translation>Позволяет изменить скорость воспроизведения без изменения высоты тона.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1296"/>
        <source>Software volume control</source>
        <translation>Программное управление громкостью</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1297"/>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation>Выберите эту опцию для использования программного микшера вместо аппаратного.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1178"/>
        <source>Postprocessing quality</source>
        <translation>Качество постобработки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1179"/>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation>Динамическое изменение степени постобработки в зависимости от количества свободного процессорного времени. Указанное вами число будет соответствовать максимальному уровню.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1172"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Звук:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="82"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>За&amp;поминать настройки всех файлов (звуковая дорожка, субтитры…)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1191"/>
        <source>Su&amp;btitles:</source>
        <translation>Суб&amp;титры:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="455"/>
        <source>&amp;Quality:</source>
        <translation>Ка&amp;чество:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="35"/>
        <source>Multimedia &amp;engine:</source>
        <translation>Движок &amp;воспроизведения:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="163"/>
        <source>Re&amp;member settings for streams</source>
        <translation>За&amp;поминать настройки для потоков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="220"/>
        <source>Temp&amp;late:</source>
        <translation>Ша&amp;блон:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="240"/>
        <source>F&amp;ormat:</source>
        <translation>Ф&amp;ормат:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="308"/>
        <source>S&amp;hut down computer</source>
        <translation>Вы&amp;ключить компьютер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="407"/>
        <source>Wa&amp;yland support</source>
        <translation>Поддер&amp;жка Wayland</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="627"/>
        <source>Start videos in &amp;fullscreen</source>
        <translation>Запускать видео на весь экр&amp;ан</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="641"/>
        <source>Disable &amp;screensaver</source>
        <translation>Подавить &amp;хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="775"/>
        <source>Global audio e&amp;qualizer</source>
        <translation>Глобальный аудиоэ&amp;квалайзер </translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="784"/>
        <source>&amp;AC3/DTS passthrough over S/PDIF and HDMI</source>
        <translation>AC3/DTS &amp;через S/PDIF и HDMI</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="894"/>
        <source>Use s&amp;oftware volume control</source>
        <translation>Програ&amp;ммное управление громкостью</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="917"/>
        <source>Ma&amp;x. Amplification:</source>
        <translation>Ма&amp;кс. усиление:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1204"/>
        <source>Direct rendering</source>
        <translation>Прямой рендеринг</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1209"/>
        <source>Double buffering</source>
        <translation>Двойная буферизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="593"/>
        <source>D&amp;irect rendering</source>
        <translation>Прямой рен&amp;деринг</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="600"/>
        <source>Dou&amp;ble buffering</source>
        <translation>Двойная &amp;буферизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1210"/>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation>Двойная буферизация исправляет мерцание кадров благодаря тому, что в память загружается два кадра, и при отображении одного обрабатывается следующий. Отключение этого параметра может негативно сказаться на экранном меню, но чаще избавляет его от мерцания.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="435"/>
        <source>&amp;Enable postprocessing by default</source>
        <translation>Разрешить &amp;постобработку по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="945"/>
        <source>Volume &amp;normalization by default</source>
        <translation>&amp;Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1149"/>
        <source>Close when finished</source>
        <translation>Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1150"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Если выбрано, то главное окно будет автоматически закрыто по окончании воспроизведения файла или плейлиста.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="173"/>
        <source>2 (Stereo)</source>
        <translation>2 (Стерео)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="174"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="175"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="799"/>
        <source>C&amp;hannels by default:</source>
        <translation>Каналы по &amp;умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="269"/>
        <source>&amp;Pause when minimized</source>
        <translation>Пауза при &amp;минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1144"/>
        <source>Pause when minimized</source>
        <translation>Пауза при минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1175"/>
        <source>Enable postprocessing by default</source>
        <translation>Включить постобработку по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1300"/>
        <source>Max. Amplification</source>
        <translation>Макс. усиление</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1307"/>
        <source>Volume normalization by default</source>
        <translation>Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1308"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Увеличивает громкость без искажений звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1276"/>
        <source>Channels by default</source>
        <translation>Каналы по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1301"/>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation>Устанавливает максимальное усиление в процентах (по умолчанию 110). Значение 200 увеличит громкость до уровня, превышающего текущий вдвое. При значениях ниже 100 начальная громкость (100%) будет выше максимума, т.е. экранное меню будет показывать неверную информацию.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1176"/>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation>Постобработка будет использована для новых открытых файлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1321"/>
        <source>You can specify here a priority list of audio language codes, separated by commas. For example: spa,eng,jpn</source>
        <translation>Вы можете указать приоритет языка звуковых дорожек, разделяя их запятыми: Например: rus,eng,jpn</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1325"/>
        <source>This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Это поле принимает регулярные выражения. Например: &lt;b&gt;ru|rus|russian&lt;/b&gt; означает, что будут выбраны аудиодорожки, содержащие в названии языка &lt;i&gt;ru&lt;/i&gt;, &lt;i&gt;rus&lt;/i&gt; или &lt;i&gt;russian.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1333"/>
        <source>You can specify here a priority list of subtitle language codes, separated by commas. For example: spa,eng,jpn</source>
        <translation>Вы можете указать приоритет языка субтитров, разделяя их запятыми: Например: rus,eng,jpn</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1336"/>
        <source>This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Это поле принимает регулярные выражения. Например: &lt;b&gt;ru|rus|russian&lt;/b&gt; означает, что будут выбраны субтитры, содержащие в названии языка &lt;i&gt;ru&lt;/i&gt;, &lt;i&gt;rus&lt;/i&gt; или &lt;i&gt;russian&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1343"/>
        <source>Audio track</source>
        <translation>Звуковая дорожка</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1344"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Указывает аудиодорожку по умолчанию, используемую для новых файлов. Если дорожка не существует, будет использована первая. &lt;br&gt;&lt;b&gt;Примечание:&lt;/b&gt; параметр &lt;i&gt;предпочитаемый язык&lt;/i&gt; более приоритетен.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1349"/>
        <source>Subtitle track</source>
        <translation>Дорожка субтитров</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1350"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Указывает дорожку субтитров по умолчанию, используемую по умолчанию для новых файлов. Если дорожка не существует, будет использована первая. &lt;br&gt;&lt;b&gt;Примечание:&lt;/b&gt; опция &lt;i&gt;Предпочитаемый язык субтитров&lt;/i&gt; более приоритетна.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1312"/>
        <source>Or choose a track number:</source>
        <translation>Либо использовать номер дорожки:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1253"/>
        <source>Audi&amp;o:</source>
        <translation>Ауди&amp;о:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1207"/>
        <source>Preferred language:</source>
        <translation>Предпочитаемый язык:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1096"/>
        <source>Preferre&amp;d audio and subtitles</source>
        <translation>&amp;Языковая дорожка и субтитры</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1266"/>
        <source>&amp;Subtitle:</source>
        <translation>Су&amp;бтитры:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="835"/>
        <source>High speed &amp;playback without altering pitch</source>
        <translation>Скоростное воспрои&amp;зведение без смены высоты тона</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1287"/>
        <source>High speed playback without altering pitch</source>
        <translation>Скоростное воспроизведение без смены высоты тона</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="348"/>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="523"/>
        <source>Add blac&amp;k borders for subtitles by default</source>
        <translation>Добавить &amp;чёрные полосы для субтитров по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="586"/>
        <source>Use s&amp;oftware video equalizer</source>
        <translation>Использовать программный видео&amp;эквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="685"/>
        <source>A&amp;udio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="870"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1159"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1258"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1317"/>
        <source>Preferred audio and subtitles</source>
        <translation>Предпочитаемые звуковая дорожка и субтитры</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="181"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="182"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="183"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (обычный)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="184"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (удвоенная частота)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="185"/>
        <source>Linear Blend</source>
        <translation>Линейное смешивание</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="186"/>
        <source>Kerndeint</source>
        <translation>Адаптивное (kerndeint)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1183"/>
        <source>Deinterlace by default</source>
        <translation>Стандартное устранение чересстрочности</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1184"/>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation>Выберите фильтр устранения чересстрочности, который вы хотите использовать по умолчанию для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1096"/>
        <source>Remember time position</source>
        <translation>Запоминать позицию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="116"/>
        <source>Remember &amp;time position</source>
        <translation>Запоминать п&amp;озицию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1263"/>
        <source>Enable the audio equalizer</source>
        <translation>Включить аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1264"/>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation>Отметьте эту опцию, если хотите использовать аудиоэквалайзер.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="752"/>
        <source>&amp;Enable the audio equalizer</source>
        <translation>Включить &amp;аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1214"/>
        <source>Draw video using slices</source>
        <translation>Отрисовывать видео с использованием слоёв</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1215"/>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation>Включает/отключает отрисовку видео слоями/полосами высотой 16 пикселов, вместо отрисовки целого кадра за один проход. Может быть быстрее или медленнее в зависимости от видеокарты и доступного кэша. Полезно только с кодеками libmpeg2 и libavcodec.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="607"/>
        <source>Dra&amp;w video using slices</source>
        <translation>Ри&amp;совать видео с использованием слоёв</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="276"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="498"/>
        <source>fast</source>
        <translation>быстро</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="534"/>
        <location filename="../prefgeneral.cpp" line="586"/>
        <source>User defined...</source>
        <translation>Определено пользователем…</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1194"/>
        <source>Default zoom</source>
        <translation>Масштаб по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1195"/>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation>Эта опция устанавливает масштаб по умолчанию для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="532"/>
        <source>Default &amp;zoom:</source>
        <translation>&amp;Масштаб по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1088"/>
        <source>If this setting is wrong, SMPlayer won&apos;t be able to play anything!</source>
        <translation>Если эта опция указана неправильно, SMPlayer не сможет ничего воспроизвести!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1092"/>
        <source>Usually SMPlayer will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>По умолчанию SMPlayer запоминает настройки каждого воспроизводимого файла (звуковая дорожка, громкость, фильтры…). Отключите эту опцию, если она вам не нравится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1145"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Если этот параметр включён, воспроизведение файла будет приостановлено при минимизации главного окна. По восстановлении окна воспроизведение продолжится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1252"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Отметьте эту опцию, чтобы отключить хранитель экрана во время воспроизведения.&lt;br&gt; Он будет включён снова по окончании воспроизведения.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="356"/>
        <location filename="../prefgeneral.ui" line="693"/>
        <source>Ou&amp;tput driver:</source>
        <translation>Драй&amp;вер вывода:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1225"/>
        <source>Add black borders on fullscreen</source>
        <translation>Добавлять чёрные полосы в полноэкранном режиме</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1226"/>
        <source>If this option is enabled, black borders will be added to the image in fullscreen mode. This allows subtitles to be displayed on the black borders.</source>
        <translation>Если эта опция включена, в полноэкранном режиме к изображению будут добавлены чёрные полосы. Это позволяет отображать на них субтитры.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="634"/>
        <source>&amp;Add black borders on fullscreen</source>
        <translation>Добавлять &amp;чёрные полосы в полноэкранном режиме</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="191"/>
        <source>one ini file</source>
        <translation>один общий файл .ini</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="192"/>
        <source>multiple ini files</source>
        <translation>отдельные файлы .ini</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1104"/>
        <source>Method to store the file settings</source>
        <translation>Метод сохранения настроек файлов</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1105"/>
        <source>This option allows to change the way the file settings would be stored. The following options are available:</source>
        <translation>Этот параметр позволяет изменить способ сохранения настроек файлов. Доступны следующие варианты:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1107"/>
        <source>&lt;b&gt;one ini file&lt;/b&gt;: the settings for all played files will be saved in a single ini file (%1)</source>
        <translation>&lt;b&gt;один общий файл .ini&lt;/b&gt;: настройки для всех воспроизводимых файлов будут сохраняться в одном общем файле .ini (%1)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1111"/>
        <source>The latter method could be faster if there is info for a lot of files.</source>
        <translation>Последний метод может быть быстрее, если уже сохранены настройки большого количества файлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="128"/>
        <source>&amp;Store settings in</source>
        <translation>Со&amp;хранять настройки в</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1109"/>
        <source>&lt;b&gt;multiple ini files&lt;/b&gt;: one ini file will be used for each played file. Those ini files will be saved in the folder %1</source>
        <translation>&lt;b&gt;отдельные файлы .ini&lt;/b&gt;: для каждого воспроизводимого файла будет использоваться свой файл .ini. Все файлы .ini будут сохранены в каталог %1</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1097"/>
        <source>If you check this option, SMPlayer will remember the last position of the file when you open it again. This option works only with regular files (not with DVDs, CDs, URLs...).</source>
        <translation>Если вы отметите эту опцию, SMPlayer будет запоминать последнюю позицию файла, когда вы снова его откроете. Эта опция работает только с обычными файлами (не с DVD, CD или сетевыми адресами…).</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1205"/>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation>Если выбрано – включается прямой рендеринг (поддерживается не всеми кодеками и модулями видеовывода)&lt;br&gt;&lt;b&gt;ВНИМАНИЕ:&lt;/b&gt; Могут возникнуть проблемы с экранным меню / субтитрами!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1113"/>
        <source>Enable screenshots</source>
        <translation>Включить снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1114"/>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation>Вы можете использовать эту опцию для того, чтобы включить или отключить создание снимков экрана.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1118"/>
        <source>Here you can specify a folder where the screenshots taken by SMPlayer will be stored. If the folder is not valid the screenshot feature will be disabled.</source>
        <translation>Здесь можно указать каталог, куда будут сохраняться снимки экрана, сделанные с помощью SMPlayer. Если каталог не указан, возможность создания снимков будет отключена.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="175"/>
        <source>Screenshots</source>
        <translation>Снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="181"/>
        <source>&amp;Enable screenshots</source>
        <translation>&amp;Включить снимки экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <source>&amp;Folder:</source>
        <translation>&amp;Каталог:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1290"/>
        <source>Global volume</source>
        <translation>Общая громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1291"/>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation>При включении этой опции будет использоваться общая громкость для всех файлов. Если опция отключена, для каждого файла будет использована своя громкость.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1294"/>
        <source>This option also applies for the mute control.</source>
        <translation>Эта опция также применяется для приглушения звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="879"/>
        <source>Glo&amp;bal volume</source>
        <translation>О&amp;бщая громкость</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1236"/>
        <source>Switch screensaver off</source>
        <translation>Отключить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1237"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation>Эта опция отключает хранитель экрана перед началом воспроизведения файла и включает его по окончании воспроизведения. Если эта опция задействована, хранитель экрана не будет появляться даже при воспроизведении аудиофайлов или когда воспроизведение приостановлено.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1243"/>
        <source>Avoid screensaver</source>
        <translation>Предотвращать хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1244"/>
        <source>When this option is checked, SMPlayer will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the SMPlayer window is in the foreground.</source>
        <translation>Если эта опция отмечена, SMPlayer попытается предотвратить появление хранителя экрана во время воспроизведения видеофайла. Скринсейвер разрешён только при воспроизведении аудиофайлов или в режиме паузы. Эта опция работает, только если окно SMPlayer активно.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="648"/>
        <source>Screensaver</source>
        <translation>Хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="654"/>
        <source>Swit&amp;ch screensaver off</source>
        <translation>&amp;Отключить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="661"/>
        <source>Avoid &amp;screensaver</source>
        <translation>Пре&amp;дотвратить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1310"/>
        <source>Audio/video auto synchronization</source>
        <translation>Автосинхронизация аудио/видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1311"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Плавно подстраивает синхронизацию аудио/видео за счёт измерений задержки звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1314"/>
        <source>A-V sync correction</source>
        <translation>Коррекция A/V-синхронизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1315"/>
        <source>Maximum A-V sync correction per frame (in seconds)</source>
        <translation>Максимальная коррекция A/V-синхронизации на фрейм (в секундах)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="955"/>
        <source>Synchronization</source>
        <translation>Синхронизация</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="966"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Автоматическая син&amp;хронизация аудио/видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="992"/>
        <source>&amp;Factor:</source>
        <translation>&amp;Фактор:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1028"/>
        <source>A-V sync &amp;correction</source>
        <translation>Ко&amp;ррекция A/V-синхронизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="1051"/>
        <source>&amp;Max. correction:</source>
        <translation>Макс. коррек&amp;ция:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1186"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; This option won&apos;t be used for TV channels.</source>
        <translation>&lt;b&gt;Внимание:&lt;/b&gt; Эта опция не будет использоваться для ТВ-каналов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="488"/>
        <source>Dei&amp;nterlace by default (except for TV):</source>
        <translation>&amp;Устранение чересстрочности по умолчанию (кроме ТВ):</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1272"/>
        <source>Uses hardware AC3 passthrough.</source>
        <translation>Использовать аппаратную передачу AC3.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="1273"/>
        <source>&lt;b&gt;Note:&lt;/b&gt; none of the audio filters will be used when this option is enabled.</source>
        <translation>&lt;b&gt;Примечание:&lt;/b&gt; аудиофильтры не будут задействованы при включении этого параметра.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="499"/>
        <source>snap mode</source>
        <translation>режим снимков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="500"/>
        <source>slower dive mode</source>
        <translation>режим медленных скачков</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="385"/>
        <source>Configu&amp;re...</source>
        <translation>&amp;Настройка…</translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <location filename="../prefinput.cpp" line="52"/>
        <source>Keyboard and mouse</source>
        <translation>Клавиатура и мышь</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="24"/>
        <source>&amp;Keyboard</source>
        <translation>&amp;Клавиатура</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="84"/>
        <source>&amp;Use the multimedia keys as global shortcuts</source>
        <translation>&amp;Использовать мультимедийные клавиши как глобальные</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="107"/>
        <source>Select &amp;keys...</source>
        <translation>Выбрать клавиши…</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="117"/>
        <source>&amp;Mouse</source>
        <translation>&amp;Мышь</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="167"/>
        <source>Button functions:</source>
        <translation>Функции кнопок:</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="364"/>
        <source>Dra&amp;g function:</source>
        <translation>Функция &amp;перетаскивания:</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="406"/>
        <source>Don&apos;t &amp;trigger the left click action with a double click</source>
        <translation>&amp;Отключить действие левой кнопки мыши при двойном щелчке</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="161"/>
        <location filename="../prefinput.cpp" line="438"/>
        <source>Media seeking</source>
        <translation>Перемотка медиа</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="162"/>
        <location filename="../prefinput.cpp" line="441"/>
        <source>Volume control</source>
        <translation>Регулятор громкости</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="163"/>
        <location filename="../prefinput.cpp" line="444"/>
        <source>Zoom video</source>
        <translation>Масштаб видео</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="67"/>
        <location filename="../prefinput.cpp" line="174"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="57"/>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Здесь можно изменить настройки горячих клавиш. Чтобы сделать это, дважды щёлкните мышкой или нажмите клавишу в необходимой ячейке. Вы можете сохранить список горячих клавиш, чтобы им могли воспользоваться другие люди или вы сами на другом компьютере.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="183"/>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation>Здесь можно изменить настройки горячих клавиш. Чтобы сделать это, дважды щёлкните мышкой или нажмите клавишу в необходимой ячейке. Вы можете сохранить список горячих клавиш, чтобы им могли воспользоваться другие люди или вы сами на другом компьютере.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="177"/>
        <source>&amp;Left click</source>
        <translation>&amp;Левый щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="200"/>
        <source>&amp;Double click</source>
        <translation>&amp;Двойной щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="321"/>
        <source>&amp;Wheel function:</source>
        <translation>&amp;Функция колеса:</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="380"/>
        <source>Shortcut editor</source>
        <translation>Редактор сочетаний клавиш</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="381"/>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation>Эта таблица позволяет изменить сочетания клавиш для различных действий. Двойной щелчок или нажатие ввода на выбранном пункте или нажатие кнопки &lt;b&gt;Изменить&lt;/b&gt; вызовет диалог &lt;i&gt;Изменить горячую клавишу&lt;/i&gt;. Есть два способа изменить сочетание клавиш: если кнопка &lt;b&gt;Захват&lt;/b&gt; нажата - просто нажать нужную комбинацию клавиш (работает не для всех клавиш). Если кнопка &lt;b&gt;Захват&lt;/b&gt; отжата, можно просто вписать полное название комбинации клавиш.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="399"/>
        <source>Left click</source>
        <translation>Левый щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="400"/>
        <source>Select the action for left click on the mouse.</source>
        <translation>Выбрать действие для левого щелчка мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="402"/>
        <source>Double click</source>
        <translation>Двойной щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="403"/>
        <source>Select the action for double click on the mouse.</source>
        <translation>Выбрать действие для двойного щелчка мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="414"/>
        <source>Wheel function</source>
        <translation>Функция колеса</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="415"/>
        <source>Select the action for the mouse wheel.</source>
        <translation>Выбрать действие для функции колеса.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="68"/>
        <source>Play</source>
        <translation>Воспроизведение</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="70"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="72"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="83"/>
        <source>Fullscreen</source>
        <translation>Полный экран</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="84"/>
        <source>Compact</source>
        <translation>Компактно</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="85"/>
        <source>Screenshot</source>
        <translation>Снимок экрана</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="89"/>
        <source>Mute</source>
        <translation>Приглушить звук</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="95"/>
        <source>Frame counter</source>
        <translation>Счётчик кадров</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="92"/>
        <source>Reset zoom</source>
        <translation>Сбросить масштаб</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="93"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из полного экрана</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="97"/>
        <source>Double size</source>
        <translation>Двойной размер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="69"/>
        <source>Play / Pause</source>
        <translation>Воспроизвести / Пауза</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="71"/>
        <source>Pause / Frame step</source>
        <translation>Пауза / покадровый просмотр</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="91"/>
        <source>Playlist</source>
        <translation>Плейлист</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="96"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="160"/>
        <source>No function</source>
        <translation>Нет функции</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="164"/>
        <location filename="../prefinput.cpp" line="447"/>
        <source>Change speed</source>
        <translation>Изменить скорость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="94"/>
        <source>Normal speed</source>
        <translation>Нормальная скорость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="378"/>
        <source>Keyboard</source>
        <translation>Клавиатура</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="397"/>
        <source>Mouse</source>
        <translation>Мышь</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="405"/>
        <source>Middle click</source>
        <translation>Средний щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="406"/>
        <source>Select the action for middle click on the mouse.</source>
        <translation>Выбрать действие для среднего щелчка мыши.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="246"/>
        <source>M&amp;iddle click</source>
        <translation>С&amp;редний щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="259"/>
        <source>X Button &amp;1</source>
        <translation>Доп. кнопка &amp;1</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="272"/>
        <source>X Button &amp;2</source>
        <translation>Доп. кнопка &amp;2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="73"/>
        <source>Go backward (short)</source>
        <translation>Назад (короткий интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="74"/>
        <source>Go backward (medium)</source>
        <translation>Назад (средний интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="75"/>
        <source>Go backward (long)</source>
        <translation>Назад (длинный интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="76"/>
        <source>Go forward (short)</source>
        <translation>Вперёд (короткий интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="77"/>
        <source>Go forward (medium)</source>
        <translation>Вперёд (средний интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="78"/>
        <source>Go forward (long)</source>
        <translation>Вперёд (длинный интервал)</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="90"/>
        <source>OSD - Next level</source>
        <translation>Экранное меню – след. уровень</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="102"/>
        <source>Show context menu</source>
        <translation>Показать контекстное меню</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="223"/>
        <source>&amp;Right click</source>
        <translation>&amp;Правый щелчок</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="79"/>
        <source>Increase volume</source>
        <translation>Увеличить громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="80"/>
        <source>Decrease volume</source>
        <translation>Уменьшить громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="408"/>
        <source>X Button 1</source>
        <translation>Доп. кнопка 1</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="409"/>
        <source>Select the action for the X button 1.</source>
        <translation>Выбрать действие для доп. кнопки 1.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="411"/>
        <source>X Button 2</source>
        <translation>Доп. кнопка 2</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="412"/>
        <source>Select the action for the X button 2.</source>
        <translation>Выбрать действие для доп. кнопки 1.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="100"/>
        <source>Show video equalizer</source>
        <translation>Показать видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="101"/>
        <source>Show audio equalizer</source>
        <translation>Показать аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="86"/>
        <source>Always on top</source>
        <translation>Всегда</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="81"/>
        <source>Play next</source>
        <translation>Воспроизвести следующий</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="82"/>
        <source>Play previous</source>
        <translation>Воспроизвести предыдущий</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="87"/>
        <source>Never on top</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="88"/>
        <source>On top while playing</source>
        <translation>Поверх окон при проигрывании</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="98"/>
        <source>Next chapter</source>
        <translation>Следующий раздел</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="99"/>
        <source>Previous chapter</source>
        <translation>Предыдущий раздел</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="105"/>
        <source>Activate option under mouse in DVD menus</source>
        <translation>Активировать опцию под мышью в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="106"/>
        <source>Return to main DVD menu</source>
        <translation>Вернуться к главному DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="107"/>
        <source>Return to previous menu in DVD menus</source>
        <translation>Вернуться к предыдущему DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="108"/>
        <source>Move cursor up in DVD menus</source>
        <translation>Передвинуть курсор вверх в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="109"/>
        <source>Move cursor down in DVD menus</source>
        <translation>Передвинуть курсор вниз в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="110"/>
        <source>Move cursor left in DVD menus</source>
        <translation>Передвинуть курсор влево в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="111"/>
        <source>Move cursor right in DVD menus</source>
        <translation>Передвинуть курсор вправо в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="112"/>
        <source>Activate highlighted option in DVD menus</source>
        <translation>Активировать подсвеченный пункт в DVD-меню</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="175"/>
        <location filename="../prefinput.cpp" line="419"/>
        <source>Move window</source>
        <translation>Переместить окно</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="177"/>
        <location filename="../prefinput.cpp" line="421"/>
        <source>Seek and volume</source>
        <translation>Перемотка и громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="392"/>
        <source>Use the multimedia keys as global shortcuts</source>
        <translation>Использовать мультимедийные клавиши как глобальные</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="393"/>
        <source>When this option is enabled the multimedia keys (Play, Stop, Volume+/-, Mute, etc.) will work even when SMPlayer is running in the background.</source>
        <translation>Когда выбрана эта опция, мультимедийные клавиши (Воспроизведение, Стоп, Громкость+/-, Тишина и т. д.) будут работать даже когда SMPlayer работает в фоне.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="417"/>
        <source>Drag function</source>
        <translation>Функция перетаскивания</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="418"/>
        <source>This option controls what to do when the mouse is moved while pressing the left button.</source>
        <translation>Эта опция контролирует, что делать, когда мышь перемещена при нажатой левой кнопке.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="419"/>
        <source>the main window is moved</source>
        <translation>главное окно перемещено</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="422"/>
        <source>a horizontal movement changes the time position while a vertical movement changes the volume</source>
        <translation>горизонтальное перемещение изменяет позицию времени, а вертикальное перемещение изменяет громкость</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="426"/>
        <source>Don&apos;t trigger the left click function with a double click</source>
        <translation>Отключить действие левой кнопки мыши при двойном щелчке</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="427"/>
        <source>If this option is enabled when you double click on the video area only the double click function will be triggered. The left click action won&apos;t be activated.</source>
        <translation>Если эта опция включена, после двойного щелчка по области видео выполнится только функция двойного щелчка, иначе будет выполняться также функция левой клавиши.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="430"/>
        <source>By enabling this option the left click is delayed %1 milliseconds because it&apos;s necessary to wait that time to know if there&apos;s a double click or not.</source>
        <translation>При включении этого параметра срабатывание левой клавиши мыши задерживается на %1 миллисекунд, так как оно необходимо для определения двойного щелчка.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="103"/>
        <source>Change function of wheel</source>
        <translation>Сменить функцию колеса</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="459"/>
        <location filename="../prefinput.cpp" line="167"/>
        <source>Media &amp;seeking</source>
        <translation>&amp;Перемотка файла</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="473"/>
        <location filename="../prefinput.cpp" line="168"/>
        <source>&amp;Zoom video</source>
        <translation>&amp;Масштаб видео</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="466"/>
        <location filename="../prefinput.cpp" line="169"/>
        <source>&amp;Volume control</source>
        <translation>Регулировка &amp;громкости</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="480"/>
        <location filename="../prefinput.cpp" line="170"/>
        <source>&amp;Change speed</source>
        <translation>&amp;Скорость воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="436"/>
        <source>Mouse wheel functions</source>
        <translation>Функции колеса мыши</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="439"/>
        <source>Check it to enable seeking as one function.</source>
        <translation>Выберите, чтобы задействовать функцию перемотки.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="442"/>
        <source>Check it to enable changing volume as one function.</source>
        <translation>Выберите, чтобы задействовать функцию регулировки громкости</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="445"/>
        <source>Check it to enable zooming as one function.</source>
        <translation>Выберите, чтобы задействовать функцию масштаба.</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="448"/>
        <source>Check it to enable changing speed as one function.</source>
        <translation>Выберите, чтобы задействовать функцию регулировки скорости воспроизведения.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="437"/>
        <source>M&amp;ouse wheel functions</source>
        <translation>Функции &amp;колеса мыши</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="449"/>
        <source>Select the actions that should be cycled through when using the &quot;Change function of wheel&quot; option.</source>
        <translation>Выберите действия, которые будут циклически переключаться при использовании опции «Сменить функцию колеса».</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="433"/>
        <source>Reverse mouse wheel seeking</source>
        <translation>Обратить направление перемотки колесом мыши</translation>
    </message>
    <message>
        <location filename="../prefinput.cpp" line="434"/>
        <source>Check it to seek in the opposite direction.</source>
        <translation>Выберите это для противоположного направления.</translation>
    </message>
    <message>
        <location filename="../prefinput.ui" line="413"/>
        <source>R&amp;everse wheel media seeking</source>
        <translation>Инв&amp;ертировать направление перемотки</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <location filename="../prefinterface.cpp" line="158"/>
        <location filename="../prefinterface.cpp" line="740"/>
        <source>Interface</source>
        <translation>Интерфейс</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="228"/>
        <location filename="../prefinterface.cpp" line="232"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="27"/>
        <source>&amp;Interface</source>
        <translation>&amp;Интерфейс</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="58"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="63"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Когда это нужно</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="68"/>
        <source>Only after loading a new video</source>
        <translation>Только для нового видео</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="830"/>
        <source>Privac&amp;y</source>
        <translation>П&amp;риватность</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="836"/>
        <location filename="../prefinterface.cpp" line="879"/>
        <source>Recent files</source>
        <translation>Недавние файлы</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="760"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="761"/>
        <source>Here you can change the language of the application.</source>
        <translation>Здесь можно изменить язык приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="202"/>
        <source>&amp;Short jump</source>
        <translation>&amp;Короткий интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="173"/>
        <source>System language</source>
        <translation>Язык системы</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="203"/>
        <source>&amp;Medium jump</source>
        <translation>&amp;Средний интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="204"/>
        <source>&amp;Long jump</source>
        <translation>&amp;Длинный интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="205"/>
        <source>Mouse &amp;wheel jump</source>
        <translation>Интервал при перемотке мы&amp;шью</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="636"/>
        <source>&amp;Use only one running instance of SMPlayer</source>
        <translation>Запускать только о&amp;дну копию SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="848"/>
        <source>Ma&amp;x. items</source>
        <translation>&amp;Максимум пунктов</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="338"/>
        <source>St&amp;yle:</source>
        <translation>&amp;Стиль:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="242"/>
        <source>Ico&amp;n set:</source>
        <translation>Набор &amp;значков:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="173"/>
        <source>L&amp;anguage:</source>
        <translation>&amp;Язык:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="33"/>
        <source>Main window</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="41"/>
        <source>Auto&amp;resize:</source>
        <translation>Автоматический &amp;размер:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="112"/>
        <source>&amp;Prevent window to get outside of screen</source>
        <translation>&amp;Предотвращать попадание окна за пределы экрана</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="134"/>
        <source>Center &amp;window</source>
        <translation>Центрировать &amp;окно</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="141"/>
        <source>R&amp;emember position and size</source>
        <translation>Запоминать пози&amp;цию и размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="290"/>
        <source>S&amp;kin:</source>
        <translation>С&amp;кин:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="397"/>
        <source>Default font:</source>
        <translation>Стандартный шрифт:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="411"/>
        <source>&amp;Change...</source>
        <translation>&amp;Изменить…</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="420"/>
        <source>Use the syste&amp;m native file dialog</source>
        <translation>Использовать систе&amp;мные файловые окна</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="506"/>
        <source>&amp;Behaviour of time slider:</source>
        <translation>&amp;Поведение полосы перемотки</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="523"/>
        <source>Seek to position while dragging</source>
        <translation>Переход при прокрутке</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="528"/>
        <source>Seek to position when released</source>
        <translation>Переход по отпуску</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="613"/>
        <source>Pressi&amp;ng the stop button once resets the time position</source>
        <translation>Однократное &amp;нажатие кнопки стоп сбрасывает позицию</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="678"/>
        <source>The floating control appears in fullscreen mode when the mouse is moved.</source>
        <translation>Плавающая панель управления появляется при перемещении мыши в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="765"/>
        <source>Show only when moving the mouse to the &amp;bottom of the screen</source>
        <translation>Показывать только при перемещении указателя мыши в&amp;низ экрана</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="781"/>
        <source>Tim&amp;e (in milliseconds) to hide the control:</source>
        <translation>&amp;Время (в миллисекундах) до скрытия панели:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="887"/>
        <source>URLs</source>
        <translation>Адреса</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="899"/>
        <source>&amp;Max. items</source>
        <translation>&amp;Максимум элементов</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="938"/>
        <source>&amp;Remember last directory</source>
        <translation>&amp;Запоминать последний каталог</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="959"/>
        <source>High &amp;DPI</source>
        <translation>Высокое &amp;разрешение</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="965"/>
        <source>SMPlayer can scale the interface in high DPI screens. Here you can disable this feature or change the scale factor.</source>
        <translation>SMPlayer может масштабировать интерфейс на высоких разрешениях. Здесь вы можете отключить эту опцию или изменить коэффициент масштабирования.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="975"/>
        <source>&amp;Enable support for high DPI screens</source>
        <translation>&amp;Включить поддержку для экранов высокого разрешения</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="985"/>
        <source>Scale</source>
        <translation>Масштаб</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="991"/>
        <source>A&amp;uto</source>
        <translation>А&amp;вто</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="1047"/>
        <source>Changes in this section requires to restart SMPlayer in order to take effect</source>
        <translation>Изменения в этой секции требуют перезапуска SMPlayer для вступления в силу</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="629"/>
        <source>TextLabel</source>
        <translation>Текстовая метка</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="441"/>
        <source>&amp;Seeking</source>
        <translation>&amp;Перемотка</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="563"/>
        <source>&amp;Absolute seeking</source>
        <translation>&amp;Абсолютное позиционирование</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="576"/>
        <source>&amp;Relative seeking</source>
        <translation>&amp;Относительное позиционирование</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="621"/>
        <source>Ins&amp;tances</source>
        <translation>&amp;Экземпляры</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="742"/>
        <source>Autoresize</source>
        <translation>Автоматический размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="743"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>Главное окно может изменять размер автоматически. Выберите подходящую настройку.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="753"/>
        <source>Remember position and size</source>
        <translation>Запоминать позицию и размер</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="754"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run SMPlayer again.</source>
        <translation>Если настройка выбрана, позиция и размер видео будут сохранены и восстановлены при следующем запуске SMPlayer.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="764"/>
        <source>Select the graphic interface you prefer for the application.</source>
        <translation>Выберите предпочитаемую графическую оболочку для приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="765"/>
        <source>The &lt;b&gt;Basic GUI&lt;/b&gt; provides the traditional interface, with the toolbar and control bar.</source>
        <translation>&lt;b&gt;Базовая оболочка&lt;/b&gt; предоставляет традиционный интерфейс с панелью инструментов и контрольной панелью.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="767"/>
        <source>The &lt;b&gt;Mini GUI&lt;/b&gt; provides a more simple interface, without toolbar and a control bar with few buttons.</source>
        <translation>&lt;b&gt;Мини-оболочка&lt;/b&gt; предоставляет более простой интерфейс без панели инструментов, но с контрольной панелью с несколькими кнопками.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="775"/>
        <source>The &lt;b&gt;Skinnable GUI&lt;/b&gt; provides an interface where several skins are available.</source>
        <translation>&lt;b&gt;Оболочка с обложками&lt;/b&gt; — это интерфейс с несколькими доступными обложками.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="771"/>
        <source>The &lt;b&gt;Mpc GUI&lt;/b&gt; looks like the interface in Media Player Classic.</source>
        <translation>&lt;b&gt;Оболочка MPC&lt;/b&gt; похожа на интерфейс Media Player Classic.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="877"/>
        <source>Privacy</source>
        <translation>Приватность</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="880"/>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation>Выберите максимум элементов в подменю &lt;b&gt;Открыть -&gt; Недавние файлы&lt;/b&gt;. При значении 0 меню не будет отображаться вообще.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="780"/>
        <source>Icon set</source>
        <translation>Набор значков</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="226"/>
        <source>Classic</source>
        <translation>Классика</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="238"/>
        <source>Basic GUI</source>
        <translation>Базовая оболочка</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="247"/>
        <source>Skinnable GUI</source>
        <translation>Оболочка с обложками</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="260"/>
        <source>Scale fact&amp;or:</source>
        <translation>Мас&amp;штабный коэффициент:</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="263"/>
        <source>Pixel rati&amp;o:</source>
        <translation>Соотношение пикс&amp;елей:</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="746"/>
        <source>Prevent window to get outside of screen</source>
        <translation>Предотвращать попадание окна за пределы экрана</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="747"/>
        <source>If after an autoresize the main window gets outside of the screen this option will center the window to prevent it.</source>
        <translation>Если после автоматической подстройки размера главное окно попадёт за пределы экрана, данная опция предотвратит это центрированием.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="750"/>
        <source>Center window</source>
        <translation>Центрировать окно</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="751"/>
        <source>When this option is enabled, the main window will be centered on the desktop.</source>
        <translation>Если выбрана эта опция, то главное окно будет центрироваться на рабочем столе.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="781"/>
        <source>Select the icon set you prefer for the application.</source>
        <translation>Выберите предпочитаемый для приложения набор значков.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="784"/>
        <source>Skin</source>
        <translation>Обложка</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="785"/>
        <source>Select the skin you prefer for the application. Only available with the skinnable GUI.</source>
        <translation>Выберите предпочитаемую обложку приложения. Доступно только для интерфейса с обложками.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="788"/>
        <source>Style</source>
        <translation>Стиль</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="789"/>
        <source>Select the style you prefer for the application.</source>
        <translation>Выберите предпочитаемый стиль приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="792"/>
        <source>Default font</source>
        <translation>Стандартный шрифт</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="793"/>
        <source>You can change here the application&apos;s font.</source>
        <translation>Здесь можно изменить шрифт приложения.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="795"/>
        <source>Use the system native file dialog</source>
        <translation>Использовать системные файловые окна</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="796"/>
        <source>When this option is enabled, SMPlayer will try to use the system native file dialog. Otherwise it will use the internal one.</source>
        <translation>Если эта опция включена, то SMPlayer попытается использовать системные окна для работы с файлами. Иначе будут использоваться встроенные.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="798"/>
        <source>Seeking</source>
        <translation>Поиск</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="800"/>
        <source>Short jump</source>
        <translation>Короткий интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="801"/>
        <location filename="../prefinterface.cpp" line="805"/>
        <location filename="../prefinterface.cpp" line="809"/>
        <source>Select the time that should be go forward or backward when you choose the %1 action.</source>
        <translation>Выберите время перемотки вперёд или назад при выборе действия %1.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="802"/>
        <source>short jump</source>
        <translation>короткий интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="804"/>
        <source>Medium jump</source>
        <translation>Средний интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="806"/>
        <source>medium jump</source>
        <translation>средний интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="808"/>
        <source>Long jump</source>
        <translation>Длинный интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="810"/>
        <source>long jump</source>
        <translation>длинный интервал</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="812"/>
        <source>Mouse wheel jump</source>
        <translation>Интервал перемотки колесом мыши</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="813"/>
        <source>Select the time that should be go forward or backward when you move the mouse wheel.</source>
        <translation>Выберите время перемотки вперёд или назад при вращении колеса мыши.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="816"/>
        <source>Behaviour of time slider</source>
        <translation>Поведение временной полосы прокрутки</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="817"/>
        <source>Select what to do when dragging the time slider.</source>
        <translation>Выберите поведение при перетаскивании ползунка прокрутки.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="829"/>
        <source>Note: this option only works when using mpv as multimedia engine.</source>
        <translation>Замечание: эта опция работает только при использовании движка воспроизведения MPV.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="831"/>
        <source>Pressing the stop button once resets the time position</source>
        <translation>Однократное нажатие кнопки стоп сбрасывает позицию</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="862"/>
        <source>Show only when moving the mouse to the bottom of the screen</source>
        <translation>Показывать только при перемещении указателя мыши вниз экрана</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="863"/>
        <source>If this option is checked, the floating control will only be displayed when the mouse is moved to the bottom of the screen. Otherwise the control will appear whenever the mouse is moved, no matter its position.</source>
        <translation>Если эта опция включена, плавающая панель будет показываться только когда мышь перемещена вниз экрана. Иначе панель будет появляться при любом движении мыши, независимо от её позиции.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="868"/>
        <source>If this option is enabled, the floating control will appear in compact mode too.</source>
        <translation>Если эта опция отмечена, плавающая панель управления будет появляться и в компактном режиме.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="870"/>
        <source>This option only works with the basic GUI.</source>
        <translation>Эта опция работает только с базовой оболочкой.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="871"/>
        <source>&lt;b&gt;Warning:&lt;/b&gt; the floating control has not been designed for compact mode and it might not work properly.</source>
        <translation>&lt;b&gt;Внимание:&lt;/b&gt; плавающая панель не была создана для компактного режима и может работать некорректно.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="874"/>
        <source>Time to hide the control</source>
        <translation>Время до скрытия панели</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="875"/>
        <source>Sets the time (in milliseconds) to hide the control after the mouse went away from the control.</source>
        <translation>Устанавливает время (в миллисекундах) до скрытия после выхода мыши за пределы панели.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="884"/>
        <source>Max. URLs</source>
        <translation>Макс. адресов</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="885"/>
        <source>Select the maximum number of items that the &lt;b&gt;Open-&gt;URL&lt;/b&gt; dialog will remember. Set it to 0 if you don&apos;t want any URL to be stored.</source>
        <translation>Выберите максимальное число элементов, запоминаемых в диалоге &lt;b&gt;Открыть -&gt; Адрес&lt;/b&gt;. Установите в 0, если не хотите сохранять адреса вообще.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="889"/>
        <source>Remember last directory</source>
        <translation>Запоминать последний каталог</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="890"/>
        <source>If this option is checked, SMPlayer will remember the last folder you use to open a file.</source>
        <translation>Если эта опция отмечена, SMPlayer будет запоминать каталог последнего открытого файла.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="551"/>
        <location filename="../prefinterface.cpp" line="820"/>
        <source>Seeking method</source>
        <translation>Способ позиционирования</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="821"/>
        <source>Sets the method to be used when seeking with the slider. Absolute seeking may be a little bit more accurate, while relative seeking may work better with files with a wrong length.</source>
        <translation>Установка метода, используемого при позиционировании ползунка перемотки. Абсолютное позиционирование более точное, но относительное может работать лучше с файлами с неправильной длительностью.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="832"/>
        <source>By default when the stop button is pressed the time position is remembered so if you press play button the media will resume at the same point. You need to press the stop button twice to reset the time position, but if this option is checked the time position will be set to 0 with only one press of the stop button.</source>
        <translation>По умолчанию при нажатии кнопки стопа временная позиция медиафайла запоминается, поэтому при нажатии кнопки воспроизведения, медиафайл продолжит воспроизводиться с того же места. Вы должны нажать кнопку стоп второй раз для сброса позиции, но эта опция, будучи установленной, установит временную позицию в 0 даже при однократном нажатии кнопки остановки.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="839"/>
        <source>Instances</source>
        <translation>Экземпляры</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="842"/>
        <source>Use only one running instance of SMPlayer</source>
        <translation>Использовать только одну копию SMPlayer</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="843"/>
        <source>Check this option if you want to use an already running instance of SMPlayer when opening other files.</source>
        <translation>Выберите эту опцию, если хотите использовать уже запущенную копию SMPlayer при открытии новых файлов.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="241"/>
        <source>Mini GUI</source>
        <translation>Мини-оболочка</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="763"/>
        <source>GUI</source>
        <translation>Оболочка</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="209"/>
        <source>&amp;GUI</source>
        <translation>&amp;Оболочка</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="847"/>
        <source>Floating control</source>
        <translation>Плавающая панель</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="849"/>
        <source>Animated</source>
        <translation>Анимировать</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="850"/>
        <source>If this option is enabled, the floating control will appear with an animation.</source>
        <translation>Если эта опция отмечена, плавающая панель управления будет появляться с анимацией.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="853"/>
        <source>Width</source>
        <translation>Ширина</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="854"/>
        <source>Specifies the width of the control (as a percentage).</source>
        <translation>Определяет ширину панели (в процентах).</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="856"/>
        <source>Margin</source>
        <translation>Отступ</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="857"/>
        <source>This option sets the number of pixels that the floating control will be away from the bottom of the screen. Useful when the screen is a TV, as the overscan might prevent the control to be visible.</source>
        <translation>Этот параметр указывает отступ плавающей панели от низа экрана в пикселах. Полезно, если экраном является телевизор, так как плавающая панель может быть скрыта вылетами развёртки.</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="867"/>
        <source>Display in compact mode too</source>
        <translation>Отображать также в компактном режиме</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="672"/>
        <source>&amp;Floating control</source>
        <translation>П&amp;лавающая панель</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="688"/>
        <source>&amp;Animated</source>
        <translation>&amp;Анимировать</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="697"/>
        <source>&amp;Width:</source>
        <translation>&amp;Ширина:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="723"/>
        <location filename="../prefinterface.ui" line="756"/>
        <location filename="../prefinterface.ui" line="1032"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="730"/>
        <source>&amp;Margin:</source>
        <translation>&amp;Отступ:</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="772"/>
        <source>Display in &amp;compact mode too</source>
        <translation>Отображать также в &amp;компактном режиме</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="244"/>
        <source>Mpc GUI</source>
        <translation>Оболочка MPC</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="757"/>
        <source>Hide video window when playing audio files</source>
        <translation>Прятать окно видео при воспроизведении аудиофайлов</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="758"/>
        <source>If this option is enabled the video window will be hidden when playing audio files.</source>
        <translation>Если этот параметр включён, окно видео будет спрятано при воспроизведении аудиофайлов.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="148"/>
        <source>&amp;Hide video window when playing audio files</source>
        <translation>&amp;Прятать окно видео при воспроизведении аудиофайлов</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="826"/>
        <source>Precise seeking</source>
        <translation>Точное позиционирование</translation>
    </message>
    <message>
        <location filename="../prefinterface.cpp" line="827"/>
        <source>If this option is enabled, seeks are more accurate but they can be a little bit slower. May not work with some video formats.</source>
        <translation>Если опция включена, перемотка будет более точной, но может быть немного медленнее. Может не работать с некоторыми форматами видео.</translation>
    </message>
    <message>
        <location filename="../prefinterface.ui" line="599"/>
        <source>&amp;Precise seeking</source>
        <translation>То&amp;чное позиционирование</translation>
    </message>
</context>
<context>
    <name>PrefNetwork</name>
    <message>
        <location filename="../prefnetwork.ui" line="24"/>
        <source>&amp;YouTube (and other sites)</source>
        <translation>&amp;YouTube (и другие сайты)</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="32"/>
        <source>Support for &amp;video sites:</source>
        <translation>Поддержка &amp;видеосайтов:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="89"/>
        <source>P&amp;referred quality:</source>
        <translation>Предпочитаемое &amp;качество:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="118"/>
        <source>Options for YouTube</source>
        <translation>Параметры YouTube</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="126"/>
        <source>Playback &amp;quality:</source>
        <translation>Качество &amp;воспроизведения:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="154"/>
        <source>Use a&amp;daptive streams (resolution up to 4K)</source>
        <translation>Использовать &amp;адаптивные потоки (разрешение до 4K)</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="188"/>
        <source>Use &amp;60 fps if available</source>
        <translation>Использовать &amp;60 к/с по возможности</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="209"/>
        <source>&amp;User agent:</source>
        <translation>&amp;Агент пользователя:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="227"/>
        <source>YouTube support application</source>
        <translation>Приложение поддержки YouTube</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="253"/>
        <source>C&amp;hromecast</source>
        <translation>C&amp;hromecast</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="259"/>
        <source>Web Server</source>
        <translation>Веб-сервер</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="271"/>
        <source>Changes in this section will be applied the next time the web server is restarted</source>
        <translation>Изменения в этом разделе будут применены в следующий раз при перезагрузке веб-сервера</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="291"/>
        <source>&amp;Directory listing</source>
        <translation>Перечень &amp;каталогов</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="298"/>
        <source>Local &amp;IP:</source>
        <translation>Локальный &amp;IP:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="344"/>
        <source>In order to serve local media from this computer to Chromecast, SMPlayer will run a tiny web server. You can adjust here some of the settings.</source>
        <translation>Для того, чтобы обслуживать локальное медиа с этого компьютера на Chromecast, SMPlayer запустит крошечный веб-сервер. Вы можете настроить здесь некоторые его параметры.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="371"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="377"/>
        <source>Convert SRT subtitles to &amp;VTT</source>
        <translation>Конвертировать субтитры SRT в &amp;VTT</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="409"/>
        <source>&amp;Overwrite existing VTT files</source>
        <translation>&amp;Перезаписать существующие VTT файлы</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="416"/>
        <source>Try to &amp;remove advertisements</source>
        <translation>Пытаться &amp;удалить рекламу</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="425"/>
        <source>Position of &amp;subtitles on screen:</source>
        <translation>Положение &amp;субтитров на экране:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="480"/>
        <source>&amp;Proxy</source>
        <translation>&amp;Прокси</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="486"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Включить прокси</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="499"/>
        <source>&amp;Host:</source>
        <translation>&amp;Хост:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="321"/>
        <location filename="../prefnetwork.ui" line="512"/>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="200"/>
        <source>Allow AV&amp;1 codec</source>
        <translation>Разрешить кодек AV&amp;1</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="532"/>
        <source>&amp;Username:</source>
        <translation>&amp;Имя пользователя:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="545"/>
        <source>Pa&amp;ssword:</source>
        <translation>Па&amp;роль:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.ui" line="562"/>
        <source>&amp;Type:</source>
        <translation>&amp;Тип:</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="40"/>
        <source>HTTP</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="41"/>
        <source>SOCKS5</source>
        <translation>SOCKS5</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="80"/>
        <source>Network</source>
        <translation>Сеть</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="332"/>
        <source>it will try to use mpv + youtube-dl only for the sites that require it</source>
        <translation>осуществляется попытка использования связки mpv + youtube-dl только для сайтов, которые требуют её</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="371"/>
        <source>User agent</source>
        <translation>Агент пользователя</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="92"/>
        <location filename="../prefnetwork.cpp" line="330"/>
        <source>Disabled</source>
        <translation>Отключено</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="94"/>
        <location filename="../prefnetwork.cpp" line="299"/>
        <location filename="../prefnetwork.cpp" line="332"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="110"/>
        <location filename="../prefnetwork.cpp" line="347"/>
        <source>Best video and audio</source>
        <translation>Наилучшее видео и аудио</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="118"/>
        <location filename="../prefnetwork.cpp" line="350"/>
        <source>Worst</source>
        <translation>Наихудшее</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="326"/>
        <source>YouTube</source>
        <translation>YouTube</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="328"/>
        <source>Support for video sites</source>
        <translation>Поддержка видеосайтов</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="330"/>
        <source>support for video sites is turned off</source>
        <translation>поддержка видеосайтов отключена</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="335"/>
        <source>only the internal support for YouTube will be used</source>
        <translation>используется только внутренняя поддержка YouTube</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="338"/>
        <source>uses mpv + youtube-dl for all sites</source>
        <translation>используется связка mpv + youtube-dl для всех сайтов</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="344"/>
        <source>Preferred quality</source>
        <translation>Предпочитаемое качество</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="345"/>
        <source>This option specifies the preferred quality for the video streams handled by youtube-dl.</source>
        <translation>Эта опция указывает предпочитаемое качество видеопотоков, получаемых от youtube-dl.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="347"/>
        <source>selects the best video and audio streams available</source>
        <translation>выбирает наилучшие доступные потоки видео и аудио</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="111"/>
        <location filename="../prefnetwork.cpp" line="348"/>
        <source>Best</source>
        <translation>Наилучшее</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="231"/>
        <source>yt-dlp (based on youtube-dl with improvements)</source>
        <translation>yt-dlp (улучшенная модификация youtube-dl)</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="249"/>
        <source>Other</source>
        <translation>Другое</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="348"/>
        <source>selects the best quality format available as a single file</source>
        <translation>выбирает формат наилучшего качества, доступный как один файл</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="349"/>
        <source>1080p, 720p...</source>
        <translation>1080p, 720p…</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="349"/>
        <source>will try to use the selected resolution if available</source>
        <translation>попытаться использовать выбранное разрешение, если оно доступно</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="350"/>
        <source>selects the worst quality format available</source>
        <translation>выбирает наихудший доступный формат качества</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="359"/>
        <source>Playback quality</source>
        <translation>Качество воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="360"/>
        <source>Select the preferred quality for YouTube videos.</source>
        <translation>Выберите предпочитаемое качество видео с YouTube.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="363"/>
        <source>Use adaptive streams</source>
        <translation>Использовать адаптивные потоки</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="364"/>
        <source>This option enables adaptive streams which can provide videos up to 4K.</source>
        <translation>Эта опция включает адаптивные потоки, которые могут обеспечить видео до 4K.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="366"/>
        <source>Use 60 fps if available</source>
        <translation>Использовать 60 к/с по возможности</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="367"/>
        <source>This option enables streams at 60 frames per second if available.</source>
        <translation>Этот параметр задействует потоки видео с частотой 60 кадров в секунду, если это возможно.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="372"/>
        <source>Set the user agent that SMPlayer will use when connecting to YouTube.</source>
        <translation>Пропишите user agent, который будет использоваться SMPlayer при подключении к YouTube.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="385"/>
        <source>Chromecast</source>
        <translation>Chromecast</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="387"/>
        <source>Local IP</source>
        <translation>Локальный IP</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="388"/>
        <source>The local IP address of this computer. It will be passed to Chromecast so that it can access the files from this computer.</source>
        <translation>Локальный IP-адрес этого компьютера. Он будет передан Chromecast, чтобы он мог получить доступ к файлам с этого компьютера.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="392"/>
        <source>The port that the web server will use.</source>
        <translation> Порт, который веб-сервер будет использовать.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="394"/>
        <source>Directory listing</source>
        <translation>Перечень каталогов</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="395"/>
        <source>When the web server is running, any device in your network can access the files from this computer. If this option is on, any device can get a listing of the files in this computer. If this option is off, the list won&apos;t be available.</source>
        <translation>Когда веб-сервер работает, то любое устройство в сети может получить доступ к файлам с этого компьютера. Если эта опция включена, то любое устройство может получить список файлов на этом компьютере. Если этот параметр отключён, то список не будет доступен.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="401"/>
        <source>Convert SRT subtitles to VTT</source>
        <translation>Конвертировать субтитры SRT в VTT</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="402"/>
        <source>When this option is enabled SMPlayer will convert automatically subtitle files in SRT format to VTT format. The VTT subtitle will have the same filename but extension .vtt</source>
        <translation>Когда этот параметр включён, SMPlayer автоматически преобразует файлы субтитров формата SRT в формат VTT. Имя субтитров VTT будет тем же самым, но расширение станет .vtt</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="405"/>
        <source>Overwrite existing VTT files</source>
        <translation>Перезаписать существующие VTT файлы</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="406"/>
        <source>If this option is enabled SMPlayer will overwrite existing VTT files.</source>
        <translation>Если эта опция включена, то SMPlayer будет перезаписывать существующие VTT файлы.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="408"/>
        <source>Try to remove advertisements</source>
        <translation>Пытаться удалить рекламу</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="409"/>
        <source>If this option is enabled SMPlayer will try to find advertisements in the subtitles and remove them.</source>
        <translation>Если эта опция включена, то SMPlayer будет пытаться найти рекламу в субтитрах и удалять её.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="412"/>
        <source>Position of subtitles on screen</source>
        <translation>Положение субтитров на экране</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="413"/>
        <source>This option sets the position on the screen where the subtitles are displayed.</source>
        <translation>Эта опция устанавливает положение на экране, где отображаются субтитры.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="414"/>
        <source>0 is the top of the screen, 100 is the bottom of the screen.</source>
        <translation>0 — верхняя часть экрана, 100 — нижняя часть экрана.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="415"/>
        <source>The special value -1 means the default position.</source>
        <translation>Специальное значение -1 означает позицию по умолчанию.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="419"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="421"/>
        <source>Enable proxy</source>
        <translation>Включить прокси</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="422"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Включить/отключить использование прокси.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="424"/>
        <source>Host</source>
        <translation>Хост</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="425"/>
        <source>The host name of the proxy.</source>
        <translation>Имя хоста прокси.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="391"/>
        <location filename="../prefnetwork.cpp" line="427"/>
        <source>Port</source>
        <translation>Порт</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="428"/>
        <source>The port of the proxy.</source>
        <translation>Порт прокси.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="430"/>
        <source>Username</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="431"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Если прокси требует аутентификации, то укажите имя пользователя.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="433"/>
        <source>Password</source>
        <translation>Пароль</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="434"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Пароль для прокси. &lt;b&gt;Внимание:&lt;/b&gt; пароль будет сохранён в виде текста в конфигурационном файле.</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="437"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../prefnetwork.cpp" line="438"/>
        <source>Select the proxy type to be used.</source>
        <translation>Выберите тип используемого прокси.</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <location filename="../prefperformance.cpp" line="85"/>
        <location filename="../prefperformance.cpp" line="302"/>
        <source>Performance</source>
        <translation>Быстродействие</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="27"/>
        <source>&amp;Performance</source>
        <translation>&amp;Быстродействие</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="33"/>
        <location filename="../prefperformance.cpp" line="306"/>
        <source>Priority</source>
        <translation>Приоритет</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="77"/>
        <source>realtime</source>
        <translation>реальное время</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="82"/>
        <source>high</source>
        <translation>высокий</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="87"/>
        <source>abovenormal</source>
        <translation>выше обычного</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="92"/>
        <source>normal</source>
        <translation>обычный</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="97"/>
        <source>belownormal</source>
        <translation>ниже обычного</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="102"/>
        <source>idle</source>
        <translation>низкий</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="145"/>
        <source>Decoding</source>
        <translation>Декодирование</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="199"/>
        <source>Hardware &amp;decoding</source>
        <translation>Аппаратное &amp;декодирование</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="355"/>
        <source>A&amp;uto</source>
        <translation>А&amp;вто</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="391"/>
        <location filename="../prefperformance.ui" line="428"/>
        <location filename="../prefperformance.ui" line="465"/>
        <location filename="../prefperformance.ui" line="502"/>
        <location filename="../prefperformance.ui" line="539"/>
        <location filename="../prefperformance.ui" line="576"/>
        <source>KB</source>
        <translation>Кб</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="345"/>
        <source>Setting a cache may improve performance on slow media</source>
        <translation>Настройка кэша может улучшить быстродействие медленного медиа</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="312"/>
        <source>Allow frame drop</source>
        <translation>Допускать выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="313"/>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation>Пропускать кадры для обеспечения синхронизации аудио и видео в медленных системах.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="315"/>
        <source>Allow hard frame drop</source>
        <translation>Допускать жёсткое выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="316"/>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation>Более жёсткий пропуск кадров (рваное декодирование). Приводит к искажению картинки!</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="63"/>
        <source>Priorit&amp;y:</source>
        <translation>П&amp;риоритет:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="131"/>
        <source>&amp;Allow frame drop</source>
        <translation>&amp;Допускать выпадение кадров</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="138"/>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation>Допускать &amp;жёсткое выпадение кадров (изображение может исказиться)</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="290"/>
        <source>&amp;Fast audio track switching</source>
        <translation>&amp;Быстрое переключение звуковых дорожек</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="318"/>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation>Быстрый &amp;поиск по главам на DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="366"/>
        <source>Fast audio track switching</source>
        <translation>Быстрое переключение звуковых дорожек</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="377"/>
        <source>Fast seek to chapters in dvds</source>
        <translation>Быстрый поиск по главам на DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="378"/>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation>Если отмечено, SMPlayer попытается использовать более быстрый метод для поиска по главам, но эта опция может не работать с некоторыми дисками.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="344"/>
        <source>Skip loop filter</source>
        <translation>Пропустить петлевой фильтр</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="230"/>
        <source>H.264</source>
        <translation>H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="367"/>
        <source>Possible values:&lt;br&gt; &lt;b&gt;Yes&lt;/b&gt;: it will try the fastest method to switch the audio track (it might not work with some formats).&lt;br&gt; &lt;b&gt;No&lt;/b&gt;: the MPlayer process will be restarted whenever you change the audio track.&lt;br&gt; &lt;b&gt;Auto&lt;/b&gt;: SMPlayer will decide what to do according to the MPlayer version.</source>
        <translation>Возможные значения: &lt;br&gt; &lt;b&gt;Да&lt;/b&gt;: будет использован наиболее быстрый метод переключения дорожек аудио (может не работать с некоторыми форматами).&lt;br&gt; &lt;b&gt;Нет&lt;/b&gt;: процесс MPlayer будет перезапущен при изменении звуковой дорожки.&lt;br&gt; &lt;b&gt;Авто&lt;/b&gt;: SMPlayer решит самостоятельно, основываясь на версии MPlayer.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="387"/>
        <source>Cache for files</source>
        <translation>Кэширование файлов</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="388"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation>Эта опция определяет размер памяти (в килобайтах), используемых для предварительного кэширования файлов.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="391"/>
        <source>Cache for streams</source>
        <translation>Кэширование потоков</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="392"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation>Эта опция определяет размер памяти (в кБайтах), используемых для предварительного кэширования адреса.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="395"/>
        <source>Cache for DVDs</source>
        <translation>Кэшировать DVD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="396"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation>Эта опция определяет размер памяти (в кБайтах), используемых для предварительного кэширования DVD.&lt;br&gt;&lt;b&gt;Внимание:&lt;/b&gt; Перемотка может работать неправильно (в том числе и обзор глав) при использовании кэширования DVD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="339"/>
        <source>&amp;Cache</source>
        <translation>&amp;Кэш</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="448"/>
        <source>Cache for &amp;DVDs:</source>
        <translation>&amp;Кэш DVD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="374"/>
        <source>Cache for &amp;local files:</source>
        <translation>Кэш локальных &amp;файлов:</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="45"/>
        <source>Select the priority for the player process.</source>
        <translation>Укажите приоритет процесса плеера.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="411"/>
        <source>Cache for &amp;streams:</source>
        <translation>Кэш &amp;потоков:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="100"/>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="101"/>
        <source>Skip (always)</source>
        <translation>Пропускать (всегда)</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="102"/>
        <source>Skip only on HD videos</source>
        <translation>Пропускать только для HD видео</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="244"/>
        <source>Loop &amp;filter</source>
        <translation>Петлевой &amp;фильтр</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="345"/>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation>Этот параметр разрешает пропускать петлевой фильтр (устранение блоков) во время декодирования H.264. Поскольку фильтрованный кадр предполагается использовать в качестве ссылки для декодирования зависимых кадров, то качество, например, у MPEG-2, будет хуже, чем если бы устранение блоков не производилось вообще. Но, как минимум, для HDTV с высоким битрейтом это даёт значительный прирост производительности без видимой потери качества.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="33"/>
        <source>None</source>
        <translation>Отсутствует</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="34"/>
        <location filename="../prefperformance.cpp" line="384"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="307"/>
        <source>Set process priority for %1 according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation>Устанавливает приоритет процесса %1 согласно предопределённым приоритетам, доступным для Windows.&lt;br&gt;&lt;b&gt;Внимание:&lt;/b&gt; Использование приоритета реального времени может сильно замедлить работу системы.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="323"/>
        <source>Hardware decoding</source>
        <translation>Аппаратное декодирование</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="324"/>
        <source>Sets the hardware video decoding API. If hardware decoding is not possible, software decoding will be used instead.</source>
        <translation>Включает интерфейс аппаратного декодирования. Если аппаратное декодирование невозможно, то будет использоваться программное декодирование.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="326"/>
        <source>Available options:</source>
        <translation>Доступные параметры:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="328"/>
        <source>None: only software decoding will be used.</source>
        <translation>Отсутствует: будет использоваться только программное декодирование.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="329"/>
        <source>Auto: it tries to automatically enable hardware decoding using the first available method.</source>
        <translation>Авто: автоматическое использование первого доступного аппаратного метода декодирования.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="331"/>
        <source>vdpau: for the vdpau and opengl video outputs.</source>
        <translation>vdpau: вывод через видеовыходы VDPAU и OpenGL.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="332"/>
        <source>vaapi: for the opengl and vaapi video outputs. For Intel GPUs only.</source>
        <translation>vaapi: вывод через видеовыходы OpenGL и VAAPI. Только для видеокарт от Intel.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="333"/>
        <source>vaapi-copy: it copies video back into system RAM. For Intel GPUs only.</source>
        <translation>vaapi-copy: копирует видео в системную память. Только для видеокарт от Intel.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="336"/>
        <source>dxva2-copy: it copies video back to system RAM. Experimental.</source>
        <translation>dxva2-copy: копирует видео в системную память. Экспериментальная функция.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="340"/>
        <source>This option only works with mpv.</source>
        <translation>Эта опция работает только с MPV.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="352"/>
        <source>Possible values:</source>
        <translation>Возможные значения:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="353"/>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation>&lt;b&gt;Включено&lt;/b&gt;: петлевой фильтр не пропускается</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="354"/>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation>&lt;b&gt;Пропускать (всегда)&lt;/b&gt;: петлевой фильтр не применяется вне зависимости от разрешения видео</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="356"/>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation>&lt;b&gt;Пропускать только для HD видео&lt;/b&gt;: петлевой фильтр пропускается только для видео с высотой картинки %1 или выше.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="361"/>
        <source>Try to use the non-free CoreAVC codec when no other codec is specified and a non-VDPAU video output is selected.</source>
        <translation>Попытаться использовать несвободный CoreAVC кодек, если не указаны другие кодеки и выбран не видеовыход VDPAU.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="363"/>
        <source>Requires a %1 build with CoreAVC support.</source>
        <translation>Требуется сборка %1 с поддержкой CoreAVC.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="382"/>
        <source>Cache</source>
        <translation>Кэш</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="385"/>
        <source>Usually this option will enable the cache when it&apos;s necessary.</source>
        <translation>Обычно эта опция включает кэш, если это необходимо.</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="400"/>
        <source>Cache for audio CDs</source>
        <translation>Кэшировать аудио-CD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="401"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation>Эта опция определяет размер памяти (в кБайтах), используемых для предварительного кэширования аудио-CD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="485"/>
        <source>Cache for &amp;audio CDs:</source>
        <translation>Кэш &amp;аудио-CD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="404"/>
        <source>Cache for VCDs</source>
        <translation>Кэшировать видео-CD</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="405"/>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation>Эта опция определяет размер памяти (в кБайтах), используемых для предварительного кэширования видео-CD.</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="522"/>
        <source>Cache for &amp;VCDs:</source>
        <translation>Кэш &amp;видео-CD:</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="319"/>
        <source>Threads for decoding</source>
        <translation>Потоки декодирования</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="320"/>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation>Указывает число потоков декодирования. Только для MPEG-1/2 и H.264</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="159"/>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation>&amp;Потоки декодирования (только для MPEG-1/2 и H.264):</translation>
    </message>
    <message>
        <location filename="../prefperformance.cpp" line="360"/>
        <source>Use CoreAVC if no other codec specified</source>
        <translation>Использовать CoreAVC, если другой кодек не указан</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="272"/>
        <source>&amp;Use CoreAVC if no other codec specified</source>
        <translation>И&amp;спользовать CoreAVC, если другой кодек не указан</translation>
    </message>
    <message>
        <location filename="../prefperformance.ui" line="559"/>
        <source>Cache for &amp;TV:</source>
        <translation>Кэш для &amp;ТВ:</translation>
    </message>
</context>
<context>
    <name>PrefPlaylist</name>
    <message>
        <location filename="../prefplaylist.cpp" line="39"/>
        <source>Playlist</source>
        <translation>Плейлист</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="208"/>
        <source>If this option is enabled, every time a file is opened, SMPlayer will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>Если эта опция отмечена, каждый раз при открытии файла, SMPlayer будет первым делом очищать плейлист и затем добавлять файл в него. Касательно DVD, CD и VCD, все заголовки на диске будут добавлены в плейлист.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="51"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="52"/>
        <source>Video files</source>
        <translation>Видеофайлы</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="53"/>
        <source>Audio files</source>
        <translation>Аудиофайлы</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="54"/>
        <source>Video and audio files</source>
        <translation>Видео и аудиофайлы</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="55"/>
        <source>Consecutive files</source>
        <translation>Последовательные файлы</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="197"/>
        <source>Start playback after loading a playlist</source>
        <translation>Начинать воспроизведение по загрузке плейлиста</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="198"/>
        <source>Playback will start just after loading a playlist.</source>
        <translation>Воспроизведение начнётся только после загрузки плейлиста.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="200"/>
        <source>Play next file automatically</source>
        <translation>Воспроизводить следующий файл автоматически</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="201"/>
        <source>When a file reaches the end, the next file will be played automatically.</source>
        <translation>Когда файл достигнет конца, следующий файл будет проигран автоматически.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="203"/>
        <source>Ignore playback errors</source>
        <translation>Игнорировать ошибки воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="207"/>
        <source>Add files to the playlist automatically</source>
        <translation>Добавлять файлы в плейлист автоматически</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="213"/>
        <source>Add files from folder</source>
        <translation>Добавлять файлы из папки</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="234"/>
        <source>Display title name instead of filename</source>
        <translation>Отображать название заголовка вместо имени файла</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="235"/>
        <source>The playlist will display the title (if any) instead of the filename.</source>
        <translation>Плейлист будет отображать заголовок (если есть) вместо имени файла.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="237"/>
        <source>The playlist window is dockable</source>
        <translation>Окно плейлиста можно закрепить</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="238"/>
        <source>If this option is checked, the playlist window can be docked inside the main window. Otherwise the playlist would be a regular window.</source>
        <translation>Если этот параметр отмечен, окно плейлиста можно закрепить в главном окне. В ином случае плейлист будет отдельным окном.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="241"/>
        <source>Misc</source>
        <translation>Прочее</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="243"/>
        <source>Auto sort</source>
        <translation>Автосортировка</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="244"/>
        <source>If this option is enabled the list will be sorted automatically after adding files.</source>
        <translation>Если эта опция включена, список будет отсортирован автоматически после добавления файлов.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="246"/>
        <source>Case sensitive search</source>
        <translation>Поиск с учётом регистра</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="247"/>
        <source>This option specifies whether the search in the playlist is case sensitive or not.</source>
        <translation>Этот параметр определяет является ли поиск в плейлисте чувствительным к регистру или нет.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="249"/>
        <source>Save a copy of the playlist on exit</source>
        <translation>Сохранять копию плейлиста при выходе</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="250"/>
        <source>If this option is checked, a copy of the playlist will be saved in the configuration file when SMPlayer is closed, and it will reloaded automatically when SMPlayer is run again.</source>
        <translation>Если эта опция отмечена, в файле конфигурации SMPlayer при закрытии будет сохранена копия плейлиста, которая будет автоматически загружена при следующем запуске SMPlayer.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="255"/>
        <source>Enable the option to delete files from disk</source>
        <translation>Включить опцию для удаления файлов с диска</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="256"/>
        <source>This option allows you to enable the option to delete files from disk in the playlist&apos;s context menu. To prevent accidental deletions this option is disabled by default.</source>
        <translation>Эта опция позволяет включить возможность удалять файлы с диска в контекстном меню плейлиста. Для предотвращения случайного удаления эта опция отключена по умолчанию.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="215"/>
        <source>&lt;b&gt;None&lt;/b&gt;: no files will be added</source>
        <translation>&lt;b&gt;Ничего&lt;/b&gt;: ни какие файлы не были добавлены</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="216"/>
        <source>&lt;b&gt;Video files&lt;/b&gt;: all video files found in the folder will be added</source>
        <translation>&lt;b&gt;Видео файлы&lt;/b&gt;: все видеофайлы, найденные в папке, будут добавлены</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="217"/>
        <source>&lt;b&gt;Audio files&lt;/b&gt;: all audio files found in the folder will be added</source>
        <translation>&lt;b&gt;Аудиофайлы&lt;/b&gt;: все аудиофайлы, найденные в папке, будут добавлены</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="218"/>
        <source>&lt;b&gt;Video and audio files&lt;/b&gt;: all video and audio files found in the folder will be added</source>
        <translation>&lt;b&gt;Файлы видео и аудио&lt;/b&gt;: все файлы видео и аудио, найденные в папке, будут добавлены</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="219"/>
        <source>&lt;b&gt;Consecutive files&lt;/b&gt;: consecutive files (like video_1.avi, video_2.avi) will be added</source>
        <translation>&lt;b&gt;Последовательные файлы&lt;/b&gt;: будут добавлены файлы, идущие по порядку (такие как video_1.avi, video_2.avi)</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="192"/>
        <source>Play files from start</source>
        <translation>Воспроизводить файлы с начала</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="193"/>
        <source>If this option is enabled, all files from the playlist will start to play from the beginning instead of resuming from a previous playback.</source>
        <translation>Если эта опция отмечена, все файлы в плейлисте будут начинаться с начала, вместо продолжения предыдущего воспроизведения.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="214"/>
        <source>This option can be used to add files automatically to the playlist:</source>
        <translation>Данная опция может быть использована для добавления файлов в плейлист автоматически:</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="227"/>
        <source>Get info automatically about files added</source>
        <translation>Автоматически получать информацию о добавленных файлах</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="204"/>
        <source>If this option is enabled, the playlist will ignore playback errors from a previous file and will play the next file in the list.</source>
        <translation>При включении данной опции плейлист будет игнорировать ошибки воспроизведения предыдущего файла и будет проигрывать следующий файл в списке.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="24"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Плейлист</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="222"/>
        <source>Add files in directories recursively</source>
        <translation>Добавить файлы в каталогах рекурсивно</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="223"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Выберите эту опцию, если вы хотите, чтобы при добавлении каталога подкаталоги тоже добавлялись рекурсивно. Иначе будут добавлены только файлы из текущего каталога.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.cpp" line="228"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Выберите эту опцию, чтобы получать из добавляемых в плейлист файлов информацию. Это позволяет отображать имя (если доступно) и сведения о файлах. Иначе эта информация не будет доступна, пока файл не начнёт воспроизводиться. Будьте осторожны: эта опция может замедлить работу, особенно при большом количестве добавляемых файлов.</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="101"/>
        <source>Add files from &amp;folder:</source>
        <translation>Добавлять файлы из &amp;папки:</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="36"/>
        <source>P&amp;lay files from start</source>
        <translation>Воспроизводить файлы с &amp;начала</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="30"/>
        <source>Playback</source>
        <translation>Воспроизведение</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="43"/>
        <source>S&amp;tart playback after loading a playlist</source>
        <translation>&amp;Начинать воспроизведение после загрузки плейлиста</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="50"/>
        <source>Pla&amp;y next file automatically</source>
        <translation>Воспрои&amp;зводить следующий файл автоматически</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="57"/>
        <source>Ig&amp;nore playback errors</source>
        <translation>И&amp;гнорировать ошибки воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="67"/>
        <source>Adding files</source>
        <translation>Добавление файлов</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="73"/>
        <source>&amp;Add files to the playlist automatically</source>
        <translation>&amp;Добавлять файлы в плейлист автоматически</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="133"/>
        <source>Add files in directories &amp;recursively</source>
        <translation>Добавлять файлы из каталогов &amp;рекурсивно</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="140"/>
        <source>Get &amp;info automatically about files added (slow)</source>
        <translation>&amp;Автоматически получать сведения о добавленных файлах (медленно)</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="157"/>
        <source>Display title name instead of &amp;filename</source>
        <translation>Отобр&amp;ажать название заголовка вместо имени файла</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="164"/>
        <source>The playlist window is &amp;dockable</source>
        <translation>Окно плейлиста можно &amp;закрепить</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="185"/>
        <source>&amp;Misc</source>
        <translation>Про&amp;чее</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="191"/>
        <source>A&amp;uto sort</source>
        <translation>Авто&amp;сортировка</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="198"/>
        <source>Cas&amp;e sensitive search</source>
        <translation>Поиск с у&amp;чётом регистра</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="205"/>
        <source>&amp;Save a copy of the playlist on exit</source>
        <translation>Со&amp;хранять копию плейлиста при выходе</translation>
    </message>
    <message>
        <location filename="../prefplaylist.ui" line="212"/>
        <source>Enable the option to delete files from &amp;disk</source>
        <translation>Включить опцию для удаления файлов с &amp;диска</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="61"/>
        <location filename="../prefsubtitles.cpp" line="400"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="30"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="39"/>
        <location filename="../prefsubtitles.cpp" line="402"/>
        <source>Autoload</source>
        <translation>Автозагрузка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>Same name as movie</source>
        <translation>Имя совпадает с фильмом</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="230"/>
        <source>Use the &amp;ASS library</source>
        <translation>Исполь&amp;зовать библиотеку ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="244"/>
        <source>Enable &amp;Windows fonts</source>
        <translation>Разрешить шрифты &amp;Windows</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="368"/>
        <location filename="../prefsubtitles.cpp" line="450"/>
        <location filename="../prefsubtitles.cpp" line="469"/>
        <source>Font</source>
        <translation>Шрифт</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="472"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="51"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>&amp;Автозагрузка файлов субтитров (*.srt, *.sub…):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="64"/>
        <source>S&amp;elect first available subtitle</source>
        <translation>Загружать &amp;первые доступные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="77"/>
        <source>All subtitles containing the movie name</source>
        <translation>Все субтитры, содержащие имя фильма</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="82"/>
        <source>All subtitles in the directory</source>
        <translation>Все субтитры каталога</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="123"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>&amp;Кодировка субтитров по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="210"/>
        <source>&amp;Include subtitles on screenshots</source>
        <translation>&amp;Сохранять субтитры на снимках экрана</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="405"/>
        <source>Select first available subtitle</source>
        <translation>Выберите первые доступные субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="411"/>
        <source>Default subtitle encoding</source>
        <translation>Кодировка субтитров по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="427"/>
        <source>Include subtitles on screenshots</source>
        <translation>Сохранять субтитры на снимках экрана</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="481"/>
        <source>Text color</source>
        <translation>Цвет текста</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="482"/>
        <source>Select the color for the text of the subtitles.</source>
        <translation>Выберите цвет текста субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="484"/>
        <source>Border color</source>
        <translation>Цвет границы</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="485"/>
        <source>Select the color for the border of the subtitles.</source>
        <translation>Выберите цвет границы субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="403"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Выберите метод автозагрузки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="406"/>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation>Если доступно более одной дорожки субтитров, одна из них будет автоматически выбрана, обычно первая, хотя если одна из дорожек удовлетворяет выбранному пользователем предпочитаемому языку, то будет выбрана именно она.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="412"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Выберите кодировку, которая будет использована для файлов субтитров по умолчанию.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="415"/>
        <source>Try to autodetect for this language</source>
        <translation>Автоматически определить для языка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="422"/>
        <source>Subtitle language</source>
        <translation>Язык субтитров</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="423"/>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation>Выберите язык, для которого будет производиться автоматическое определение кодировки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="109"/>
        <source>Encoding</source>
        <translation>Кодировка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="172"/>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation>А&amp;втоматически определить для языка:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="511"/>
        <source>Outline</source>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="470"/>
        <source>Select the font for the subtitles.</source>
        <translation>Выберите шрифт для субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="431"/>
        <source>Use the ASS library</source>
        <translation>Использовать библиотеку ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="432"/>
        <source>This option enables the ASS library, which allows to display subtitles with multiple colors, fonts...</source>
        <translation>Данная опция активирует библиотеку ASS, что позволяет использовать субтитры с разными цветами, шрифтами…</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="442"/>
        <source>Enable Windows fonts</source>
        <translation>Разрешить шрифты Windows</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="443"/>
        <source>If this option is enabled the Windows system fonts will be available for subtitles. There&apos;s an inconvenience: a font cache have to be created which can take some time.</source>
        <translation>Если эта опция включена, системные шрифты Windows будут доступны для субтитров. Но есть неудобство: должен быть создан кэш шрифтов, это может занять некоторое время.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="446"/>
        <source>If this option is not checked then only a few fonts bundled with SMPlayer can be used, but this is faster.</source>
        <translation>Если эта опция включена, будет использоваться только несколько шрифтов, входящих в состав SMPlayer, но это быстрее. </translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="473"/>
        <source>The size in pixels.</source>
        <translation>Размер в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="475"/>
        <source>Bold</source>
        <translation>Жирный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="476"/>
        <source>If checked, the text will be displayed in &lt;b&gt;bold&lt;/b&gt;.</source>
        <translation>Если отмечено, текст будет отображаться &lt;b&gt;жирным&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="478"/>
        <source>Italic</source>
        <translation>Наклонный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="479"/>
        <source>If checked, the text will be displayed in &lt;i&gt;italic&lt;/i&gt;.</source>
        <translation>Если отмечено, текст будет отображаться &lt;i&gt;наклонным&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="490"/>
        <source>Left margin</source>
        <translation>Поле слева</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="491"/>
        <source>Specifies the left margin in pixels.</source>
        <translation>Определяет размер поля слева в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="493"/>
        <source>Right margin</source>
        <translation>Поле справа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="494"/>
        <source>Specifies the right margin in pixels.</source>
        <translation>Определяет размер поля справа в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="496"/>
        <source>Vertical margin</source>
        <translation>Вертикальное поле</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="497"/>
        <source>Specifies the vertical margin in pixels.</source>
        <translation>Определяет размер поля по вертикали в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="499"/>
        <source>Horizontal alignment</source>
        <translation>Выравнивание по горизонтали</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="500"/>
        <source>Specifies the horizontal alignment. Possible values are left, centered and right.</source>
        <translation>Определяет тип выравнивания по горизонтали. Возможные значения – слева, по центру и справа.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="503"/>
        <source>Vertical alignment</source>
        <translation>Выравнивание по вертикали</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="504"/>
        <source>Specifies the vertical alignment. Possible values: bottom, middle and top.</source>
        <translation>Определяет тип выравнивания по вертикали. Возможные значения – снизу, по середине и сверху.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="507"/>
        <source>Border style</source>
        <translation>Стиль границы</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="508"/>
        <source>Specifies the border style. Possible values: outline and opaque box.</source>
        <translation>Определяет стиль границы. Возможные значения: контур и непрозрачный.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="515"/>
        <source>Shadow</source>
        <translation>Тень</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="519"/>
        <source>Apply style to ASS files too</source>
        <translation>Применить стили и для файлов ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="386"/>
        <source>Si&amp;ze:</source>
        <translation>&amp;Размер:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="428"/>
        <source>Bol&amp;d</source>
        <translation>&amp;Жирный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="435"/>
        <source>&amp;Italic</source>
        <translation>&amp;Наклонный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="447"/>
        <source>Colors</source>
        <translation>Цвета</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="456"/>
        <source>&amp;Text:</source>
        <translation>&amp;Текст:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="482"/>
        <source>&amp;Border:</source>
        <translation>Грани&amp;ца:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="534"/>
        <source>Margins</source>
        <translation>Поля</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="543"/>
        <source>L&amp;eft:</source>
        <translation>С&amp;лева:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="563"/>
        <source>&amp;Right:</source>
        <translation>С&amp;права:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="583"/>
        <source>Verti&amp;cal:</source>
        <translation>По &amp;вертикали:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="619"/>
        <source>Alignment</source>
        <translation>Выравнивание</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="628"/>
        <source>&amp;Horizontal:</source>
        <translation>&amp;Горизонтальное:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="644"/>
        <source>&amp;Vertical:</source>
        <translation>Верти&amp;кальное:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="665"/>
        <source>Border st&amp;yle:</source>
        <translation>&amp;Стиль границы:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="694"/>
        <source>Opacity:</source>
        <translation>Непрозрачность:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="730"/>
        <source>&amp;Outline:</source>
        <translation>К&amp;онтур:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="750"/>
        <source>Shado&amp;w:</source>
        <translation>Т&amp;ень:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="790"/>
        <source>A&amp;pply style to ASS files too</source>
        <translation>П&amp;рименить стили и для файлов ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="839"/>
        <source>Use custo&amp;m style</source>
        <translation>Использовать &amp;особый стиль</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="466"/>
        <source>The following options allows you to define the style to be used for non-styled subtitles (srt, sub...).</source>
        <translation>Следующие параметры позволяют вам определить стиль, который будет использован для нестилизованных субтитров (srt, sub…).</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="106"/>
        <source>Left</source>
        <comment>horizontal alignment</comment>
        <translation>Слева</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="107"/>
        <source>Centered</source>
        <comment>horizontal alignment</comment>
        <translation>По центру</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="108"/>
        <source>Right</source>
        <comment>horizontal alignment</comment>
        <translation>Справа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="113"/>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation>Снизу</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="114"/>
        <source>Middle</source>
        <comment>vertical alignment</comment>
        <translation>По середине</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="115"/>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation>Сверху</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="120"/>
        <source>Outline</source>
        <comment>border style</comment>
        <translation>Контур</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="121"/>
        <source>Opaque box</source>
        <comment>border style</comment>
        <translation>Непрозрачный</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="416"/>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a %1 with ENCA support.</source>
        <translation>Если опция отмечена, будет произведена попытка автоматически определить кодировку для указанного языка. При ошибке будет использована кодировка по умолчанию. Опция требует %1, скомпилированного с поддержкой ENCA.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="436"/>
        <source>You should normally not disable this option. Do it only if your %1 is compiled without freetype support. &lt;b&gt;Disabling this option could make subtitles not to work at all!&lt;/b&gt;</source>
        <translation>Обычно отключение данной опции не требуется. Отключайте её только, если %1 собран без поддержки freetype. &lt;b&gt;Отключение этой опции может привести к неработоспособности субтитров!&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="512"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the width of the outline around the text in pixels.</source>
        <translation>Если стиль границы установлен в &lt;i&gt;контур&lt;/i&gt;, эта опция определяет ширину контура вокруг текста в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="516"/>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the depth of the drop shadow behind the text in pixels.</source>
        <translation>Если стиль границы установлен в &lt;i&gt;непрозрачный&lt;/i&gt;, эта опция определяет длину тени за текстом в пикселах.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="452"/>
        <source>This option does NOT change the size of the subtitles in the current video. To do so, use the options &lt;i&gt;Size+&lt;/i&gt; and &lt;i&gt;Size-&lt;/i&gt; in the subtitles menu.</source>
        <translation>Этот параметр НЕ изменяет размер субтитров для текущего видео. Чтобы сделать это, используйте параметры &lt;i&gt;Размер +&lt;/i&gt; и &lt;i&gt;Размер –&lt;/i&gt; в меню субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="456"/>
        <source>Default scale</source>
        <translation>Увеличение по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="457"/>
        <source>This option specifies the default font scale for SSA/ASS subtitles which will be used for new opened files.</source>
        <translation>Эта настройка определяет размер шрифта для субтитров SSA/ASS, который будет использоваться для новых видеофайлов.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="461"/>
        <source>Line spacing</source>
        <translation>Междустрочный интервал</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="462"/>
        <source>This specifies the spacing that will be used to separate multiple lines. It can have negative values.</source>
        <translation>Здесь указывается интервал, который будет использоваться для разделения строк. Он может иметь отрицательные значения.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="271"/>
        <source>&amp;Font and colors</source>
        <translation>&amp;Шрифт и цвета</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="298"/>
        <source>Defa&amp;ult scale:</source>
        <translation>Увели&amp;чение по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="337"/>
        <source>&amp;Line spacing:</source>
        <translation>Междустрочный &amp;интервал:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="435"/>
        <source>Freetype support</source>
        <translation>Поддержка Freetype</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="237"/>
        <source>Freet&amp;ype support</source>
        <translation>Под&amp;держка Freetype</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="428"/>
        <source>If this option is checked, the subtitles will appear in the screenshots. &lt;b&gt;Note:&lt;/b&gt; it may cause some troubles sometimes.</source>
        <translation>Если выбрано, субтитры будут отображаться на снимках экрана.&lt;b&gt; Примечание:&lt;/b&gt; иногда это может вызывать проблемы.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="349"/>
        <source>Customize SSA/ASS style</source>
        <translation>Настроить стиль субтитров SSA/ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="350"/>
        <source>Here you can enter your customized SSA/ASS style.</source>
        <translation>Здесь можно указать предпочитаемый стиль субтитров SSA/ASS.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="351"/>
        <source>Clear the edit line to disable the customized style.</source>
        <translation>Очистите поле ввода, чтобы отменить настройки стиля.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="465"/>
        <source>SSA/ASS style</source>
        <translation>Стиль SSA/ASS</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="487"/>
        <source>Shadow color</source>
        <translation>Цвет тени</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="488"/>
        <source>This color will be used for the shadow of the subtitles.</source>
        <translation>Этот цвет будет использован для тени субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="508"/>
        <source>Shadow:</source>
        <translation>Тень:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="813"/>
        <source>Custo&amp;mize...</source>
        <translation>&amp;Настроить…</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="520"/>
        <source>If this option is checked, the style defined above will be applied to ass subtitles too.</source>
        <translation>Если эта опция выбрана, указанные стили будут также применены и к субтитрам в формате ass.</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <location filename="../preftv.cpp" line="41"/>
        <source>TV and radio</source>
        <translation>ТВ и радио</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="53"/>
        <source>None</source>
        <translation>Ничего</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="54"/>
        <source>Lowpass5</source>
        <translation>Lowpass5</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="55"/>
        <source>Yadif (normal)</source>
        <translation>Yadif (обычный)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="56"/>
        <source>Yadif (double framerate)</source>
        <translation>Yadif (удвоенная частота)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="57"/>
        <source>Linear Blend</source>
        <translation>Линейное смешивание</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="58"/>
        <source>Kerndeint</source>
        <translation>Адаптивное (kerndeint)</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="105"/>
        <source>Deinterlace by default for TV</source>
        <translation>Стандартное устранение чересстрочности для ТВ</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="106"/>
        <source>Select the deinterlace filter that you want to be used for TV channels.</source>
        <translation>Выберите фильтр устранения чересстрочности, который вы хотите использовать для ТВ-каналов.</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="109"/>
        <source>Rescan ~/.mplayer/channels.conf on startup</source>
        <translation>Пересканировать ~/.mplayer/channels.conf при запуске</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="32"/>
        <source>&amp;TV and radio</source>
        <translation>&amp;ТВ и радио</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="55"/>
        <source>Dei&amp;nterlace by default for TV:</source>
        <translation>Стандартное &amp;устранение чересстрочности для ТВ:</translation>
    </message>
    <message>
        <location filename="../preftv.cpp" line="110"/>
        <source>If this option is enabled, SMPlayer will look for new TV and radio channels on ~/.mplayer/channels.conf.ter or ~/.mplayer/channels.conf.</source>
        <translation>Если эта опция выбрана, SMPlayer будет искать новые ТВ и радио каналы в ~/.mplayer/channels.conf.ter или ~/.mplayer/channels.conf.</translation>
    </message>
    <message>
        <location filename="../preftv.ui" line="90"/>
        <source>&amp;Check for new channels on startup</source>
        <translation>&amp;Проверять на наличие новых каналов при старте</translation>
    </message>
</context>
<context>
    <name>PrefUpdates</name>
    <message>
        <location filename="../prefupdates.ui" line="24"/>
        <source>U&amp;pdates</source>
        <translation>Обновления</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="30"/>
        <source>Check for &amp;updates</source>
        <translation>Проверять &amp;обновления</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="62"/>
        <source>Check interval (in &amp;days)</source>
        <translation>Интервал проверки (в &amp;днях)</translation>
    </message>
    <message>
        <location filename="../prefupdates.ui" line="104"/>
        <source>&amp;Open an informative page after an upgrade</source>
        <translation>&amp;Открыть страницу с информацией после обновления</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="46"/>
        <source>Updates</source>
        <translation>Обновления</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="86"/>
        <source>Check for updates</source>
        <translation>Проверка обновлений</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="87"/>
        <source>If this option is enabled, SMPlayer will check for updates and display a notification if a new version is available.</source>
        <translation>Если этот параметр включён, то SMPlayer будет проверять обновления и покажет сообщение, когда станет доступна новая версия.</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="90"/>
        <source>Check interval</source>
        <translation>Интервал проверки</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="91"/>
        <source>You can enter here the interval (in days) for the update checks.</source>
        <translation>Здесь вы можете ввести интервал проверки обновлений (в днях).</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="95"/>
        <source>Open an informative page after an upgrade</source>
        <translation>Открыть страницу с информацией после обновления</translation>
    </message>
    <message>
        <location filename="../prefupdates.cpp" line="96"/>
        <source>If this option is enabled, an informative page about SMPlayer will be opened after an upgrade.</source>
        <translation>Если включено, после обновления будет открыта страницу с информацией об SMPlayer.</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="171"/>
        <source>SMPlayer - Help</source>
        <translation>SMPlayer – Справка</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Отмена</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="13"/>
        <source>SMPlayer - Preferences</source>
        <translation>SMPlayer – Настройки</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="183"/>
        <source>will show this message and then will exit.</source>
        <translation>будет показано это сообщение, после чего приложение закроется.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="150"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>главное окно закроется по окончании файла/плейлиста.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="605"/>
        <source>This is SMPlayer v. %1 running on %2</source>
        <translation>SMPlayer v. %1 запущен в %2</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="135"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>пытается соединиться с другим запущенным экземпляром и послать ему заданное действие. Пример: -send-action pause Остальные параметры (если есть) будут игнорироваться, и приложение будет закрыто. При успешном выполнении задачи возвращается &quot;0&quot;, в обратном случае — &quot;-1&quot;.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="142"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>список_действий – список действий, разделённый пробелами. Эти действия будут выполняться по загрузке файла в заданной вами последовательности. Для действий с переменными значениями можно использовать true или false в качестве параметров. Например: -actions &quot;fullscreen compact true&quot;. Кавычки необходимы в случае, если используется более одного действия.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="100"/>
        <location filename="../clhelp.cpp" line="192"/>
        <source>media</source>
        <translation>медиа</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="186"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>Если экземпляр программы уже запущен, то файлы мультимедиа будут добавлены в текущий плейлист. Если же нет – параметр будет проигнорирован и файлы будут открыты в новом экземпляре.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="153"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>главное окно не закроется по окончании файла/плейлиста.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="156"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>Видео будет воспроизводиться в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="159"/>
        <source>the video will be played in window mode.</source>
        <translation>Видео будет воспроизводиться в оконном режиме.</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="254"/>
        <source>Enqueue in SMPlayer</source>
        <translation>Добавить в очередь SMPlayer</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="117"/>
        <source>opens the mini gui instead of the default one.</source>
        <translation>открывает мини-интерфейс вместо стандартного.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Восстанавливает старые ассоциации и очищает реестр.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <location filename="../clhelp.cpp" line="109"/>
        <source>Usage:</source>
        <translation>Использование:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="95"/>
        <source>directory</source>
        <translation>каталог</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="96"/>
        <source>action_name</source>
        <translation>имя_действия</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="97"/>
        <source>action_list</source>
        <translation>список_действий</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="123"/>
        <source>opens the default gui.</source>
        <translation>открывает интерфейс по умолчанию.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="98"/>
        <source>subtitle_file</source>
        <translation>файл_субтитров</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="168"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>указывает файл субтитров, который будет загружен для первого видеофайла.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="127"/>
        <location filename="../helper.cpp" line="133"/>
        <source>%n second(s)</source>
        <translation><numerusform>%n секунда</numerusform><numerusform>%n секунды</numerusform><numerusform>%n секунд</numerusform><numerusform>%n секунд</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="130"/>
        <location filename="../helper.cpp" line="132"/>
        <source>%n minute(s)</source>
        <translation><numerusform>%n минута</numerusform><numerusform>%n минуты</numerusform><numerusform>%n минут</numerusform><numerusform>%n минут</numerusform></translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="134"/>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="131"/>
        <source>specifies the directory where smplayer will store its configuration files (smplayer.ini, smplayer_files.ini...)</source>
        <translation>определяет каталог, в котором SMPlayer будет сохранять свои конфигурационные файлы (smplayer.ini, smplayer_files.ini…)</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="188"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>отключено</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="199"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>автоматически</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="200"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>неизвестно</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="120"/>
        <source>opens the mpc gui.</source>
        <translation>открывает оболочку MPC.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="99"/>
        <source>width</source>
        <translation>ширина</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="99"/>
        <source>height</source>
        <translation>высота</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="101"/>
        <source>time</source>
        <translation>время</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the gui with support for skins.</source>
        <translation>открывает графический интерфейс с поддержкой обложек.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="162"/>
        <source>sets the stay on top option to always.</source>
        <translation>включает опцию всегда поверх всех окон.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="165"/>
        <source>sets the stay on top option to never.</source>
        <translation>отключает параметр поверх всех окон.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="171"/>
        <source>sets the media title for the first video.</source>
        <translation>указывает название для первого видеофайла.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="174"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>указывает координаты верхнего левого угла главного окна приложения.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="177"/>
        <source>specifies the size of the main window.</source>
        <translation>указывает размер главного окна.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="180"/>
        <source>specifies the start time (in seconds) of the first file to be played. Also valid h:m:s and m:s</source>
        <translation>указывает время начала (в секундах) первого файла для воспроизведения. Также принимаются ч:м:с и м:с</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="192"/>
        <source>&apos;media&apos; is any kind of file that SMPlayer can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls.</source>
        <translation>&apos;медиа&apos; – любой тип файла, который может открыть SMPlayer. Это может быть файл, DVD (напр. dvd://1), интернет-поток (напр. mms://....) или локальный плейлист в формате m3u или pls.</translation>
    </message>
    <message>
        <location filename="../sharedata.cpp" line="40"/>
        <source>SMPlayer is my favorite media player for my PC. Check it out!</source>
        <comment>This text is to be published on twitter and the translation should not be more than 99 characters long</comment>
        <translation>SMPlayer — мой любимый медиаплеер для ПК. Попробуйте!</translation>
    </message>
    <message>
        <location filename="../version.cpp" line="44"/>
        <source>%1 (revision %2) %3</source>
        <translation>%1 (ревизия %2) %3</translation>
    </message>
    <message>
        <location filename="../version.cpp" line="46"/>
        <source>%1 (revision %2)</source>
        <translation>%1 (ревизия %2)</translation>
    </message>
</context>
<context>
    <name>ShareDialog</name>
    <message>
        <location filename="../sharedialog.ui" line="14"/>
        <source>Support SMPlayer</source>
        <translation>Поддержать SMPlayer</translation>
    </message>
    <message>
        <location filename="../sharedialog.ui" line="89"/>
        <source>&amp;Remind me later</source>
        <translation>&amp;Напомнить позже</translation>
    </message>
    <message>
        <location filename="../sharedialog.cpp" line="33"/>
        <source>Donate with PayPal</source>
        <translation>Пожертвовать в PayPal</translation>
    </message>
    <message>
        <location filename="../sharedialog.cpp" line="47"/>
        <source>You can support SMPlayer by sending a donation or sharing it with your friends.</source>
        <translation>Вы можете поддержать SMPlayer пожертвованием или распространением среди друзей.</translation>
    </message>
</context>
<context>
    <name>ShareWidget</name>
    <message>
        <location filename="../sharewidget.cpp" line="113"/>
        <source>Donate with PayPal</source>
        <translation>Пожертвовать в PayPal</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="114"/>
        <source>Share SMPlayer in Facebook</source>
        <translation>Поделиться SMPlayer через Фейсбук</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="115"/>
        <source>Share SMPlayer in Twitter</source>
        <translation>Поделиться SMPlayer через Твиттер</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="117"/>
        <source>Support SMPlayer</source>
        <translation>Поддержать SMPlayer</translation>
    </message>
    <message>
        <location filename="../sharewidget.cpp" line="118"/>
        <source>Donate / Share SMPlayer with your friends</source>
        <translation>Пожертвовать / поделиться SMPlayer с друзьями</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="267"/>
        <source>Modify shortcut</source>
        <translation>Изменить сочетание клавиш</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="310"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Press the key combination you want to assign</source>
        <translation>Нажмите клавиши, сочетание которых вы хотите использовать</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="280"/>
        <source>Add shortcut</source>
        <translation>Добавить сочетание</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="284"/>
        <source>Remove shortcut</source>
        <translation>Удалить сочетание</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="312"/>
        <source>Capture</source>
        <translation>Захват</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="313"/>
        <source>Capture keystrokes</source>
        <translation>Горячая клавиша снимка экрана</translation>
    </message>
</context>
<context>
    <name>ShutdownDialog</name>
    <message>
        <location filename="../shutdowndialog.ui" line="14"/>
        <source>Shutting down computer</source>
        <translation>Выключение компьютера</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="41"/>
        <source>Playback has finished. SMPlayer is about to exit.</source>
        <translation>Воспроизведение закончилось. SMPlayer скоро закроется.</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="42"/>
        <source>The computer will shut down in %1 seconds.</source>
        <translation>Компьютер выключится через %1 секунд.</translation>
    </message>
    <message>
        <location filename="../shutdowndialog.cpp" line="42"/>
        <source>Press &lt;b&gt;Cancel&lt;/b&gt; to abort shutdown.</source>
        <translation>Нажмите &lt;b&gt;Отменить&lt;/b&gt; для отмены выключения.</translation>
    </message>
</context>
<context>
    <name>SkinGui</name>
    <message>
        <location filename="../skingui/skingui.cpp" line="391"/>
        <source>&amp;Toolbars</source>
        <translation>&amp;Панели</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="394"/>
        <source>Status&amp;bar</source>
        <translation>Панель с&amp;татуса</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="397"/>
        <source>&amp;Main toolbar</source>
        <translation>&amp;Главная панель</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="401"/>
        <source>Edit main &amp;toolbar</source>
        <translation>Изменить &amp;главную панель</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="403"/>
        <source>Edit &amp;floating control</source>
        <translation>Изменить &amp;плавающую панель</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="407"/>
        <source>&amp;Video info</source>
        <translation>&amp;Информация о видео</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="408"/>
        <source>&amp;Scroll title</source>
        <translation>&amp;Прокручивать название</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="416"/>
        <source>Playing</source>
        <translation>Воспроизводится</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="417"/>
        <source>Pause</source>
        <translation>Пауза</translation>
    </message>
    <message>
        <location filename="../skingui/skingui.cpp" line="418"/>
        <source>Stop</source>
        <translation>Стоп</translation>
    </message>
</context>
<context>
    <name>Stereo3dDialog</name>
    <message>
        <location filename="../stereo3ddialog.ui" line="14"/>
        <source>Stereo 3D filter</source>
        <translation>Стерео 3D-фильтр</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.ui" line="20"/>
        <source>&amp;3D format of the video:</source>
        <translation>&amp;3D формат видео:</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.ui" line="33"/>
        <source>&amp;Output format:</source>
        <translation>&amp;Режим вывода:</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="26"/>
        <source>Side by side parallel (left eye left, right eye right)</source>
        <translation>Горизонтальная стереопара (левый глаз слева, правый глаз справа)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="27"/>
        <source>Side by side crosseye (right eye left, left eye right)</source>
        <translation>Перекрёстная стереопара (правый глаз слева, левый глаз справа)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="28"/>
        <source>Side by side with half width resolution (left eye left, right eye right)</source>
        <translation>Горизонтальная стереопара с половинной шириной (левый глаз слева, правый глаз справа)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="29"/>
        <source>Side by side with half width resolution (right eye left, left eye right)</source>
        <translation>Перекрёстная стереопара с половинной шириной (правый глаз слева, левый глаз справа)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="31"/>
        <source>Above-below (left eye above, right eye below)</source>
        <translation>Вертикальная стереопара (левый глаз сверху, правый глаз снизу)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="32"/>
        <source>Above-below (right eye above, left eye below)</source>
        <translation>Вертикальная стереопара (правый глаз сверху, левый глаз снизу)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="33"/>
        <source>Above-below with half height resolution (left eye above, right eye below)</source>
        <translation>Вертикальная стереопара с половинной высотой (левый глаз сверху, правый глаз снизу)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="34"/>
        <source>Above-below with half height resolution (right eye above, left eye below)</source>
        <translation>Вертикальная стереопара с половинной высотой (правый глаз сверху, левый глаз снизу)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="41"/>
        <source>Anaglyph red/cyan gray</source>
        <translation>Анаглиф красный/голубой серый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="42"/>
        <source>Anaglyph red/cyan half colored</source>
        <translation>Анаглиф красный/голубой полутоновый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="43"/>
        <source>Anaglyph red/cyan color</source>
        <translation>Анаглиф красный/голубой цветной</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="44"/>
        <source>Anaglyph red/cyan color optimized with the least-squares projection of Dubois</source>
        <translation>Анаглиф красный/голубой оптимизированный по Дюбуа</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="46"/>
        <source>Anaglyph green/magenta gray</source>
        <translation>Анаглиф зелёный/пурпурный серый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="47"/>
        <source>Anaglyph green/magenta half colored</source>
        <translation>Анаглиф зелёный/пурпурный полутоновый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="48"/>
        <source>Anaglyph green/magenta colored</source>
        <translation>Анаглиф зелёный/пурпурный цветной</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="50"/>
        <source>Anaglyph yellow/blue gray</source>
        <translation>Анаглиф жёлтый/синий серый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="51"/>
        <source>Anaglyph yellow/blue half colored</source>
        <translation>Анаглиф жёлтый/синий полутоновый</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="52"/>
        <source>Anaglyph yellow/blue colored</source>
        <translation>Анаглиф жёлтый/синий цветной</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="54"/>
        <source>Interleaved rows (left eye has top row, right eye starts on next row)</source>
        <translation>Чересстрочная стереопара (верхняя строка для левого глаза, следующая - для правого)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="55"/>
        <source>Interleaved rows (right eye has top row, left eye starts on next row)</source>
        <translation>Чересстрочная стереопара (верхняя строка для правого глаза, следующая - для левого)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="57"/>
        <source>Mono output (left eye only)</source>
        <translation>Моно режим (только левый глаз)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="58"/>
        <source>Mono output (right eye only)</source>
        <translation>Моно режим (только правый глаз)</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="60"/>
        <source>None</source>
        <translation>Нет</translation>
    </message>
    <message>
        <location filename="../stereo3ddialog.cpp" line="61"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Выбор субтитров</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Этот архив содержит более одного файла субтитров. Пожалуйста, выберите нужный вам для распаковки.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="115"/>
        <source>Channel editor</source>
        <translation>Редактор каналов</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="116"/>
        <source>TV/Radio list</source>
        <translation>Список ТВ и радио</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Перейти к:</translation>
    </message>
    <message>
        <location filename="../timedialog.cpp" line="26"/>
        <source>SMPlayer - Seek</source>
        <translation>SMPlayer – Перемотка</translation>
    </message>
</context>
<context>
    <name>ToolbarEditor</name>
    <message>
        <location filename="../toolbareditor.ui" line="14"/>
        <source>Toolbar Editor</source>
        <translation>Редактор панели инструментов</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="22"/>
        <source>&amp;Available actions:</source>
        <translation>&amp;Доступные действия:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="57"/>
        <source>&amp;Left</source>
        <translation>В&amp;лево</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="67"/>
        <source>&amp;Right</source>
        <translation>В&amp;право</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="77"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="87"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="113"/>
        <source>Curre&amp;nt actions:</source>
        <translation>&amp;Текущие действия:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="130"/>
        <source>&amp;Icon size:</source>
        <translation>&amp;Размер значков:</translation>
    </message>
    <message>
        <location filename="../toolbareditor.ui" line="163"/>
        <source>Add &amp;separator</source>
        <translation>Добавить &amp;разделитель</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="255"/>
        <source>Time slider</source>
        <translation>Ползунок времени</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="257"/>
        <source>Volume slider</source>
        <translation>Ползунок громкости</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="259"/>
        <source>Display time</source>
        <translation>Отображение времени</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="261"/>
        <source>Current time</source>
        <translation>Текущее время</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="263"/>
        <source>Total time</source>
        <translation>Общее время</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="265"/>
        <source>Remaining time</source>
        <translation>Оставшееся время</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="267"/>
        <source>3 in 1 rewind</source>
        <translation>3 в 1 перемотка назад</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="269"/>
        <source>3 in 1 forward</source>
        <translation>3 в 1 перемотка вперёд</translation>
    </message>
    <message>
        <location filename="../toolbareditor.cpp" line="271"/>
        <source>Quick access menu</source>
        <translation>Меню быстрого запуска</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="34"/>
        <source>Auto</source>
        <translation>Автоматически</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="35"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>UpdateChecker</name>
    <message>
        <location filename="../updatechecker.cpp" line="167"/>
        <source>Failed to get the latest version number</source>
        <translation>Не удалось получить номер последней версии</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="202"/>
        <source>New version available</source>
        <translation>Доступна новая версия</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="203"/>
        <source>A new version of SMPlayer is available.</source>
        <translation>Доступна новая версия SMPlayer.</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="204"/>
        <location filename="../updatechecker.cpp" line="221"/>
        <source>Installed version: %1</source>
        <translation>Установленная версия: %1</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="205"/>
        <location filename="../updatechecker.cpp" line="222"/>
        <source>Available version: %1</source>
        <translation>Доступная версия: %1</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="206"/>
        <source>Would you like to know more about this new version?</source>
        <translation>Хотите узнать больше о новой версии?</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="219"/>
        <source>Checking for updates</source>
        <translation>Проверка обновлений</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="220"/>
        <source>Congratulations, SMPlayer is up to date.</source>
        <translation>Поздравляем, у вас последняя версия SMPlayer!</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="227"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="228"/>
        <source>An error happened while trying to retrieve information about the latest version available.</source>
        <translation>Возникла ошибка при получении информации о последней доступной версии.</translation>
    </message>
    <message>
        <location filename="../updatechecker.cpp" line="229"/>
        <source>Error code: %1</source>
        <translation>Код ошибки: %1</translation>
    </message>
</context>
<context>
    <name>VDPAUProperties</name>
    <message>
        <location filename="../vdpauproperties.ui" line="14"/>
        <source>VDPAU Properties</source>
        <translation>Свойства VDPAU</translation>
    </message>
    <message>
        <location filename="../vdpauproperties.ui" line="20"/>
        <source>Select the vdpau codecs to use. Not all of them may work.</source>
        <translation>Выберите используемые кодеки VDPAU. Некоторые из них могут не работать.</translation>
    </message>
    <message>
        <location filename="../vdpauproperties.ui" line="79"/>
        <source>&amp;Disable software video filters</source>
        <translation>&amp;Отключить программные фильтры видео</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.ui" line="14"/>
        <source>Video Equalizer</source>
        <translation>Видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="22"/>
        <source>&amp;Contrast</source>
        <translation>&amp;Контраст</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="76"/>
        <source>&amp;Brightness</source>
        <translation>&amp;Яркость</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="130"/>
        <source>&amp;Hue</source>
        <translation>&amp;Оттенок</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="184"/>
        <source>&amp;Saturation</source>
        <translation>&amp;Насыщенность</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="238"/>
        <source>&amp;Gamma</source>
        <translation>&amp;Гамма</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="309"/>
        <source>Software &amp;equalizer</source>
        <translation>Программный &amp;эквалайзер</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="316"/>
        <source>Set as &amp;default values</source>
        <translation>Установить в качестве стан&amp;дартных</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="323"/>
        <source>&amp;Reset</source>
        <translation>&amp;Сброс</translation>
    </message>
    <message>
        <location filename="../videoequalizer.ui" line="330"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать текущие значения как настройки по умолчанию для новых видео.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="103"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>Video preview</source>
        <translation>Предпросмотр видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="169"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="128"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="129"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="168"/>
        <source>Thumbnail Generator</source>
        <translation>Генератор миниатюр</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="257"/>
        <source>Creating thumbnails...</source>
        <translation>Создание миниатюр…</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="516"/>
        <source>Size: %1 MB</source>
        <translation>Размер: %1 МБ</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="518"/>
        <source>Length: %1</source>
        <translation>Длительность: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="520"/>
        <source>FPS: %1</source>
        <translation>Частота кадров: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="522"/>
        <source>Audio format: %1</source>
        <translation>Формат аудио: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="697"/>
        <source>Save file</source>
        <translation>Сохранить файл</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="714"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="715"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранён</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="213"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="214"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>При создании миниатюр произошла следующая ошибка:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="240"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Не удалось создать временную папку (%1)</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="403"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Процесс MPlayer не был запущен</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="517"/>
        <source>Resolution: %1x%2</source>
        <translation>Разрешение: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="521"/>
        <source>Video format: %1</source>
        <translation>Формат видео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="524"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="423"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Не удалось загрузить файл %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="561"/>
        <source>No filename</source>
        <translation>Не указано имя файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="655"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Процесс MPlayer не был запущен при получении информации о видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="231"/>
        <source>The length of the video is 0</source>
        <translation>Длительность видео 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="275"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Файл %1 не существует</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="698"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="501"/>
        <source>No info</source>
        <translation>Нет информации</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="504"/>
        <location filename="../videopreview/videopreview.cpp" line="505"/>
        <source>%1 kbps</source>
        <translation>%1 кбит/с</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="506"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Video bitrate: %1</source>
        <translation>Битрейт видео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Audio bitrate: %1</source>
        <translation>Битрейт аудио: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="528"/>
        <source>Audio rate: %1</source>
        <translation>Частота аудио: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="37"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="14"/>
        <source>Thumbnail Generator</source>
        <translation>Генератор миниатюр</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="22"/>
        <source>&amp;File:</source>
        <translation>&amp;Файл:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="56"/>
        <source>&amp;Columns:</source>
        <translation>Стол&amp;бцы:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="92"/>
        <source>&amp;Rows:</source>
        <translation>Стро&amp;ки:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="136"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Соотношение сторон:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="200"/>
        <source>&amp;Maximum width:</source>
        <translation>Максимальная &amp;ширина:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="28"/>
        <source>&amp;OK</source>
        <translation>&amp;ОК</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="29"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Отмена</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Окно предпросмотра будет создано для указанного здесь файла.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Миниатюры будут сгруппированы в таблицу.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Эта опция определяет столбцов в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Эта опция определяет количество строк в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="51"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Если вы отметите эту опцию, время будет отображаться внизу каждой миниатюры.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Если соотношение сторон видео неправильное, здесь можно указать другое.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Обычно первые кадры чёрные, поэтому неплохой идеей будет пропустить несколько секунд в начале видео. Эта опция определяет, сколько секунд будет пропущено.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="55"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Эта опция указывает максимальную ширину в пикселах, которую будет иметь сгенерированное изображение.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="56"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Отдельные кадры будут извлечены из видео для создания миниатюр. Здесь вы можете выбрать формат извлекаемых изображений. PNG может выдать лучшее качество.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="114"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Добавить вре&amp;мя на миниатюрах</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="166"/>
        <source>&amp;Seconds to skip at the beginning:</source>
        <translation>Пропуск в &amp;начале в секундах:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="250"/>
        <source>&amp;Extract frames as</source>
        <translation>Извлечь &amp;кадры в</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Укажите здесь устройство DVD или каталог с образом DVD.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="39"/>
        <source>&amp;DVD device:</source>
        <translation>Устройст&amp;во DVD:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="291"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>&amp;Запоминать каталог для сохранения миниатюр</translation>
    </message>
</context>
<context>
    <name>VolumeControlPanel</name>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="132"/>
        <source>Playlist</source>
        <translation>Плейлист</translation>
    </message>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="133"/>
        <source>Fullscreen on/off</source>
        <translation>Полный экран вкл/откл</translation>
    </message>
    <message>
        <location filename="../skingui/volumecontrolpanel.cpp" line="134"/>
        <source>Video equalizer</source>
        <translation>Видеоэквалайзер</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="196"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
</context>
</TS>